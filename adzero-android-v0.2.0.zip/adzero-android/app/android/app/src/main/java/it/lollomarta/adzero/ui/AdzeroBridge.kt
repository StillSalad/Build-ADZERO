package it.lollomarta.adzero.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import it.lollomarta.adzero.AdzeroApp
import it.lollomarta.adzero.BuildConfig
import it.lollomarta.adzero.data.ListUpdateWorker
import it.lollomarta.adzero.data.ListUpdater
import it.lollomarta.adzero.data.UpdateChecker
import it.lollomarta.adzero.data.RuleException
import it.lollomarta.adzero.engine.Action
import it.lollomarta.adzero.engine.DnsMessage
import it.lollomarta.adzero.engine.Stats
import it.lollomarta.adzero.vpn.AdzeroVpnService
import it.lollomarta.adzero.vpn.UpstreamResolver
import it.lollomarta.adzero.vpn.VpnState
import it.lollomarta.adzero.vpn.VpnState.Protection
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.concurrent.Executors

class BridgeException(val code: String, message: String) : Exception(message)

/**
 * Ponte tra dashboard e app. Contratto: docs/BRIDGE.md.
 * Solo i metodi elencati in [handle] esistono; ogni argomento viene validato.
 */
class AdzeroBridge(private val activity: MainActivity, private val webView: WebView) {
    private val app = AdzeroApp.from(activity)
    private val pool = Executors.newFixedThreadPool(3)
    private val idPattern = Regex("^r\\d{1,9}$")

    /** Usato solo sui WebView vecchi senza WEB_MESSAGE_LISTENER. */
    inner class Legacy {
        @JavascriptInterface
        fun request(id: String, method: String, argsJson: String) = dispatch(id, method, argsJson)
    }
    val legacyInterface = Legacy()

    fun onMessage(data: String?) {
        val o = try { JSONObject(data ?: return) } catch (e: Exception) { return }
        dispatch(o.optString("id"), o.optString("method"), o.optJSONObject("args")?.toString() ?: "{}")
    }

    private fun dispatch(id: String, method: String, argsJson: String) {
        if (!idPattern.matches(id) || argsJson.length > 4096) return
        submit {
            val (ok, payload) = try {
                true to handle(method, JSONObject(argsJson))
            } catch (e: BridgeException) {
                false to JSONObject().put("code", e.code).put("message", e.message)
            } catch (e: RuleException) {
                false to JSONObject().put("code", e.code).put("message", e.message)
            } catch (e: Exception) {
                false to JSONObject().put("code", "unknown").put("message", "Operazione non riuscita.")
            }
            post("window.__adzero.resolve(${JSONObject.quote(id)}, $ok, ${JSONObject.quote(payload.toString())})")
        }
    }

    fun emitStatus() = submit {
        post("window.__adzero.emit(\"status\", ${JSONObject.quote(status().toString())})")
    }

    /** Dopo la chiusura dell'Activity il pool è spento: le richieste in ritardo vengono ignorate. */
    private fun submit(task: () -> Unit) {
        try { pool.execute(task) } catch (e: java.util.concurrent.RejectedExecutionException) { }
    }

    private fun post(js: String) = activity.runOnUiThread {
        if (!activity.isDestroyed) webView.evaluateJavascript(js, null)
    }

    fun close() = pool.shutdownNow()

    private fun ok() = JSONObject().put("ok", true)
    private fun JSONObject.str(key: String, allowed: Set<String>? = null): String {
        val v = optString(key, "")
        if (allowed != null && v !in allowed) throw BridgeException("invalid_argument", "Valore non valido per $key.")
        return v
    }

    private fun handle(method: String, a: JSONObject): Any = when (method) {
        "getStatus" -> status()
        "setProtection" -> {
            if (a.optBoolean("enabled")) activity.requestVpnStart()
            else { app.settings.protectionWanted = false; AdzeroVpnService.stop(activity) }
            status()
        }
        "getStats" -> stats(a.str("range", setOf("today", "7d", "30d")))
        "resetStats" -> { app.stats.reset(); ok() }
        "listRules" -> listRules(a)
        "addRule" -> {
            val action = if (a.str("action", setOf("block", "allow")) == "block") Action.BLOCK else Action.ALLOW
            val r = app.rules.addUserRule(action, a.optString("domain").take(300))
            JSONObject().put("action", a.str("action")).put("domain", r.domain)
                .put("includeSubdomains", r.includeSubdomains).put("source", "user")
        }
        "removeRule" -> {
            val action = if (a.str("action", setOf("block", "allow")) == "block") Action.BLOCK else Action.ALLOW
            app.rules.removeUserRule(action, a.optString("domain")); ok()
        }
        "getSources" -> JSONArray(app.rules.sources.map { s ->
            JSONObject().put("id", s.id).put("name", s.name).put("license", s.license).put("homepage", s.homepage)
                .put("enabled", app.rules.isEnabled(s)).put("rules", ListUpdater.ruleCount(activity, s.id))
                .put("updatedAt", ListUpdater.fetchedAt(activity, s.id) ?: JSONObject.NULL)
                .put("lastError", app.settings.sourceLastError(s.id) ?: JSONObject.NULL)
        })
        "setSourceEnabled" -> {
            val id = a.optString("id")
            if (app.rules.sources.none { it.id == id }) throw BridgeException("invalid_argument", "Lista sconosciuta.")
            app.settings.setSourceEnabled(id, a.optBoolean("enabled"))
            app.rules.reloadAsync(); ok()
        }
        "updateLists" -> JSONObject().put("results", JSONArray(ListUpdater.updateAll(activity).map {
            JSONObject().put("id", it.id).put("ok", it.ok).put("rules", it.rules).put("message", it.message)
        }))
        "getApps" -> JSONObject().put("mode", app.settings.appMode).put("apps", JSONArray(
            app.apps.list(a.optString("query").take(100)).map {
                JSONObject().put("packageName", it.packageName).put("label", it.label)
                    .put("selected", it.packageName in app.settings.selectedApps)
                    .put("icon", it.icon ?: JSONObject.NULL)
            }))
        "setAppMode" -> {
            app.settings.appMode = a.str("mode", setOf("exclude", "include"))
            AdzeroVpnService.restartIfRunning(activity); ok()
        }
        "setAppSelected" -> {
            val pkg = a.optString("packageName")
            if (!app.apps.isInstalled(pkg)) throw BridgeException("invalid_argument", "App non trovata.")
            val set = app.settings.selectedApps.toMutableSet()
            if (a.optBoolean("selected")) set.add(pkg) else set.remove(pkg)
            app.settings.selectedApps = set
            AdzeroVpnService.restartIfRunning(activity); ok()
        }
        "getSettings" -> JSONObject().put("theme", app.settings.theme).put("autoUpdate", app.settings.autoUpdate)
            .put("blockMode", app.settings.blockMode).put("upstream", app.settings.upstream)
            .put("version", BuildConfig.VERSION_NAME)
        "setSetting" -> { setSetting(a); ok() }
        "shareApp" -> { shareApp(); ok() }
        "exportStats" -> { exportStats(); ok() }
        "getUpdate" -> update()
        "downloadUpdate" -> { downloadUpdate(a.optString("url")); ok() }
        "getDiagnostics" -> diagnostics()
        "resetDefaults" -> {
            app.settings.resetToDefaults()
            app.rules.clearUserRules()
            ListUpdateWorker.schedule(activity, app.settings.autoUpdate)
            AdzeroVpnService.restartIfRunning(activity); ok()
        }
        "openSystemSettings" -> {
            val action = when (a.str("target", setOf("vpn", "private_dns"))) {
                "vpn" -> AndroidSettings.ACTION_VPN_SETTINGS
                else -> AndroidSettings.ACTION_WIRELESS_SETTINGS
            }
            activity.startActivity(Intent(action)); ok()
        }
        else -> throw BridgeException("unknown_method", "Metodo non consentito.")
    }

    private fun setSetting(a: JSONObject) {
        val s = app.settings
        try {
            when (a.optString("key")) {
                "theme" -> s.theme = a.getString("value")
                "autoUpdate" -> { s.autoUpdate = a.getBoolean("value"); ListUpdateWorker.schedule(activity, s.autoUpdate) }
                "blockMode" -> { s.blockMode = a.getString("value"); app.dnsCache.clear() }
                "upstream" -> { s.upstream = a.getString("value"); app.dnsCache.clear() }
                else -> throw BridgeException("invalid_setting", "Impostazione sconosciuta.")
            }
        } catch (e: IllegalArgumentException) {
            throw BridgeException("invalid_setting", "Valore non valido.")
        } catch (e: org.json.JSONException) {
            throw BridgeException("invalid_setting", "Valore non valido.")
        }
    }


    private fun shareApp() {
        val text = "ADZERO — Meno pubblicità. Più libertà.\nScarica l'app Android gratuita:\n" + UpdateChecker.DOWNLOAD_PAGE
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
            .putExtra(Intent.EXTRA_SUBJECT, "ADZERO")
        activity.startActivity(Intent.createChooser(send, "Condividi ADZERO").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Esporta le statistiche in un CSV temporaneo e apre la condivisione. */
    private fun exportStats() {
        val st = app.stats.stats
        val sb = StringBuilder("data,richieste,bloccate\n")
        st.history(30).forEach { sb.append("${it.date},${it.total},${it.blocked}\n") }
        sb.append("\ndominio,bloccato_volte\n")
        st.topBlocked(50).forEach { sb.append("${it.first},${it.second}\n") }
        val dir = java.io.File(activity.cacheDir, "export").apply { mkdirs() }
        val file = java.io.File(dir, "adzero-statistiche.csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        val uri = androidx.core.content.FileProvider.getUriForFile(activity, "${activity.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).setType("text/csv")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(send, "Esporta statistiche").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun update(): JSONObject {
        val u = UpdateChecker.check()
        return JSONObject().put("current", u.current).put("latest", u.latest ?: JSONObject.NULL)
            .put("available", u.available).put("url", u.apkUrl ?: JSONObject.NULL)
            .put("notes", u.notes ?: JSONObject.NULL).put("error", u.error ?: JSONObject.NULL)
            .put("page", UpdateChecker.DOWNLOAD_PAGE)
    }

    private fun downloadUpdate(url: String) {
        if (url.isBlank()) throw BridgeException("invalid_argument", "Nessun file da scaricare.")
        // Android richiede il permesso di installare pacchetti; se manca, lo chiede.
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            activity.startActivity(Intent(AndroidSettings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                android.net.Uri.parse("package:${activity.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            throw BridgeException("install_permission", "Consenti a ADZERO di installare app, poi riprova.")
        }
        val file = try {
            UpdateChecker.download(activity, url) { pct ->
                post("window.__adzero.emit(\"update_progress\", ${JSONObject.quote(JSONObject().put("percent", pct).toString())})")
            }
        } catch (e: Exception) {
            throw BridgeException("download_failed", "Download non riuscito: ${e.message ?: "errore"}")
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(activity, "${activity.packageName}.files", file)
        val install = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(install)
    }

    fun status(): JSONObject {
        val p = VpnState.protection
        val rs = app.rules.current
        val err = VpnState.errorCode ?: app.rules.lastLoadError
        val updated = app.rules.sources.mapNotNull { ListUpdater.fetchedAt(activity, it.id) }.maxOrNull()
        return JSONObject()
            .put("protection", p.name.lowercase())
            .put("vpn", when (p) { Protection.ON -> "connected"; Protection.STARTING -> "connecting"; else -> "disconnected" })
            .put("network", if (app.network.isAvailable) "available" else "unavailable")
            .put("error", if (err != null) JSONObject().put("code", err).put("message", "") else JSONObject.NULL)
            .put("privateDnsStrict", app.network.privateDnsStrict)
            .put("blockedDomains", rs.blockedDomainCount)
            .put("allowedDomains", rs.allowedDomainCount)
            .put("listsUpdatedAt", updated ?: JSONObject.NULL)
            .put("engineVersion", BuildConfig.VERSION_NAME)
    }

    private fun stats(range: String): JSONObject {
        val st = app.stats.stats
        val days = when (range) { "7d" -> st.history(7); "30d" -> st.history(30); else -> listOf(st.day(LocalDate.now())) }
        val total = days.sumOf { it.total }
        val blocked = days.sumOf { it.blocked }
        return JSONObject()
            .put("total", total).put("blocked", blocked).put("percent", Stats.percent(blocked, total))
            .put("days", JSONArray(days.map { JSONObject().put("date", it.date).put("total", it.total).put("blocked", it.blocked) }))
            .put("top", JSONArray(st.topBlocked(10).map { JSONObject().put("domain", it.first).put("count", it.second) }))
    }

    private fun listRules(a: JSONObject): JSONObject {
        val (rows, total) = app.rules.listRules(a.optString("query").take(100),
            a.str("kind", setOf("all", "block", "allow")), a.optInt("limit", 100))
        return JSONObject().put("total", total).put("rules", JSONArray(rows.map { (r, src) ->
            JSONObject().put("action", if (r.action == Action.BLOCK) "block" else "allow").put("domain", r.domain)
                .put("includeSubdomains", r.includeSubdomains).put("source", src)
        }))
    }

    private fun diagnostics(): JSONObject {
        val items = JSONArray()
        fun item(id: String, label: String, ok: Boolean, detail: String) =
            items.put(JSONObject().put("id", id).put("label", label).put("ok", ok).put("detail", detail))

        val consent = VpnService.prepare(activity) == null
        item("consent", "Permesso VPN", consent, if (consent) "Concesso." else "Non ancora concesso: tocca lo scudo nella Home.")
        val on = VpnState.protection == Protection.ON
        item("vpn", "Servizio VPN", on, if (on) "In esecuzione, filtra le richieste DNS." else "Non in esecuzione.")
        val n = app.rules.current.blockedDomainCount
        item("lists", "Liste di blocco", n > 0, if (n > 0) "%,d domini caricati.".format(n).replace(',', '.') else "Nessuna lista: aggiornale dalla sezione Regole.")
        item("network", "Connessione", app.network.isAvailable, if (app.network.isAvailable) "Disponibile." else "Nessuna rete.")
        val strict = app.network.privateDnsStrict
        item("private_dns", "DNS privato", !strict, if (strict) "Impostato su un nome host: scavalca ADZERO." else "Compatibile.")
        val servers = when (app.settings.upstream) {
            "cloudflare" -> UpstreamResolver.CLOUDFLARE; "quad9" -> UpstreamResolver.QUAD9
            else -> app.network.underlyingDnsServers().ifEmpty { UpstreamResolver.CLOUDFLARE }
        }
        val t0 = System.nanoTime()
        val resp = UpstreamResolver(null) { servers }.resolve(DnsMessage.buildQuery("example.com", id = 0x4144), 3000)
        val ms = (System.nanoTime() - t0) / 1_000_000
        item("upstream", "Server DNS", resp != null, if (resp != null) "Risponde in $ms ms." else "Nessuna risposta: prova un altro server DNS.")
        val notif = Build.VERSION.SDK_INT < 33 ||
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        item("notifications", "Notifiche", notif, if (notif) "Consentite." else "Negate: la protezione funziona, ma senza notifica.")
        return JSONObject().put("items", items)
    }
}
