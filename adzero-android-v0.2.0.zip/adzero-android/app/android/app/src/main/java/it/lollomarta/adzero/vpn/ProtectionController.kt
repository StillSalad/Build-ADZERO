package it.lollomarta.adzero.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import it.lollomarta.adzero.ui.MainActivity

/**
 * Accende/spegne la protezione da punti diversi dall'app (tile, widget).
 * Se manca il consenso VPN apre l'app, perché il consenso richiede una schermata.
 */
object ProtectionController {
    fun toggle(context: Context) {
        if (VpnState.protection == VpnState.Protection.ON) stop(context) else start(context)
    }

    fun start(context: Context) {
        if (VpnService.prepare(context) != null) {
            // Serve il consenso: lo chiede l'app.
            context.startActivity(Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(MainActivity.EXTRA_REQUEST_START, true))
        } else {
            AdzeroVpnService.start(context)
        }
    }

    fun stop(context: Context) = AdzeroVpnService.stop(context)
}
