package it.lollomarta.adzero.ui

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import it.lollomarta.adzero.AdzeroApp
import it.lollomarta.adzero.R
import it.lollomarta.adzero.vpn.VpnState
import it.lollomarta.adzero.vpn.VpnState.Protection
import java.time.LocalDate

/** Widget in home: stato, richieste bloccate oggi, pulsante acceso/spento. */
class AdzeroWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context) ?: return
            val ids = manager.getAppWidgetIds(ComponentName(context, AdzeroWidget::class.java))
            if (ids.isEmpty()) return
            val views = build(context)
            ids.forEach { manager.updateAppWidget(it, views) }
        }

        private fun build(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_adzero)
            val on = VpnState.protection == Protection.ON
            val blocked = AdzeroApp.from(context).stats.stats.day(LocalDate.now()).blocked
            v.setTextViewText(R.id.widget_state, when (VpnState.protection) {
                Protection.ON -> "Protezione attiva"
                Protection.STARTING -> "Avvio…"
                Protection.ERROR -> "Non attiva"
                else -> "Disattivata"
            })
            v.setTextViewText(R.id.widget_count, blocked.toString())
            v.setTextViewText(R.id.widget_toggle, if (on) "Disattiva" else "Attiva")

            val toggle = PendingIntent.getBroadcast(context, 0,
                Intent(context, ToggleReceiver::class.java).setAction(ToggleReceiver.ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.widget_toggle, toggle)

            val open = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.widget_root, open)
            return v
        }
    }
}
