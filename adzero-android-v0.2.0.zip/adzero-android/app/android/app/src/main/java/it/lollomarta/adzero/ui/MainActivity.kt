package it.lollomarta.adzero.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import it.lollomarta.adzero.vpn.AdzeroVpnService
import it.lollomarta.adzero.vpn.VpnState

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var bridge: AdzeroBridge
    private val statusListener: () -> Unit = { runOnUiThread { bridge.emitStatus() } }

    private val vpnConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) AdzeroVpnService.start(this)
        else VpnState.set(VpnState.Protection.ERROR, "consent_denied")
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            domStorageEnabled = false
            setGeolocationEnabled(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == HOST) loader.shouldInterceptRequest(request.url)
                else WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), null)

            // Nessuna navigazione fuori dalla dashboard interna.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = request.url.host != HOST
        }

        bridge = AdzeroBridge(this, webView)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            // Preferito: il ponte esiste solo per la pagina con origine interna.
            WebViewCompat.addWebMessageListener(webView, "AdzeroNative", setOf(ORIGIN)) { _, message, origin, isMainFrame, _ ->
                if (isMainFrame && origin.toString() == ORIGIN) bridge.onMessage(message.data)
            }
        } else {
            webView.addJavascriptInterface(bridge.legacyInterface, "AdzeroNative")
        }

        VpnState.addListener(statusListener)
        if (savedInstanceState == null) webView.loadUrl("$ORIGIN/assets/index.html")
        else webView.restoreState(savedInstanceState)
        handleIntentExtras(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntentExtras(intent)
    }

    /** Avvio chiesto dal widget o dalla tile quando serviva il consenso VPN. */
    private fun handleIntentExtras(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_REQUEST_START, false) == true) {
            intent.removeExtra(EXTRA_REQUEST_START)
            requestVpnStart()
        }
    }

    /** Chiamato dal ponte: chiede il consenso Android solo se serve. */
    fun requestVpnStart() = runOnUiThread {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val consent = VpnService.prepare(this)
        if (consent != null) vpnConsent.launch(consent) else AdzeroVpnService.start(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        VpnState.removeListener(statusListener)
        bridge.close()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_REQUEST_START = "request_start"
        const val HOST = "appassets.androidplatform.net"
        const val ORIGIN = "https://$HOST"
    }
}
