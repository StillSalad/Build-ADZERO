package it.lollomarta.adzero.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import it.lollomarta.adzero.vpn.ProtectionController

/** Riceve il tocco sul pulsante del widget in home. */
class ToggleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TOGGLE) ProtectionController.toggle(context)
    }

    companion object {
        const val ACTION_TOGGLE = "it.lollomarta.adzero.TOGGLE"
    }
}
