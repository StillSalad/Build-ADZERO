package it.lollomarta.adzero.ui

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import it.lollomarta.adzero.AdzeroApp
import it.lollomarta.adzero.vpn.ProtectionController
import it.lollomarta.adzero.vpn.VpnState
import it.lollomarta.adzero.vpn.VpnState.Protection

/** Interruttore di ADZERO nelle Impostazioni rapide di Android. */
class AdzeroTileService : TileService() {
    override fun onStartListening() { render() }

    override fun onClick() {
        ProtectionController.toggle(this)
        render()
    }

    private fun render() {
        val tile = qsTile ?: return
        val blocked = AdzeroApp.from(this).stats.stats.day(java.time.LocalDate.now()).blocked
        tile.state = when (VpnState.protection) {
            Protection.ON -> Tile.STATE_ACTIVE
            Protection.STARTING, Protection.STOPPING -> Tile.STATE_UNAVAILABLE
            else -> Tile.STATE_INACTIVE
        }
        tile.label = "ADZERO"
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = when (VpnState.protection) {
                Protection.ON -> "$blocked bloccate oggi"
                Protection.STARTING -> "Avvio…"
                else -> "Disattivato"
            }
        }
        tile.updateTile()
    }

    companion object {
        fun refresh(context: android.content.Context) {
            try { requestListeningState(context, android.content.ComponentName(context, AdzeroTileService::class.java)) }
            catch (e: Exception) { /* la tile potrebbe non essere aggiunta: ignora */ }
        }
    }
}
