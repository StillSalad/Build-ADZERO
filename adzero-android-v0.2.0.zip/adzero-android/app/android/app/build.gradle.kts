plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Radice del repository (adzero-android/). La dashboard (web/) e le fonti delle
// liste (lists/) diventano assets direttamente: un'unica copia dei file, nessun
// task di copia da tenere sincronizzato.
val repoRoot = rootDir.parentFile.parentFile

// Firma e versione arrivano da variabili d'ambiente (GitHub Actions o PC).
// Senza chiave, la build release resta non firmata: non si può installare.
val keystorePath: String? = System.getenv("ADZERO_KEYSTORE")
val releaseVersion: String = System.getenv("ADZERO_VERSION")?.removePrefix("v") ?: "0.2.0"
val releaseCode: Int = System.getenv("ADZERO_VERSION_CODE")?.toIntOrNull() ?: 1

android {
    namespace = "it.lollomarta.adzero"
    compileSdk = 35

    defaultConfig {
        applicationId = "it.lollomarta.adzero"
        minSdk = 26
        targetSdk = 35
        versionCode = releaseCode
        versionName = releaseVersion
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("ADZERO_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ADZERO_KEY_ALIAS")
                keyPassword = System.getenv("ADZERO_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Vedi docs/COMPILARE.md, sezione "APK firmato".
            signingConfig = if (keystorePath != null) signingConfigs.getByName("release") else null
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { buildConfig = true }

    sourceSets["main"].assets.srcDirs(repoRoot.resolve("web"), repoRoot.resolve("lists"))

    androidResources {
        // Pattern predefinito di Android + esclusioni nostre: liste compilate sul PC,
        // README e modelli che non servono nell'app.
        ignoreAssetsPattern = "!.svn:!.git:!.ds_store:!*.scc:.*:<dir>_*:!CVS:!thumbs.db:!picasa.ini:!*~" +
            ":!compiled:!README.md:!blocklist_custom.txt"
    }

    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    testImplementation("junit:junit:4.13.2")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:rules:1.6.1")
}
