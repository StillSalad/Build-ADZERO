package it.lollomarta.adzero.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log
import it.lollomarta.adzero.AdzeroApp

/**
 * Riavvia la protezione dopo l'accensione del telefono, ma SOLO se:
 * 1. l'utente l'aveva lasciata attiva (protectionWanted), e
 * 2. il consenso VPN è già stato concesso in passato.
 *
 * Android non permette di aprire la finestra di consenso all'avvio, quindi
 * la primissima attivazione resta manuale (tocco dello scudo nell'app).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Solo dopo lo sblocco: le impostazioni stanno in storage normale, non
        // disponibile con LOCKED_BOOT_COMPLETED (telefono ancora bloccato).
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",   // alcuni telefoni (HTC, vecchi)
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED -> start(context)  // dopo un aggiornamento dell'app
        }
    }

    private fun start(context: Context) {
        val app = AdzeroApp.from(context)
        if (!app.settings.protectionWanted) return
        // prepare() restituisce null solo se il consenso VPN è già stato dato.
        if (VpnService.prepare(context) != null) {
            Log.i(TAG, "protezione desiderata ma consenso VPN assente: avvio saltato")
            return
        }
        try {
            AdzeroVpnService.start(context)
        } catch (e: Exception) {
            Log.w(TAG, "avvio automatico non riuscito", e)
        }
    }

    companion object {
        private const val TAG = "AdzeroBoot"
    }
}
