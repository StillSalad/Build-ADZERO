# Liste di blocco

| id | Nome | Licenza | Stato | Note |
|---|---|---|---|---|
| stevenblack-unified | StevenBlack Unified | MIT | attiva | generalista, buon equilibrio |
| hagezi-light | HaGeZi Light | GPL-3.0 | spenta | leggera, pochissimi falsi positivi |
| hagezi-normal | HaGeZi Normal | GPL-3.0 | spenta | più completa, più copertura |

Le liste **non sono incluse nel repository né nell'APK**: l'app le scarica
dalle fonti originali al primo avvio e poi una volta al giorno.

Consiglio d'uso: tieni attiva **una** lista alla volta. Light o Normal di
HaGeZi vanno usate *al posto* di StevenBlack, non insieme, perché si
sovrappongono molto. Più regole = più copertura ma più rischio che qualcosa
si rompa; in quel caso aggiungi il dominio a "Consenti sempre".

HaGeZi è GPL-3.0: finché la lista viene scaricata (non inclusa nell'APK), non
tocca la licenza MIT di ADZERO.
