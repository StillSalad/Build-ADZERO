/* ADZERO — dashboard. Nessun dato inventato: ogni numero arriva da Adzero.call(). */
(function () {
  "use strict";

  var view = document.getElementById("view");
  var state = { route: "home", sub: null, statsRange: "today", ruleKind: "all", ruleQuery: "", appQuery: "" };
  var pollTimer = null;
  var updateInfo = null; // risultato di getUpdate, controllato una volta all'avvio
  var fmt = new Intl.NumberFormat("it-IT");

  /* ---------- Utilità ---------- */
  // Crea elementi senza mai usare innerHTML: i domini arrivano da liste esterne.
  function h(tag, attrs) {
    var el = document.createElement(tag);
    var children = Array.prototype.slice.call(arguments, 2);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === "class") el.className = v;
      else if (k === "text") el.textContent = v;
      else if (k === "style") el.style.cssText = v; // via CSSOM: consentito dalla CSP
      else if (k.slice(0, 2) === "on") el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    });
    children.forEach(function add(c) {
      if (c === null || c === undefined || c === false) return;
      if (Array.isArray(c)) c.forEach(add);
      else el.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return el;
  }

  // replaceChildren non appiattisce gli array: lo facciamo noi.
  function fill(el) {
    var flat = [];
    (function add(list) { list.forEach(function (c) {
      if (Array.isArray(c)) add(c); else if (c) flat.push(c);
    }); })(Array.prototype.slice.call(arguments, 1));
    el.replaceChildren.apply(el, flat);
  }

  var SVGNS = "http://www.w3.org/2000/svg";
  function svg(viewBox, paths) {
    var s = document.createElementNS(SVGNS, "svg");
    s.setAttribute("viewBox", viewBox);
    s.setAttribute("aria-hidden", "true");
    paths.forEach(function (d) {
      var p = document.createElementNS(SVGNS, "path");
      p.setAttribute("d", d);
      s.appendChild(p);
    });
    return s;
  }
  var ICON = {
    shield: function () { return svg("0 0 64 64", ["M32 6 12 13.5v15C12 41.5 20.4 51.8 32 55c11.6-3.2 20-13.5 20-26.5v-15z", "M23 41 32 20l9 21M26.9 34h10.2"]); },
    alert: function () { return svg("0 0 24 24", ["M12 3 2 20h20z", "M12 10v4", "M12 17.2v.1"]); },
    back: function () { return svg("0 0 24 24", ["M15 5l-7 7 7 7"]); },
    close: function () { return svg("0 0 24 24", ["M6 6l12 12M18 6 6 18"]); },
    chevron: function () { return svg("0 0 24 24", ["M9 5l7 7-7 7"]); }
  };

  function n(x) { return fmt.format(x || 0); }
  // Senza servizio non esistono numeri: mostriamo un trattino, non uno zero.
  function nv(x) { return Adzero.isPreview ? "—" : n(x); }
  function pv(x) { return Adzero.isPreview ? "—" : pct(x); }
  function pct(x) { return (Math.round((x || 0) * 10) / 10).toString().replace(".", ",") + "%"; }
  function dateIt(iso) {
    if (!iso) return "mai";
    var d = new Date(iso);
    return isNaN(d) ? "mai" : d.toLocaleString("it-IT", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  var toastTimer;
  function toast(msg) {
    var t = document.getElementById("toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 3200);
  }

  function call(method, args) {
    return Adzero.call(method, args).catch(function (e) {
      if (e.code !== "preview") console.warn(method, e);
      throw e;
    });
  }

  // Pulsante con conferma a doppio tocco (niente finestre modali).
  function confirmButton(label, confirmLabel, cls, action) {
    var armed = false, timer;
    var b = h("button", { class: "btn " + cls + " block", type: "button", text: label });
    b.addEventListener("click", function () {
      if (!armed) {
        armed = true; b.textContent = confirmLabel;
        timer = setTimeout(function () { armed = false; b.textContent = label; }, 4000);
        return;
      }
      clearTimeout(timer); armed = false; b.textContent = label;
      action();
    });
    return b;
  }

  function switchEl(checked, label, onChange) {
    var input = h("input", { type: "checkbox", role: "switch", "aria-label": label });
    input.checked = !!checked;
    input.addEventListener("change", function () { onChange(input.checked, input); });
    return h("label", { class: "switch" }, input, h("span"));
  }

  function segmented(options, current, label, onPick) {
    return h("div", { class: "segmented", role: "group", "aria-label": label },
      options.map(function (o) {
        return h("button", { type: "button", "aria-pressed": String(o[0] === current), text: o[1],
          onclick: function () { onPick(o[0]); } });
      }));
  }

  function emptyState(title, text) {
    return h("div", { class: "empty" }, h("strong", { text: title }), text);
  }

  function errorNotice(e) {
    return notice("danger", "Dati non disponibili", e.message || "Riprova tra poco.");
  }

  function notice(kind, title, text, action) {
    return h("div", { class: "notice" + (kind === "danger" ? " danger" : ""), role: kind === "danger" ? "alert" : null },
      ICON.alert(),
      h("div", null, h("strong", { text: title }), h("p", { text: text }), action || null));
  }

  function subHeader(title) {
    return h("div", { class: "row", style: "margin: 4px 0 10px -10px" },
      h("button", { class: "icon-btn", type: "button", "aria-label": "Indietro",
        onclick: function () { state.sub = null; render(); } }, ICON.back()),
      h("h1", { style: "margin:0", text: title }));
  }

  /* ---------- Tema ---------- */
  var systemDark = window.matchMedia("(prefers-color-scheme: dark)");
  var themePref = "system";
  function applyTheme(pref) {
    themePref = pref || themePref;
    var dark = themePref === "dark" || (themePref === "system" && systemDark.matches);
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  }
  systemDark.addEventListener("change", function () { applyTheme(); });

  /* ---------- Spiegazioni degli errori ---------- */
  var ERRORS = {
    consent_denied: ["Permesso VPN non concesso", "Senza il permesso di Android ADZERO non può filtrare. Tocca lo scudo e scegli OK nella finestra di sistema."],
    other_vpn: ["Un'altra VPN è attiva", "Android permette una sola VPN alla volta. Disattiva l'altra app VPN, poi tocca lo scudo."],
    always_on_other: ["VPN sempre attiva assegnata a un'altra app", "Apri le impostazioni VPN di Android e togli la VPN sempre attiva all'altra app."],
    no_network: ["Nessuna connessione", "Il filtro riprende da solo quando torna la rete."],
    tun_failed: ["Il servizio VPN non è partito", "Tocca lo scudo per riprovare. Se succede di nuovo, apri Impostazioni > Diagnostica."],
    upstream_unreachable: ["Il server DNS non risponde", "Prova a cambiare server DNS in Impostazioni > Filtro."],
    lists_corrupted: ["Una lista di blocco era danneggiata", "È stata scartata. Aggiorna le liste dalla sezione Regole."],
    no_apps_selected: ["Nessuna app selezionata", "In modalità «Solo queste…» scegli almeno un'app nella sezione App, poi tocca lo scudo."]
  };

  /* ---------- Home ---------- */
  var STATE_TEXT = {
    on: ["Protezione attiva", "Le richieste verso domini pubblicitari noti vengono bloccate."],
    off: ["Protezione disattivata", "Tocca lo scudo per attivare il filtro."],
    starting: ["Avvio in corso…", "In attesa del servizio VPN."],
    stopping: ["Arresto in corso…", "Il traffico DNS torna normale."],
    error: ["Protezione non attiva", "Qualcosa ha impedito l'avvio del filtro."],
    unavailable: ["Servizio non disponibile", "Questa è un'anteprima: il filtro funziona solo nell'app installata sul telefono."]
  };

  function renderHome() {
    view.replaceChildren(h("div", { class: "skeleton", style: "margin-top:40px" }));
    Promise.all([call("getStatus"), call("getStats", { range: "today" })]).then(function (r) {
      if (state.route !== "home") return;
      drawHome(r[0], r[1]);
    }).catch(function (e) { view.replaceChildren(errorNotice(e)); });
  }

  function drawHome(st, stats) {
    var p = st.protection;
    var text = STATE_TEXT[p] || STATE_TEXT.error;
    var busy = p === "starting" || p === "stopping";
    var core = h("button", {
      class: "core", type: "button", "data-state": p,
      "aria-label": p === "on" ? "Disattiva protezione" : "Attiva protezione",
      "aria-pressed": String(p === "on"), disabled: busy || p === "unavailable" ? true : null,
      onclick: function () { toggleProtection(p !== "on"); }
    }, ICON.shield());

    var notices = [];
    if (st.error && ERRORS[st.error.code]) {
      notices.push(notice("danger", ERRORS[st.error.code][0], ERRORS[st.error.code][1],
        st.error.code === "always_on_other" ? h("button", { class: "link-btn", type: "button", text: "Apri impostazioni VPN",
          onclick: function () { call("openSystemSettings", { target: "vpn" }).catch(function (e) { toast(e.message); }); } }) : null));
    } else if (st.error && st.error.code !== "preview" && st.error.message) {
      notices.push(notice("danger", "Errore", st.error.message));
    }
    if (st.privateDnsStrict) {
      notices.push(notice("warn", "DNS privato attivo",
        "Con il DNS privato impostato su un nome host, Android scavalca ADZERO. Imposta DNS privato su Automatico o Disattivato.",
        h("button", { class: "link-btn", type: "button", text: "Apri DNS privato",
          onclick: function () { call("openSystemSettings", { target: "private_dns" }).catch(function (e) { toast(e.message); }); } })));
    }
    if (updateInfo && updateInfo.available) {
      notices.unshift(h("div", { class: "notice", role: "status" },
        ICON.alert(),
        h("div", null,
          h("strong", { text: "Aggiornamento disponibile (" + updateInfo.latest + ")" }),
          h("p", { text: "Hai la versione " + updateInfo.current + "." }),
          h("button", { class: "link-btn", type: "button", text: "Scarica e installa",
            onclick: function () { go("settings"); state.sub = "update"; render(); } }))));
    }
    if (!Adzero.isPreview && st.blockedDomains === 0) {
      notices.push(notice("warn", "Nessuna lista caricata", "Senza liste ADZERO non blocca nulla. Scaricale dalla sezione Regole.",
        h("button", { class: "link-btn", type: "button", text: "Vai alle liste", onclick: function () { go("rules"); } })));
    }

    var vpnLabel = { connected: "Connesso", connecting: "In connessione", disconnected: "Non connesso" }[st.vpn] || "Sconosciuto";

    fill(view,
      h("div", { class: "core-wrap" }, core),
      h("p", { class: "state-title", "data-tone": p === "on" ? "on" : p === "error" ? "error" : null, text: text[0] }),
      h("p", { class: "state-sub", text: text[1] }),
      notices,
      h("section", { class: "ledger", "aria-label": "Richieste di oggi", tabindex: "0" },
        h("div", { class: "ledger-head" },
          h("span", { class: "label", text: "Richieste bloccate oggi" }),
          h("span", { class: "num big", text: nv(stats.blocked) }),
          h("div", { class: "meter", role: "img", "aria-label": pct(stats.percent) + " delle richieste bloccate" },
            h("span", { style: "width:" + Math.min(100, stats.percent || 0) + "%" }))),
        h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Richieste DNS oggi" }), h("span", { class: "num", text: nv(stats.total) })),
        h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Percentuale bloccata" }), h("span", { class: "num", text: pv(stats.percent) })),
        h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Domini nella blocklist" }), h("span", { class: "num", text: nv(st.blockedDomains) })),
        h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Servizio VPN" }), h("span", { text: vpnLabel }))),
      h("p", { class: "footnote", text: "Una richiesta bloccata non equivale a un annuncio eliminato: un annuncio può usare più richieste, e alcuni arrivano da domini che il DNS non può separare dai contenuti." })
    );
  }

  function toggleProtection(enable) {
    call("setProtection", { enabled: enable })
      .then(function () { if (state.route === "home") renderHome(); })
      .catch(function (e) { toast(e.message); });
  }

  /* ---------- Statistiche ---------- */
  function renderStats() {
    var head = h("h1", { text: "Statistiche" });
    var seg = segmented([["today", "Oggi"], ["7d", "7 giorni"], ["30d", "30 giorni"]], state.statsRange, "Periodo",
      function (r) { state.statsRange = r; renderStats(); });
    var body = h("div", null, h("div", { class: "skeleton", style: "margin-top:14px" }));
    view.replaceChildren(head, seg, body);

    call("getStats", { range: state.statsRange }).then(function (s) {
      if (state.route !== "stats") return;
      var parts = [
        h("section", { class: "ledger" },
          h("div", { class: "ledger-head" },
            h("span", { class: "label", text: "Richieste bloccate" }),
            h("span", { class: "num big", text: nv(s.blocked) }),
            h("div", { class: "meter" }, h("span", { style: "width:" + Math.min(100, s.percent || 0) + "%" }))),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Richieste DNS totali" }), h("span", { class: "num", text: nv(s.total) })),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Percentuale bloccata" }), h("span", { class: "num", text: pv(s.percent) })))
      ];
      if (state.statsRange !== "today") parts.push(chart(s.days));

      parts.push(h("h2", { text: "Domini bloccati più spesso" }));
      parts.push(s.top && s.top.length
        ? h("div", { class: "list" }, s.top.map(function (t) {
            return h("div", { class: "item" },
              h("div", { class: "item-main" }, h("div", { class: "item-title", text: t.domain })),
              h("span", { class: "count", text: n(t.count) }));
          }))
        : h("div", { class: "list" }, emptyState("Ancora nessun dominio bloccato",
            "Attiva la protezione e usa il telefono normalmente: qui compariranno i domini fermati più spesso.")));

      parts.push(h("p", { class: "footnote", text: "Le statistiche restano sul telefono. Vengono salvati solo i contatori e i domini bloccati, mai quelli che visiti." }));
      parts.push(h("div", { class: "stack" },
        Adzero.isPreview ? null : h("button", { class: "btn ghost block", type: "button", text: "Esporta statistiche (CSV)",
          onclick: function () { call("exportStats").catch(function (e) { toast(e.message); }); } }),
        confirmButton("Azzera statistiche", "Tocca di nuovo per azzerare", "ghost", function () {
          call("resetStats").then(function () { toast("Statistiche azzerate"); renderStats(); }).catch(function (e) { toast(e.message); });
        })));
      body.replaceChildren.apply(body, parts);
    }).catch(function (e) { body.replaceChildren(errorNotice(e)); });
  }

  function chart(days) {
    var W = 320, H = 150, pad = 18, n = days.length;
    var max = Math.max(1, Math.max.apply(null, days.map(function (d) { return d.total; })));
    var gap = n > 10 ? 2 : 6, bw = (W - gap * (n - 1)) / n;
    var s = document.createElementNS(SVGNS, "svg");
    s.setAttribute("viewBox", "0 0 " + W + " " + H);
    s.setAttribute("preserveAspectRatio", "none");
    s.setAttribute("role", "img");
    var total = days.reduce(function (a, d) { return a + d.blocked; }, 0);
    s.setAttribute("aria-label", "Richieste bloccate per giorno, totale " + fmt.format(total));
    function rect(x, y, w, hgt, cls) {
      var r = document.createElementNS(SVGNS, "rect");
      r.setAttribute("x", x); r.setAttribute("y", y); r.setAttribute("width", w);
      r.setAttribute("height", Math.max(0, hgt)); r.setAttribute("rx", Math.min(3, w / 2));
      r.setAttribute("class", cls); s.appendChild(r);
    }
    var usable = H - pad;
    days.forEach(function (d, i) {
      var x = i * (bw + gap);
      var th = d.total ? Math.max(2, d.total / max * usable) : 2;
      rect(x, usable - th, bw, th, "bar-total");
      if (d.blocked) { var bh = Math.max(2, d.blocked / max * usable); rect(x, usable - bh, bw, bh, "bar-blocked"); }
      if (n <= 7 || i === 0 || i === n - 1) {
        var t = document.createElementNS(SVGNS, "text");
        t.setAttribute("x", x + bw / 2); t.setAttribute("y", H - 3);
        t.setAttribute("text-anchor", n > 7 ? (i === 0 ? "start" : "end") : "middle");
        t.setAttribute("class", "axis");
        var dt = new Date(d.date + "T12:00:00");
        t.textContent = n <= 7 ? dt.toLocaleDateString("it-IT", { weekday: "short" }) : dt.toLocaleDateString("it-IT", { day: "numeric", month: "short" });
        s.appendChild(t);
      }
    });
    return h("div", { class: "chart" }, s,
      h("div", { class: "legend" },
        h("span", null, h("i", { style: "background:var(--green)" }), "Bloccate"),
        h("span", null, h("i", { style: "background:var(--surface-2)" }), "Totali")));
  }

  /* ---------- Regole ---------- */
  var newRuleAction = "block";
  function renderRules() {
    var input = h("input", { class: "field", type: "text", inputmode: "url", autocapitalize: "off", autocomplete: "off",
      spellcheck: "false", placeholder: "es. ads.esempio.com", "aria-label": "Dominio" });
    var hint = h("p", { class: "hint", text: "I sottodomini sono inclusi." });
    var addBtn = h("button", { class: "btn", type: "button", text: "Aggiungi", disabled: true });

    input.addEventListener("input", function () {
      var raw = input.value.trim();
      var d = AdzeroDomain.normalizeDomain(raw);
      addBtn.disabled = !d;
      input.setAttribute("aria-invalid", String(!!raw && !d));
      hint.className = "hint" + (raw && !d ? " error" : "");
      hint.textContent = !raw ? "I sottodomini sono inclusi." : d ? (d !== raw.toLowerCase() ? "Verrà salvato come " + d : "I sottodomini sono inclusi.") : "Non è un dominio valido.";
    });
    function add() {
      if (addBtn.disabled) return;
      call("addRule", { action: newRuleAction, domain: input.value }).then(function (r) {
        toast((r.action === "block" ? "Bloccato " : "Consentito ") + r.domain);
        input.value = ""; renderRules();
      }).catch(function (e) { hint.className = "hint error"; hint.textContent = e.message; });
    }
    addBtn.addEventListener("click", add);
    input.addEventListener("keydown", function (e) { if (e.key === "Enter") add(); });

    var search = h("input", { class: "field", type: "search", placeholder: "Cerca nelle regole", "aria-label": "Cerca nelle regole", value: state.ruleQuery });
    var listBox = h("div", { class: "list" }, h("div", { class: "empty", text: "Caricamento…" }));
    var t;
    search.addEventListener("input", function () {
      clearTimeout(t);
      t = setTimeout(function () { state.ruleQuery = search.value; loadRules(listBox); }, 200);
    });

    var sourcesBox = h("div", null);

    view.replaceChildren(
      h("h1", { text: "Regole" }),
      segmented([["block", "Blocca"], ["allow", "Consenti sempre"]], newRuleAction, "Tipo di regola",
        function (a) { newRuleAction = a; renderRules(); }),
      h("div", { class: "row", style: "margin-top:10px" }, input, addBtn),
      hint,
      h("h2", { text: "Le tue regole e quelle predefinite" }),
      segmented([["all", "Tutte"], ["block", "Bloccate"], ["allow", "Consentite"]], state.ruleKind, "Filtra",
        function (k) { state.ruleKind = k; renderRules(); }),
      h("div", { style: "margin:10px 0" }, search),
      listBox,
      h("h2", { text: "Liste di blocco" }),
      sourcesBox
    );
    loadRules(listBox);
    loadSources(sourcesBox);
  }

  function loadRules(box) {
    call("listRules", { query: state.ruleQuery, kind: state.ruleKind, limit: 100 }).then(function (res) {
      if (!res.rules.length) {
        box.replaceChildren(emptyState(state.ruleQuery ? "Nessun risultato" : "Nessuna regola",
          state.ruleQuery ? "Prova con una parte diversa del dominio." : "Aggiungi un dominio qui sopra."));
        return;
      }
      box.replaceChildren.apply(box, res.rules.map(function (r) {
        return h("div", { class: "item" },
          h("div", { class: "item-main" },
            h("div", { class: "item-title", text: r.domain }),
            h("div", { class: "item-sub", text: (r.includeSubdomains ? "Con sottodomini" : "Solo questo nome") + (r.source === "default" ? " · predefinita" : "") })),
          h("span", { class: "tag " + r.action, text: r.action === "block" ? "Bloccato" : "Consentito" }),
          r.source === "user" ? h("button", { class: "icon-btn", type: "button", "aria-label": "Elimina regola " + r.domain,
            onclick: function () {
              call("removeRule", { action: r.action, domain: r.domain })
                .then(function () { toast("Regola eliminata"); loadRules(box); })
                .catch(function (e) { toast(e.message); });
            } }, ICON.close()) : null);
      }));
      if (res.total > res.rules.length)
        box.appendChild(h("div", { class: "empty small", text: "Mostrate " + res.rules.length + " regole su " + n(res.total) + ". Usa la ricerca per trovarne altre." }));
    }).catch(function (e) { box.replaceChildren(errorNotice(e)); });
  }

  function loadSources(box) {
    call("getSources").then(function (sources) {
      var updateBtn = h("button", { class: "btn ghost block", type: "button", text: "Aggiorna liste ora" });
      updateBtn.addEventListener("click", function () {
        updateBtn.disabled = true; updateBtn.textContent = "Aggiornamento…";
        call("updateLists").then(function (res) {
          var bad = res.results.filter(function (r) { return !r.ok; });
          toast(bad.length ? "Non aggiornate: " + bad.map(function (b) { return b.id; }).join(", ") : "Liste aggiornate");
          loadSources(box);
        }).catch(function (e) {
          toast(e.message); updateBtn.disabled = false; updateBtn.textContent = "Aggiorna liste ora";
        });
      });
      box.replaceChildren(
        h("div", { class: "list" }, sources.map(function (s) {
          var sub = "Licenza " + s.license + " · " + (s.updatedAt ? n(s.rules) + " regole · " + dateIt(s.updatedAt) : "non ancora scaricata");
          return h("div", { class: "item" },
            h("div", { class: "item-main" },
              h("div", { class: "item-title", text: s.name }),
              h("div", { class: "item-sub", text: sub }),
              s.lastError ? h("div", { class: "item-sub", style: "color:var(--danger)", text: s.lastError }) : null),
            switchEl(s.enabled, "Usa " + s.name, function (on, el) {
              call("setSourceEnabled", { id: s.id, enabled: on }).catch(function (e) { el.checked = !on; toast(e.message); });
            }));
        })),
        h("div", { class: "stack" }, updateBtn),
        h("p", { class: "footnote", text: "Le liste vengono scaricate direttamente dalle fonti originali. Una lista che arriva vuota o danneggiata viene scartata e resta quella precedente." }));
    }).catch(function (e) { box.replaceChildren(errorNotice(e)); });
  }

  /* ---------- App ---------- */
  function renderApps() {
    var listBox = h("div", { class: "list" }, h("div", { class: "empty", text: "Caricamento…" }));
    var search = h("input", { class: "field", type: "search", placeholder: "Cerca app", "aria-label": "Cerca app", value: state.appQuery });
    var t;
    search.addEventListener("input", function () {
      clearTimeout(t);
      t = setTimeout(function () { state.appQuery = search.value; load(); }, 200);
    });
    var modeBox = h("div");
    var explain = h("p", { class: "muted small", style: "margin:10px 4px 0" });

    view.replaceChildren(h("h1", { text: "App" }), modeBox, explain, h("div", { style: "margin:16px 0 10px" }, search), listBox,
      h("p", { class: "footnote", text: "Dopo una modifica ADZERO riavvia il filtro per applicarla. Android non permette di combinare le due modalità." }));

    function load() {
      call("getApps", { query: state.appQuery }).then(function (res) {
        modeBox.replaceChildren(segmented([["exclude", "Tutte tranne…"], ["include", "Solo queste…"]], res.mode, "Modalità",
          function (m) { call("setAppMode", { mode: m }).then(load).catch(function (e) { toast(e.message); }); }));
        explain.textContent = res.mode === "exclude"
          ? "Il filtro vale per tutte le app. Attiva l'interruttore sulle app da escludere."
          : "Il filtro vale solo per le app con l'interruttore attivo.";
        if (!res.apps.length) {
          listBox.replaceChildren(Adzero.isPreview
            ? emptyState("Elenco app non disponibile", "L'elenco delle app installate arriva dall'app Android.")
            : emptyState("Nessuna app trovata", "Prova con un altro nome."));
          return;
        }
        listBox.replaceChildren.apply(listBox, res.apps.map(function (a) {
          return h("div", { class: "item" },
            h("div", { class: "avatar" }, a.icon && a.icon.indexOf("data:image/png;base64,") === 0
              ? h("img", { src: a.icon, alt: "" }) : (a.label || "?").charAt(0).toUpperCase()),
            h("div", { class: "item-main" },
              h("div", { class: "item-title", text: a.label }),
              h("div", { class: "item-sub", text: a.packageName })),
            switchEl(a.selected, (res.mode === "exclude" ? "Escludi " : "Filtra ") + a.label, function (on, el) {
              call("setAppSelected", { packageName: a.packageName, selected: on }).catch(function (e) { el.checked = !on; toast(e.message); });
            }));
        }));
      }).catch(function (e) { listBox.replaceChildren(errorNotice(e)); });
    }
    load();
  }

  /* ---------- Impostazioni ---------- */
  function navItem(title, sub, onclick) {
    return h("button", { class: "item", type: "button", style: "width:100%;border-left:0;border-right:0;border-bottom:0;background:none;text-align:left", onclick: onclick },
      h("div", { class: "item-main" }, h("div", { class: "item-title", text: title }), sub ? h("div", { class: "item-sub", text: sub }) : null),
      h("span", { class: "icon-btn" }, ICON.chevron()));
  }

  function selectEl(label, value, options, onChange) {
    var s = h("select", { class: "field", "aria-label": label },
      options.map(function (o) { return h("option", { value: o[0], selected: o[0] === value ? true : null, text: o[1] }); }));
    s.addEventListener("change", function () { onChange(s.value); });
    return s;
  }

  function setSetting(key, value) {
    return call("setSetting", { key: key, value: value }).catch(function (e) { toast(e.message); throw e; });
  }

  function renderSettings() {
    if (state.sub === "privacy") return renderPrivacy();
    if (state.sub === "engine") return renderEngine();
    if (state.sub === "diagnostics") return renderDiagnostics();
    if (state.sub === "update") return renderUpdate();

    call("getSettings").then(function (s) {
      if (state.route !== "settings") return;
      view.replaceChildren(
        h("h1", { text: "Impostazioni" }),
        h("h2", { text: "Aspetto" }),
        h("div", { class: "list" },
          h("div", { class: "item" }, h("div", { class: "item-main" }, h("div", { class: "item-title", text: "Tema" })),
            selectEl("Tema", s.theme, [["system", "Come il telefono"], ["dark", "Scuro"], ["light", "Chiaro"]],
              function (v) { setSetting("theme", v).then(function () { applyTheme(v); }); }))),
        h("h2", { text: "Liste" }),
        h("div", { class: "list" },
          h("div", { class: "item" },
            h("div", { class: "item-main" }, h("div", { class: "item-title", text: "Aggiornamento automatico" }),
              h("div", { class: "item-sub", text: "Una volta al giorno, solo con Wi-Fi" })),
            switchEl(s.autoUpdate, "Aggiornamento automatico", function (on, el) { setSetting("autoUpdate", on).catch(function () { el.checked = !on; }); })),
          navItem("Gestisci liste e regole", null, function () { go("rules"); })),
        h("h2", { text: "Filtro" }),
        h("div", { class: "list" },
          h("div", { class: "item" },
            h("div", { class: "item-main" }, h("div", { class: "item-title", text: "Risposta DNS" }), h("div", { class: "item-sub", text: "Per i domini bloccati" })),
            selectEl("Risposta ai domini bloccati", s.blockMode, [["null_ip", "Indirizzo nullo"], ["nxdomain", "Dominio inesistente"]],
              function (v) { setSetting("blockMode", v); })),
          h("div", { class: "item" },
            h("div", { class: "item-main" }, h("div", { class: "item-title", text: "Server DNS" })),
            selectEl("Server DNS", s.upstream, [["auto", "Quello della rete"], ["cloudflare", "Cloudflare"], ["quad9", "Quad9"]],
              function (v) { setSetting("upstream", v); }))),
        h("h2", { text: "Condivisione e aggiornamenti" }),
        h("div", { class: "list" },
          navItem("Condividi ADZERO", "Invia il link per scaricarla", function () {
            call("shareApp").catch(function (e) { toast(e.message); });
          }),
          navItem("Esporta statistiche", "Salva un file CSV", function () {
            call("exportStats").catch(function (e) { toast(e.message); });
          }),
          navItem("Controlla aggiornamenti", "Versione " + (s.version || ""), function () { state.sub = "update"; render(); })),
        h("h2", { text: "Informazioni" }),
        h("div", { class: "list" },
          navItem("Motore di filtraggio", "Versione, regole caricate, limiti", function () { state.sub = "engine"; render(); }),
          navItem("Privacy", "Cosa resta sul telefono", function () { state.sub = "privacy"; render(); }),
          navItem("Diagnostica", "Controlla cosa non funziona", function () { state.sub = "diagnostics"; render(); })),
        h("div", { class: "stack", style: "margin-top:26px" },
          confirmButton("Ripristina impostazioni predefinite", "Tocca di nuovo per ripristinare", "danger", function () {
            call("resetDefaults").then(function () { applyTheme("system"); toast("Impostazioni ripristinate"); renderSettings(); })
              .catch(function (e) { toast(e.message); });
          })),
        h("p", { class: "footnote", style: "text-align:center;margin-top:22px", text: "ADZERO · Meno pubblicità. Più libertà." })
      );
    }).catch(function (e) { view.replaceChildren(errorNotice(e)); });
  }

  function renderPrivacy() {
    view.replaceChildren(subHeader("Privacy"), h("div", { class: "prose" },
      h("p", { text: "ADZERO funziona interamente sul telefono. Non ha account, non usa server propri e non invia dati a nessuno." }),
      h("p", { text: "La VPN serve solo a far passare le richieste DNS dal filtro. Il resto del traffico non entra nel tunnel e il contenuto delle connessioni HTTPS non viene mai letto né decifrato." }),
      h("p", { text: "Vengono salvati soltanto contatori giornalieri e i domini bloccati più frequenti. I domini consentiti, gli orari e le app di provenienza non vengono registrati." }),
      h("p", { text: "Le uniche connessioni di ADZERO verso Internet sono il download delle liste dalle loro fonti originali e l'inoltro delle richieste DNS consentite al server DNS scelto." }),
      h("p", { text: "Puoi cancellare tutto in qualsiasi momento con Azzera statistiche e Ripristina impostazioni predefinite." })));
  }

  function renderEngine() {
    call("getStatus").then(function (st) {
      view.replaceChildren(subHeader("Motore di filtraggio"),
        h("section", { class: "ledger", style: "margin-top:6px" },
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Versione" }), h("span", { text: st.engineVersion || "—" })),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Domini bloccati" }), h("span", { class: "num", text: n(st.blockedDomains) })),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Domini consentiti" }), h("span", { class: "num", text: n(st.allowedDomains) })),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Liste aggiornate" }), h("span", { text: dateIt(st.listsUpdatedAt) }))),
        h("h2", { text: "Come funziona" }),
        h("div", { class: "prose" },
          h("p", { text: "Ogni volta che un'app cerca l'indirizzo di un dominio, ADZERO controlla le regole. Se il dominio è nella blocklist risponde subito con un indirizzo vuoto, così l'annuncio non viene scaricato. Le regole Consenti sempre hanno la precedenza." })),
        h("h2", { text: "Limiti" }),
        h("div", { class: "prose" },
          h("p", { text: "Non tutti gli annunci si possono bloccare: alcuni arrivano dallo stesso dominio dei contenuti, come i video di YouTube." }),
          h("p", { text: "Le app che usano un DNS cifrato proprio, come Chrome con DNS sicuro attivo, e il DNS privato di Android impostato su un nome host scavalcano il filtro." }),
          h("p", { text: "Android consente una sola VPN alla volta." }),
          h("p", { text: "Il consumo di batteria è basso perché nel tunnel passano solo le richieste DNS, ma non è nullo." })));
    }).catch(function (e) { view.replaceChildren(subHeader("Motore di filtraggio"), errorNotice(e)); });
  }

  function renderDiagnostics() {
    var box = h("div", { class: "list" }, h("div", { class: "empty", text: "Controllo in corso…" }));
    view.replaceChildren(subHeader("Diagnostica"), box,
      h("div", { class: "stack" }, h("button", { class: "btn ghost block", type: "button", text: "Ripeti controllo", onclick: renderDiagnostics })));
    call("getDiagnostics").then(function (d) {
      box.replaceChildren.apply(box, d.items.map(function (it) {
        return h("div", { class: "item" },
          h("span", { class: "diag-dot" + (it.ok ? " ok" : ""), "aria-label": it.ok ? "OK" : "Problema" }),
          h("div", { class: "item-main" }, h("div", { class: "item-title", text: it.label }), h("div", { class: "item-sub", text: it.detail })));
      }));
    }).catch(function (e) { box.replaceChildren(errorNotice(e)); });
  }

  function renderUpdate() {
    var box = h("div", null, h("div", { class: "skeleton", style: "margin-top:6px" }));
    view.replaceChildren(subHeader("Aggiornamenti"), box);
    call("getUpdate").then(function (u) {
      updateInfo = u;
      if (u.error) { box.replaceChildren(errorNotice({ message: u.error })); return;
      }
      if (!u.available) {
        box.replaceChildren(
          h("section", { class: "ledger", style: "margin-top:6px" },
            h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Versione installata" }), h("span", { text: u.current })),
            h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Ultima versione" }), h("span", { text: u.latest || "—" }))),
          h("p", { class: "footnote", text: u.latest ? "Hai già l'ultima versione." : "Nessuna versione pubblicata da scaricare." }));
        return;
      }
      var progress = h("p", { class: "hint" });
      var btn = h("button", { class: "btn block", type: "button", text: "Scarica e installa " + u.latest });
      var onProg = function (p) { progress.textContent = "Scaricamento… " + p.percent + "%"; };
      btn.addEventListener("click", function () {
        btn.disabled = true; progress.textContent = "Avvio del download…";
        Adzero.on("update_progress", onProg);
        call("downloadUpdate", { url: u.url }).then(function () {
          progress.textContent = "Apro l'installazione…";
        }).catch(function (e) {
          btn.disabled = false; progress.className = "hint error"; progress.textContent = e.message;
        });
      });
      box.replaceChildren(
        h("section", { class: "ledger", style: "margin-top:6px" },
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Versione installata" }), h("span", { text: u.current })),
          h("div", { class: "ledger-row" }, h("span", { class: "label", text: "Nuova versione" }), h("span", { class: "num", text: u.latest }))),
        u.notes ? h("div", { class: "prose", style: "margin-top:14px" }, h("h2", { text: "Novità" }), h("p", { text: u.notes })) : null,
        h("div", { class: "stack" }, btn), progress,
        h("p", { class: "footnote", text: "L'installazione va confermata da Android. Funziona solo se la nuova versione è firmata con la stessa chiave della precedente." }));
    }).catch(function (e) { box.replaceChildren(errorNotice(e)); });
  }

  /* ---------- Navigazione ---------- */
  var ROUTES = { home: renderHome, stats: renderStats, rules: renderRules, apps: renderApps, settings: renderSettings };

  function go(route) {
    if (!ROUTES[route]) route = "home";
    state.route = route; state.sub = null;
    render();
    window.scrollTo(0, 0);
    if (document.documentElement.classList.contains("tv")) focusFirstInContent();
    else view.focus({ preventScroll: true });
  }

  // In TV porta il fuoco sul primo comando dentro il contenuto, non sulla barra in basso.
  function focusFirstInContent() {
    setTimeout(function () {
      var el = view.querySelector('button, a[href], input, select, [tabindex]:not([tabindex="-1"])');
      if (el) el.focus(); else view.focus({ preventScroll: true });
    }, 60);
  }


  /* ---------- Navigazione con telecomando (Android TV) ---------- */
  function focusables() {
    return Array.prototype.filter.call(
      document.querySelectorAll('button, a[href], input, select, [tabindex]:not([tabindex="-1"])'),
      function (el) { return el.offsetParent !== null && !el.disabled; });
  }

  // Sposta il fuoco all'elemento più vicino nella direzione data (frecce del telecomando).
  function moveFocus(dir) {
    var list = focusables();
    var active = document.activeElement;
    var here = (active && list.indexOf(active) !== -1) ? active.getBoundingClientRect() : null;
    if (!here) { if (list[0]) list[0].focus(); return; }
    var best = null, bestScore = Infinity;
    var cx = here.left + here.width / 2, cy = here.top + here.height / 2;
    list.forEach(function (el) {
      if (el === active) return;
      var r = el.getBoundingClientRect();
      var ex = r.left + r.width / 2, ey = r.top + r.height / 2;
      var dx = ex - cx, dy = ey - cy;
      var ok = (dir === "right" && dx > 8) || (dir === "left" && dx < -8) ||
               (dir === "down" && dy > 8) || (dir === "up" && dy < -8);
      if (!ok) return;
      // Distanza, penalizzando lo scostamento sull'asse trasversale.
      var along = (dir === "left" || dir === "right") ? Math.abs(dx) : Math.abs(dy);
      var cross = (dir === "left" || dir === "right") ? Math.abs(dy) : Math.abs(dx);
      var score = along + cross * 2.5;
      if (score < bestScore) { bestScore = score; best = el; }
    });
    if (best) best.focus();
  }

  function setupTvNavigation() {
    document.addEventListener("keydown", function (e) {
      var k = e.key;
      if (k === "ArrowRight") { moveFocus("right"); e.preventDefault(); }
      else if (k === "ArrowLeft") { moveFocus("left"); e.preventDefault(); }
      else if (k === "ArrowDown") { moveFocus("down"); e.preventDefault(); }
      else if (k === "ArrowUp") { moveFocus("up"); e.preventDefault(); }
      else if (k === "Enter" && document.activeElement && document.activeElement.tagName === "SELECT") {
        // lascia aprire il menu a tendina normalmente
      }
    });
    // A ogni cambio schermata, porta il fuoco sul primo elemento utile.
    var mo = new MutationObserver(function () {
      var a = document.activeElement;
      if (a === document.body || a === view || a === null) {
        var el = view.querySelector('button, a[href], input, select, [tabindex]:not([tabindex="-1"])');
        if (el) el.focus();
      }
    });
    mo.observe(view, { childList: true, subtree: true });
  }

  function render() {
    document.querySelectorAll(".tab").forEach(function (t) {
      if (t.dataset.route === state.route) t.setAttribute("aria-current", "page");
      else t.removeAttribute("aria-current");
    });
    ROUTES[state.route]();
    schedulePoll();
  }

  // Aggiorna la Home ogni 5 secondi mentre è visibile (l'app nativa può anche spingere eventi).
  function schedulePoll() {
    clearInterval(pollTimer);
    if (state.route === "home" && !Adzero.isPreview) {
      pollTimer = setInterval(function () {
        if (document.hidden || state.route !== "home") return;
        Promise.all([call("getStatus"), call("getStats", { range: "today" })])
          .then(function (r) { if (state.route === "home") drawHome(r[0], r[1]); }).catch(function () {});
      }, 5000);
    }
  }

  Adzero.on("status", function () { if (state.route === "home") renderHome(); });

  document.querySelectorAll(".tab").forEach(function (t) {
    t.addEventListener("click", function () { go(t.dataset.route); });
  });

  // Modalità TV: l'app aggiunge ?tv=1 all'indirizzo quando gira su Android TV.
  var isTv = /[?&]tv=1\b/.test(location.search);
  if (isTv) {
    document.documentElement.classList.add("tv");
    setupTvNavigation();
  }

  document.getElementById("previewBadge").hidden = !Adzero.isPreview;
  call("getSettings").then(function (s) { applyTheme(s.theme); }).catch(function () { applyTheme("system"); });
  if (!Adzero.isPreview) {
    call("getUpdate").then(function (u) {
      updateInfo = u;
      if (u.available && state.route === "home") renderHome();
    }).catch(function () {});
  }
  go("home");
})();
