package it.lollomarta.adzero.data

import android.content.Context
import it.lollomarta.adzero.BuildConfig
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val current: String,
    val latest: String?,
    val available: Boolean,
    val apkUrl: String?,
    val notes: String?,
    val error: String?,
)

/**
 * Controllo aggiornamenti dalle Release di GitHub e download dell'APK.
 * Solo HTTPS e solo host di GitHub; l'installazione la conferma sempre l'utente.
 */
object UpdateChecker {
    // Se il tuo repository ha un nome diverso, cambia qui "utente/repo".
    const val REPO = "StillSalad/Build-ADZERO"
    const val DOWNLOAD_PAGE = "https://github.com/$REPO/releases/latest"

    private const val MAX_APK_BYTES = 80 * 1024 * 1024
    private val ALLOWED_HOSTS = setOf(
        "github.com", "api.github.com",
        "objects.githubusercontent.com", "release-assets.githubusercontent.com",
    )

    private fun allowed(host: String) = ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") }

    fun check(): UpdateInfo {
        val current = BuildConfig.VERSION_NAME
        return try {
            val json = JSONObject(httpGetText("https://api.github.com/repos/$REPO/releases/latest"))
            val tag = json.getString("tag_name").removePrefix("v")
            val notes = json.optString("body", "").trim().take(1000)
            val assets = json.getJSONArray("assets")
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }
                .firstOrNull { it.optString("name").endsWith(".apk") }
                ?.optString("browser_download_url")
            UpdateInfo(current, tag, isNewer(tag, current), apk, notes.ifBlank { null }, null)
        } catch (e: Exception) {
            UpdateInfo(current, null, false, null, null, friendly(e))
        }
    }

    /** Confronto per segmenti numerici: 0.10.0 > 0.9.0. */
    fun isNewer(latest: String, current: String): Boolean {
        fun parts(v: String) = v.split('.', '-', '+').mapNotNull { it.toIntOrNull() }
        val a = parts(latest); val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun download(context: Context, url: String, onProgress: (Int) -> Unit): File {
        val dir = File(context.cacheDir, "update").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "adzero-update.apk")
        val conn = openFollowingRedirects(url)
        try {
            if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                out.outputStream().use { file ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        file.write(buf, 0, n)
                        read += n
                        if (read > MAX_APK_BYTES) throw java.io.IOException("file troppo grande")
                        if (total > 0) onProgress(((read * 100) / total).toInt().coerceIn(0, 100))
                    }
                }
            }
            onProgress(100)
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun httpGetText(url: String): String {
        val conn = openFollowingRedirects(url)
        try {
            if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** Segue i reindirizzamenti a mano, verificando l'host a ogni passo. */
    private fun openFollowingRedirects(startUrl: String): HttpURLConnection {
        var url = startUrl
        repeat(6) {
            val parsed = URL(url)
            require(parsed.protocol == "https" && allowed(parsed.host)) { "URL non attendibile" }
            val conn = parsed.openConnection() as HttpURLConnection
            conn.connectTimeout = 20_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "ADZERO/${BuildConfig.VERSION_NAME}")
            conn.setRequestProperty("Accept", "application/vnd.github+json, application/octet-stream")
            val code = conn.responseCode
            if (code in 301..308) {
                val loc = conn.getHeaderField("Location") ?: throw java.io.IOException("redirect senza destinazione")
                conn.disconnect()
                url = URL(parsed, loc).toString()
                return@repeat
            }
            return conn
        }
        throw java.io.IOException("troppi reindirizzamenti")
    }

    private fun friendly(e: Exception): String = when {
        e.message?.contains("HTTP 404") == true -> "Nessuna release pubblicata."
        e is java.net.UnknownHostException -> "Nessuna connessione."
        else -> "Controllo non riuscito."
    }
}
