# ADZERO — Fase 1: requisiti e architettura

## 1. Decisione chiave: dove gira il filtraggio

Il filtraggio sul telefono è scritto in **Kotlin**, non in Python.

Perché non Python nell'app (es. Chaquopy): il servizio VPN deve decidere su
ogni singola richiesta DNS, in background, per ore. Passare ogni pacchetto
da Kotlin a un interprete Python via JNI aggiunge latenza, consumo di
batteria, megabyte all'APK e un secondo runtime da mantenere. Non è
giustificato.

Ruolo di Python: **motore di riferimento**. In `engine/` c'è l'algoritmo
completo e testato (normalizzazione, parsing liste, decisione, risposte DNS,
cache, statistiche, aggiornamento liste). Il motore Kotlin lo replica, e i
**vettori condivisi** in `tests/vectors/` vengono eseguiti sia da pytest sia
dai test JUnit: se i due motori divergono, un test fallisce.

## 2. Schema

```
 App/gioco ──query DNS──▶ resolver Android ──▶ DNS virtuale 10.111.222.1 (tun)
                                                     │
                                         AdzeroVpnService (Kotlin)
                                         ├─ parse pacchetto IP/UDP/DNS
                                         ├─ RuleSet.check(dominio)
                                         │   ├─ bloccato → risposta 0.0.0.0 / ::
                                         │   └─ consentito → cache → DNS reale
                                         │        (socket protetto con protect())
                                         └─ Stats (solo contatori locali)
 Dashboard WebView (assets locali) ◀── bridge JS limitato ──▶ servizio
```

Nel tunnel passa **solo il traffico DNS**: la VPN instrada soltanto
l'indirizzo del DNS virtuale, il resto del traffico va direttamente in rete.
Niente intercettazione HTTPS, niente certificati, consumo minimo.

## 3. Bridge dashboard ↔ nativo

- WebView carica solo `web/` dagli assets tramite `WebViewAssetLoader`
  (`https://appassets.androidplatform.net`), mai URL esterni: la navigazione
  verso altri indirizzi viene bloccata.
- Un solo oggetto `AdzeroBridge` con metodi espliciti: `getStatus()`,
  `getStats(range)`, `setProtection(on)`, `addRule()`, `removeRule()`,
  `searchRules()`, `updateLists()`, `resetDefaults()`, `getDiagnostics()`.
- Input e output in JSON validato lato Kotlin; nessun accesso a file,
  nessuna esecuzione di comandi.
- `setProtection(true)` non attiva nulla da solo: apre la finestra di
  consenso Android (`VpnService.prepare`).

## 4. Limiti reali (da mostrare anche nell'app)

- **Richieste bloccate ≠ annunci eliminati.** Un annuncio può usare più
  richieste, o arrivare da un dominio condiviso con contenuti legittimi.
- **Statistiche per app non affidabili**: le query DNS le invia il resolver
  di sistema per conto delle app, quindi la VPN non sa con certezza quale
  app le ha generate. Per questo le schermate "app più attive / top app per
  pubblicità" delle tavole **non verranno implementate** con numeri: sarebbero
  inventati.
- Il DNS su TCP verso il server virtuale non è gestito: Android lo usa solo
  per risposte troncate, rare per gli indirizzi A/AAAA.
- Annunci serviti dallo stesso dominio del contenuto (es. YouTube): non
  bloccabili via DNS.
- App con DNS proprio (DNS-over-HTTPS, es. "DNS sicuro" di Chrome) e
  **DNS privato** di Android in modalità "nome host" scavalcano il filtro:
  l'app li rileva e lo segnala in Diagnostica.
- Una sola VPN alla volta su Android: con un'altra VPN attiva, ADZERO si ferma.
- Selezione app: Android permette o "solo queste app" o "tutte tranne
  queste", non entrambe.
- **Google Play**: le policy vietano le app che interferiscono con la
  pubblicità di altre app. Distribuzione prevista via GitHub Releases
  (ed eventualmente F-Droid), come fanno blocker simili.

## 5. Mappa requisiti → moduli

| Requisito | Python (riferimento) | Android |
|---|---|---|
| Normalizzazione domini | `engine/domains.py` | `engine/Domains.kt` |
| Parsing liste | `engine/rules.py` | `engine/Rules.kt` |
| Allowlist/blocklist, domini protetti | `engine/matcher.py` | `engine/RuleSet.kt` |
| Risposte DNS | `engine/dnsmsg.py` | `engine/DnsMessage.kt` |
| Cache | `engine/cache.py` | `engine/DnsCache.kt` |
| Statistiche | `engine/stats.py` | `engine/Stats.kt` + `data/StatsStore.kt` |
| Pacchetti IPv4/IPv6/UDP | — | `engine/IpPackets.kt` |
| Aggiornamento liste | `engine/updater.py` | `data/ListUpdater.kt` + `ListUpdateWorker.kt` |
| Servizio VPN | — | `vpn/AdzeroVpnService.kt`, `vpn/DnsTunnel.kt` |
| Dashboard | — | `web/` + `ui/AdzeroBridge.kt` |

## 6. Stato delle fasi

- [x] Fase 1 — analisi e architettura (questo file)
- [x] Fase 2 — repository, motore Python, 125 test superati; prova reale
      con la lista StevenBlack (76.147 regole)
- [x] Fase 3 — dashboard HTML/CSS/JS con ponte documentato in `docs/BRIDGE.md`;
      verificata nel browser, senza numeri dimostrativi
- [x] Fase 4 — servizio VPN Kotlin, ponte nativo, test unitari e strumentali.
      Verificato qui: motore Kotlin compilato, 22 test superati, risultati
      identici a Python sulla lista StevenBlack (76.147 regole); codice
      Android controllato contro l'SDK 35. Da verificare nella Fase 6:
      build Gradle completa e test su telefono.
- [x] Fase 5 — la dashboard legge solo dal servizio: nessun dato dimostrativo
- [ ] Fase 6 — compilazione e test su dispositivo. Fatto: revisione e
      correzioni (assets, avvio in primo piano, chiusura del ponte), controlli
      locali tutti verdi, workflow con build Gradle + test su emulatore.
      Manca: esito della build su GitHub Actions.
- [x] Fase 7 — README, guida alla compilazione e alla firma, release
      automatica su GitHub, checklist di pubblicazione, privacy, licenze,
      pagina di download per Netlify. Le release funzioneranno quando la
      Fase 6 sarà verde.

## Versione 0.2 — aggiunte

- **Tile nelle Impostazioni rapide** (`ui/AdzeroTileService.kt`) e **widget in
  home** (`ui/AdzeroWidget.kt` + `res/layout/widget_adzero.xml`): accendono e
  spengono la protezione e mostrano le richieste bloccate oggi. Se manca il
  consenso VPN aprono l'app, perché il consenso richiede una schermata.
- **Condividi ADZERO**: condivide il link alla pagina di download.
- **Esporta statistiche**: scrive un CSV (solo dati locali) e lo condivide
  tramite `FileProvider`.
- **Controlla aggiornamenti** (`data/UpdateChecker.kt`): legge le Release di
  GitHub, confronta la versione, e se ce n'è una nuova scarica l'APK (solo da
  host di GitHub, con verifica a ogni reindirizzamento) e apre l'installazione
  di Android. Limiti: l'utente deve confermare l'installazione, e l'APK nuovo
  si installa sopra il vecchio solo se firmato con la stessa chiave. Per
  questo il pulsante ha senso con le release firmate della Fase 7, non con gli
  APK di prova.

Nuovo permesso: `REQUEST_INSTALL_PACKAGES`, usato solo dal pulsante Aggiorna.
Se vuoi evitarlo, togli il permesso dal manifest e il pulsante rimanderà alla
pagina di GitHub invece di scaricare da solo.

## Android TV

Lo stesso APK gira su telefono e su TV. Il manifest dichiara
`LEANBACK_LAUNCHER`, un banner TV e il touch non obbligatorio, così l'app è
installabile su entrambi. `MainActivity.isTv()` rileva il televisore e carica
la dashboard con `?tv=1`; la dashboard attiva la classe `tv` (CSS a caratteri
grandi, fuoco verde evidente) e la navigazione a frecce del telecomando, che
sceglie l'elemento più vicino nella direzione premuta. La logica di filtraggio
è identica: il servizio VPN non cambia.
