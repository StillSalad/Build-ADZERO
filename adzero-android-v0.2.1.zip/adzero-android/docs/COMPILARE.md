# Compilare ADZERO

Ci sono due strade. La prima non richiede di installare nulla sul PC.

## A. Con GitHub (consigliata)

1. Su github.com crea un repository nuovo: pulsante verde **New**, nome
   `adzero-android`, visibilità a scelta, poi **Create repository**.
2. Nella pagina del repository vuoto clicca **uploading an existing file** e
   trascina dentro **tutto il contenuto** della cartella `adzero-android`
   (comprese le cartelle nascoste `.github` e il file `.gitignore`).
   Poi **Commit changes**.
   Se il browser non carica le cartelle nascoste, usa GitHub Desktop
   (File > Add local repository > Publish repository).
3. Apri la scheda **Actions**: parte da sola la compilazione "Build ADZERO".
   Dura circa 5–8 minuti.
4. Quando ha la spunta verde, clicca sull'esecuzione e, in fondo alla pagina
   nella sezione **Artifacts**, scarica **adzero-debug-apk** (è uno zip con
   dentro `app-debug.apk`).
5. Sul telefono: apri l'APK, consenti l'installazione da questa fonte quando
   Android lo chiede, poi **Installa**.

Se la spunta è rossa, apri il passaggio fallito e copia il messaggio
d'errore: va corretto nella Fase 6.

## B. Con Android Studio

1. Installa Android Studio (versione Ladybug o successiva).
2. **File > Open** e scegli la cartella `adzero-android/app/android`
   (non la radice del repository).
3. Attendi la fine di "Gradle sync" nella barra in basso.
4. Collega il telefono con il debug USB attivo (Impostazioni > Info telefono >
   tocca 7 volte "Numero build", poi Opzioni sviluppatore > Debug USB).
5. Premi il triangolo verde **Run 'app'**.

## Test

- Python: `python -m pytest`
- JavaScript: `node --test tests/web/domain.test.js`
- Kotlin (motore): in Android Studio, tasto destro su
  `app/src/test` > **Run 'Tests in ...'**, oppure `./gradlew testDebugUnitTest`
- Android (su telefono collegato), prima concedi il consenso VPN ai test:
  `adb shell appops set it.lollomarta.adzero ACTIVATE_VPN allow`
  poi `./gradlew connectedDebugAndroidTest`

## APK firmato per la distribuzione

L'APK di debug va bene per provare. Per darlo ad altri serve un APK
**firmato con una tua chiave**: Android accetta gli aggiornamenti solo se
sono firmati con la stessa chiave della prima installazione.

### 1. Crea la chiave (una volta sola)

In Android Studio, con il progetto aperto:
**Build > Generate Signed App Bundle or APK… > APK > Next >
Create new…**

- Key store path: una cartella **fuori** dal repository, ad esempio
  `Documenti/chiavi/adzero.jks`
- Password: scegline una robusta e salvala in un gestore di password
- Alias: `adzero`
- Validity: 30 anni
- Certificate: basta il nome (es. Lorenzo Marta)

Premi **OK**, poi **Cancel**: la chiave è creata, il resto lo fa GitHub.

> Se perdi questo file o la password non potrai più pubblicare
> aggiornamenti: chi ha l'app dovrebbe disinstallarla e reinstallarla.
> Tienine una copia di sicurezza. Non caricarlo mai nel repository.

### 2. Dai la chiave a GitHub (in modo segreto)

Trasforma il file in testo. In Windows apri **PowerShell** nella cartella
della chiave e scrivi:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("adzero.jks")) | Set-Clipboard
```

Ora il testo è negli appunti. Su GitHub, nel repository:
**Settings > Secrets and variables > Actions > New repository secret**,
e crea questi quattro secret:

| Nome | Valore |
|---|---|
| `ADZERO_KEYSTORE_BASE64` | incolla gli appunti |
| `ADZERO_KEYSTORE_PASSWORD` | la password del key store |
| `ADZERO_KEY_ALIAS` | `adzero` |
| `ADZERO_KEY_PASSWORD` | la password della chiave (se non l'hai cambiata, è la stessa) |

### 3. Pubblica una versione

Su GitHub: **Releases > Draft a new release > Choose a tag**, scrivi
`v0.1.0` e scegli **Create new tag**. Dai un titolo (es. "ADZERO 0.1.0"),
scrivi cosa c'è di nuovo e premi **Publish release**.

Il workflow "Release ADZERO" parte da solo e dopo qualche minuto allega
alla release `ADZERO-v0.1.0.apk` e `SHA256SUMS.txt`.

Per le versioni successive usa un numero più alto (`v0.1.1`, `v0.2.0`…):
il numero di versione interno cresce da solo.

## Installare su Android TV (Xiaomi TV Stick, Fire TV…)

ADZERO è la stessa app: lo stesso APK funziona su telefono e su TV. Su TV
si accorge da sola di essere su un televisore e passa alla navigazione con
il telecomando (frecce + OK), con testo più grande e il fuoco verde ben
visibile.

1. Sulla TV installa **Downloader** dallo store.
2. In Downloader apri la pagina della release
   (`github.com/StillSalad/Build-ADZERO/releases/latest`) e scarica l'APK,
   oppure, per l'APK di prova, il link diretto all'artifact.
3. Consenti l'installazione da fonti sconosciute quando la TV lo chiede, poi
   installa.
4. Apri ADZERO dalla schermata delle app (ha un banner orizzontale dedicato).
   Muoviti con le frecce, premi OK sullo scudo e accetta la VPN.

Ricorda il limite già noto: ADZERO blocca solo gli annunci che viaggiano su
domini separati dal contenuto. Dipende dall'app, quindi su alcune funziona
bene e su altre no.

Per coprire **tutti** i dispositivi di casa (TV comprese) senza installare
nulla su ciascuno, la strada migliore resta un blocco DNS di rete
(AdGuard Home / Pi-hole), ad esempio sul NAS.

## Creare la chiave di firma SENZA un PC (dal telefono)

Se non hai un computer, la chiave la crea GitHub, una volta sola.

1. Sul repository apri **Actions**.
2. Nella colonna a sinistra scegli **1 - Crea la chiave di firma**.
3. A destra premi **Run workflow**. Inserisci una **password** (almeno 8
   caratteri: scrivila e conservala, senza non potrai più aggiornare l'app) e
   il tuo nome. Premi **Run workflow**.
4. Dopo un minuto apri l'esecuzione. In fondo, in **Artifacts**, scarica
   **CHIAVE-adzero-base64**: è uno zip con un file di testo.
5. Apri quel file e copia **tutto** il testo.
6. Vai in **Settings → Secrets and variables → Actions** e crea 4 secret:
   - `ADZERO_KEYSTORE_BASE64` = il testo copiato
   - `ADZERO_KEYSTORE_PASSWORD` = la password scelta
   - `ADZERO_KEY_ALIAS` = `adzero`
   - `ADZERO_KEY_PASSWORD` = la stessa password
7. Fatto. Ora puoi pubblicare le release (vedi "APK firmato per la
   distribuzione"). Puoi anche cancellare l'esecuzione per non lasciare in
   giro il file della chiave.

> La chiave vive nei secret del repository. Tienili privati: chiunque li
> avesse potrebbe firmare un'app facendola passare per la tua.
