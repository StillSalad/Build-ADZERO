# Il ponte per i WebView vecchi viene chiamato via riflessione.
-keepclassmembers class it.lollomarta.adzero.ui.AdzeroBridge$Legacy {
    @android.webkit.JavascriptInterface <methods>;
}
