package it.lollomarta.adzero.engine

import java.net.IDN

/**
 * Normalizzazione dei domini. Port 1:1 di engine/domains.py:
 * i vettori in tests/vectors/ verificano che i due motori coincidano.
 */
object Domains {
    const val MAX_DOMAIN_LEN = 253

    private val LABEL = Regex("^[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?$")
    private val IPV4 = Regex("^(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}$")
    private val HEX_GROUP = Regex("^[0-9a-fA-F]{1,4}$")

    val IGNORED_NAMES = setOf(
        "localhost", "localhost.localdomain", "local", "broadcasthost",
        "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
        "ip6-allnodes", "ip6-allrouters", "ip6-allhosts",
    )

    /** true se la stringa è un indirizzo IPv4 o IPv6 (nessuna risoluzione DNS). */
    fun isIp(value: String): Boolean = IPV4.matches(value) || isIpv6(value)

    private fun isIpv6(value: String): Boolean {
        val v = value.substringBefore('%') // id di zona
        if (v.isEmpty() || !v.contains(':')) return false
        val dbl = v.split("::")
        if (dbl.size > 2) return false
        fun groups(part: String): List<String>? =
            if (part.isEmpty()) emptyList() else part.split(':')
        val head = groups(dbl[0]) ?: return false
        val tail = if (dbl.size == 2) groups(dbl[1]) ?: return false else emptyList()
        val all = head + tail
        var count = 0
        for ((i, g) in all.withIndex()) {
            if (i == all.lastIndex && g.contains('.')) {
                if (!IPV4.matches(g)) return false
                count += 2
            } else {
                if (!HEX_GROUP.matches(g)) return false
                count += 1
            }
        }
        return if (dbl.size == 2) count <= 7 else count == 8
    }

    fun normalize(raw: String?): String? {
        if (raw == null) return null
        var d = raw.trim().lowercase()
        if (d.isEmpty() || d.any { it.isWhitespace() }) return null
        val scheme = d.indexOf("://")
        if (scheme >= 0) d = d.substring(scheme + 3)
        for (sep in charArrayOf('/', '?', '#')) d = d.substringBefore(sep)
        if (d.contains('@') || d.startsWith("[")) return null
        if (d.startsWith("*.")) d = d.substring(2)
        if (isIp(d)) return null
        val colons = d.count { it == ':' }
        if (colons == 1) {
            val port = d.substringAfter(':')
            if (port.isEmpty() || !port.all { it in '0'..'9' }) return null
            d = d.substringBefore(':')
        } else if (colons > 1) return null
        if (d.endsWith(".")) d = d.dropLast(1)
        if (d.isEmpty() || d in IGNORED_NAMES) return null
        if (d.any { it.code > 127 }) {
            d = try {
                IDN.toASCII(d, IDN.ALLOW_UNASSIGNED).lowercase()
            } catch (e: IllegalArgumentException) {
                return null
            }
        }
        if (d.length > MAX_DOMAIN_LEN) return null
        val labels = d.split('.')
        if (labels.size < 2) return null
        if (!labels.all { LABEL.matches(it) }) return null
        if (labels.last().all { it in '0'..'9' }) return null
        return d
    }

    /** "a.b.example.com" -> a.b.example.com, b.example.com, example.com */
    fun suffixes(domain: String): List<String> {
        val out = ArrayList<String>(4)
        var idx = 0
        while (true) {
            val next = domain.indexOf('.', idx)
            if (next < 0) break
            out.add(domain.substring(idx))
            idx = next + 1
        }
        return out
    }
}
