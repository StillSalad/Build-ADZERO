package it.lollomarta.adzero.engine

import java.time.LocalDate

/**
 * Port di engine/stats.py. Conta RICHIESTE DNS, non annunci visibili.
 * Salva solo contatori giornalieri e domini bloccati, mai quelli consentiti.
 */
class Stats(private val maxTop: Int = 200, private val historyDays: Int = 30) {
    var total = 0L; private set
    var blocked = 0L; private set
    private val days = HashMap<String, LongArray>() // data -> [totali, bloccate]
    private val top = HashMap<String, Long>()

    @Synchronized
    fun record(domain: String?, isBlocked: Boolean, day: LocalDate = LocalDate.now()) {
        val e = days.getOrPut(day.toString()) { LongArray(2) }
        e[0]++; total++
        if (isBlocked) {
            e[1]++; blocked++
            if (domain != null) {
                top[domain] = (top[domain] ?: 0L) + 1
                if (top.size > maxTop * 2) {
                    val keep = topBlockedUnsafe(maxTop)
                    top.clear(); keep.forEach { top[it.first] = it.second }
                }
            }
        }
        val cutoff = day.minusDays((historyDays - 1).toLong()).toString()
        days.keys.removeAll { it < cutoff }
    }

    @Synchronized
    fun day(day: LocalDate): DayStats {
        val e = days[day.toString()] ?: LongArray(2)
        return DayStats(day.toString(), e[0], e[1])
    }

    @Synchronized
    fun history(n: Int, end: LocalDate = LocalDate.now()): List<DayStats> =
        (n - 1 downTo 0).map { day(end.minusDays(it.toLong())) }

    private fun topBlockedUnsafe(n: Int) =
        top.entries.sortedWith(compareByDescending<Map.Entry<String, Long>> { it.value }.thenBy { it.key })
            .take(n).map { it.key to it.value }

    @Synchronized fun topBlocked(n: Int = 10): List<Pair<String, Long>> = topBlockedUnsafe(n)

    @Synchronized
    fun reset() { total = 0; blocked = 0; days.clear(); top.clear() }

    /** Formato testuale semplice, senza librerie: "v1", "t <tot> <bloc>", "d <data> <tot> <bloc>", "x <conteggio> <dominio>". */
    @Synchronized
    fun serialize(): String = buildString {
        append("v1\n")
        append("t $total $blocked\n")
        days.toSortedMap().forEach { (k, v) -> append("d $k ${v[0]} ${v[1]}\n") }
        top.forEach { (k, v) -> append("x $v $k\n") }
    }

    data class DayStats(val date: String, val total: Long, val blocked: Long) {
        val percent: Double get() = percent(blocked, total)
    }

    companion object {
        fun percent(part: Long, whole: Long): Double =
            if (whole > 0) Math.round(1000.0 * part / whole) / 10.0 else 0.0

        private val DATE = Regex("^\\d{4}-\\d{2}-\\d{2}$")

        /** Dati corrotti -> statistiche vuote (mai un crash). */
        fun deserialize(text: String, maxTop: Int = 200, historyDays: Int = 30): Stats {
            val s = Stats(maxTop, historyDays)
            try {
                val lines = text.lines().filter { it.isNotBlank() }
                if (lines.firstOrNull() != "v1") return s
                for (line in lines.drop(1)) {
                    val p = line.split(' ')
                    when (p[0]) {
                        "t" -> { s.total = p[1].toLong(); s.blocked = p[2].toLong() }
                        "d" -> {
                            require(DATE.matches(p[1]))
                            val t = p[2].toLong(); val b = p[3].toLong()
                            require(t >= 0 && b in 0..t)
                            s.days[p[1]] = longArrayOf(t, b)
                        }
                        "x" -> { val c = p[1].toLong(); require(c > 0 && p.size == 3); s.top[p[2]] = c }
                        else -> throw IllegalArgumentException()
                    }
                }
                require(s.total >= 0 && s.blocked in 0..s.total)
            } catch (e: Exception) {
                return Stats(maxTop, historyDays)
            }
            return s
        }
    }
}
