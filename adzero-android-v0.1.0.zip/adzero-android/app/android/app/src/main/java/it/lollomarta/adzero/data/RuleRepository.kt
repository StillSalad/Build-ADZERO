package it.lollomarta.adzero.data

import android.content.Context
import android.util.Log
import it.lollomarta.adzero.engine.Action
import it.lollomarta.adzero.engine.Domains
import it.lollomarta.adzero.engine.Rule
import it.lollomarta.adzero.engine.RuleParser
import it.lollomarta.adzero.engine.RuleSet
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class RuleException(val code: String, message: String) : Exception(message)

data class ListSource(
    val id: String, val name: String, val url: String, val homepage: String,
    val license: String, val format: String, val enabledByDefault: Boolean,
)

/**
 * Tiene insieme regole predefinite, regole dell'utente e liste scaricate.
 * Il RuleSet attivo viene sostituito in blocco: il servizio VPN legge sempre
 * una versione completa e coerente.
 */
class RuleRepository(
    private val context: Context,
    private val settings: Settings,
    private val onReloaded: () -> Unit,
) {
    private val listsDir = File(context.filesDir, "lists")
    private val userFile = File(context.filesDir, "user_rules.rules")
    private val loader = Executors.newSingleThreadExecutor()

    @Volatile var current: RuleSet = RuleSet(); private set
    @Volatile var lastLoadError: String? = null; private set

    val sources: List<ListSource> by lazy { loadSources() }
    val defaultRules: List<Rule> by lazy {
        val text = context.assets.open("allowlist_default.txt").bufferedReader().use { it.readText() }
        RuleParser.parseText(text, plainSubdomains = true).first.map { Rule(Action.ALLOW, it.domain, it.includeSubdomains) }
    }

    private fun loadSources(): List<ListSource> {
        val json = context.assets.open("sources.json").bufferedReader().use { it.readText() }
        val arr = JSONObject(json).getJSONArray("sources")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ListSource(o.getString("id"), o.getString("name"), o.getString("url"), o.getString("homepage"),
                o.getString("license"), o.getString("format"), o.getBoolean("enabled"))
        }.filter { it.url.startsWith("https://") && it.license.isNotBlank() }
    }

    fun listFile(id: String) = File(listsDir, "$id.rules")
    fun hasAnyList() = sources.any { listFile(it.id).isFile }
    fun isEnabled(s: ListSource) = settings.isSourceEnabled(s.id, s.enabledByDefault)

    @Synchronized
    fun userRules(): List<Rule> = if (userFile.isFile) {
        try { RuleParser.parseCompiled(userFile.readText()) } catch (e: Exception) { emptyList() }
    } else emptyList()

    fun reloadAsync() { loader.execute { reload() } }

    /** Ricostruisce il RuleSet. Una lista danneggiata viene saltata, non blocca le altre. */
    fun reload() {
        val rs = RuleSet()
        rs.addAll(defaultRules)
        rs.addAll(userRules())
        var error: String? = null
        for (s in sources) {
            if (!isEnabled(s)) continue
            val f = listFile(s.id)
            if (!f.isFile) continue
            try {
                RuleParser.loadCompiledFast(f.readText(), rs)
            } catch (e: Exception) {
                Log.w(TAG, "lista ${s.id} danneggiata", e)
                error = "lists_corrupted"
                f.delete()
            }
        }
        current = rs
        lastLoadError = error
        onReloaded()
    }

    @Synchronized
    fun addUserRule(action: Action, raw: String): Rule {
        val d = Domains.normalize(raw) ?: throw RuleException("invalid_domain", "Questo non è un dominio valido.")
        if (action == Action.BLOCK && d in RuleSet.DEFAULT_GUARDED)
            throw RuleException("guarded_domain", "$d è protetto: bloccarlo romperebbe il telefono.")
        val existing = userRules()
        if (existing.any { it.domain == d && it.action == action }) throw RuleException("duplicate", "La regola esiste già.")
        val rule = Rule(action, d, true)
        saveUser(listOf(rule) + existing)
        reloadAsync()
        return rule
    }

    @Synchronized
    fun removeUserRule(action: Action, domain: String) {
        saveUser(userRules().filterNot { it.domain == domain && it.action == action })
        reloadAsync()
    }

    @Synchronized
    fun clearUserRules() { userFile.delete(); reloadAsync() }

    private fun saveUser(rules: List<Rule>) {
        Files.atomicWrite(userFile, "# ADZERO regole utente\n" + rules.joinToString("\n") { RuleParser.toCompiledLine(it) } + "\n")
    }

    /** Righe per la dashboard: regole utente e predefinite; con una ricerca anche quelle delle liste. */
    fun listRules(query: String, kind: String, limit: Int): Pair<List<Pair<Rule, String>>, Int> {
        val q = query.trim().lowercase()
        fun ok(r: Rule) = (kind == "all" || (kind == "block") == (r.action == Action.BLOCK)) && q in r.domain
        val own = userRules().filter(::ok).map { it to "user" } + defaultRules.filter(::ok).map { it to "default" }
        val fromLists = if (q.length >= 2) {
            val seen = own.map { it.first }.toSet()
            current.search(q, 500).filter { ok(it) && it !in seen }.map { it to "list" }
        } else emptyList()
        val all = own + fromLists
        return all.take(limit.coerceIn(1, 500)) to all.size
    }

    companion object { private const val TAG = "AdzeroRules" }
}
