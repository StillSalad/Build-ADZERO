package it.lollomarta.adzero.vpn

import java.util.concurrent.CopyOnWriteArrayList

/**
 * Stato reale della protezione. "ON" viene impostato solo quando il tunnel
 * è aperto e il ciclo di lettura dei pacchetti è partito.
 */
object VpnState {
    enum class Protection { OFF, STARTING, ON, STOPPING, ERROR }

    @Volatile var protection = Protection.OFF; private set
    @Volatile var errorCode: String? = null; private set

    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun set(p: Protection, error: String? = null) {
        protection = p
        errorCode = if (p == Protection.ERROR) error else null
        listeners.forEach { it() }
    }

    fun addListener(l: () -> Unit) = listeners.add(l)
    fun removeListener(l: () -> Unit) = listeners.remove(l)
}
