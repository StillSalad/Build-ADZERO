package it.lollomarta.adzero

import android.app.Application
import it.lollomarta.adzero.data.AppCatalog
import it.lollomarta.adzero.data.ListUpdateWorker
import it.lollomarta.adzero.data.RuleRepository
import it.lollomarta.adzero.data.Settings
import it.lollomarta.adzero.data.StatsStore
import it.lollomarta.adzero.engine.DnsCache
import it.lollomarta.adzero.vpn.NetworkWatcher

/** Contenitore dei componenti condivisi tra dashboard e servizio VPN. */
class AdzeroApp : Application() {
    lateinit var settings: Settings; private set
    lateinit var rules: RuleRepository; private set
    lateinit var stats: StatsStore; private set
    lateinit var network: NetworkWatcher; private set
    lateinit var apps: AppCatalog; private set
    val dnsCache = DnsCache()

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        stats = StatsStore(this)
        rules = RuleRepository(this, settings) { dnsCache.clear() }
        network = NetworkWatcher(this)
        apps = AppCatalog(this, settings)
        network.start()
        rules.reloadAsync()
        ListUpdateWorker.schedule(this, settings.autoUpdate)
        if (!rules.hasAnyList()) ListUpdateWorker.runNow(this)
    }

    companion object {
        fun from(ctx: android.content.Context) = ctx.applicationContext as AdzeroApp
    }
}
