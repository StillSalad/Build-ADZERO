package it.lollomarta.adzero.data

import java.io.File
import java.io.IOException

object Files {
    /** Scrive su un file temporaneo e poi lo rinomina: niente file a metà. */
    fun atomicWrite(target: File, text: String) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, ".tmp-" + target.name)
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IOException("impossibile salvare ${target.name}")
        }
    }
}
