package it.lollomarta.adzero.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Base64
import java.io.ByteArrayOutputStream

data class AppInfo(val packageName: String, val label: String, val icon: String?)

/** App con icona nel launcher (visibili grazie al blocco <queries> del manifest). */
class AppCatalog(private val context: Context, private val settings: Settings) {
    private val iconCache = HashMap<String, String?>()

    fun list(query: String): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = query.trim().lowercase()
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != context.packageName }
            .map { it.packageName to pm.getApplicationLabel(it).toString() }
            .filter { (pkg, label) -> q.isEmpty() || q in label.lowercase() || q in pkg }
            .sortedBy { it.second.lowercase() }
            .map { (pkg, label) -> AppInfo(pkg, label, icon(pkg)) }
    }

    @Synchronized
    private fun icon(pkg: String): String? = iconCache.getOrPut(pkg) {
        try {
            val d = context.packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 48, 48)
            d.draw(Canvas(bmp))
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    fun isInstalled(pkg: String) = try {
        context.packageManager.getApplicationInfo(pkg, 0); true
    } catch (e: Exception) { false }
}
