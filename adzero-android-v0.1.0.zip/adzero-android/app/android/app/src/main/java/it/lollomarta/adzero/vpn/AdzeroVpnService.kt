package it.lollomarta.adzero.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import it.lollomarta.adzero.AdzeroApp
import it.lollomarta.adzero.R
import it.lollomarta.adzero.ui.MainActivity
import it.lollomarta.adzero.vpn.VpnState.Protection
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * VPN locale che instrada SOLO l'indirizzo del DNS virtuale. Il resto del
 * traffico non entra nel tunnel e HTTPS non viene mai toccato.
 */
class AdzeroVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var tunnel: DnsTunnel? = null
    private var thread: Thread? = null
    private var saver: ScheduledExecutorService? = null
    private val app get() = AdzeroApp.from(this)
    private val main = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { app.settings.protectionWanted = false; shutdown(Protection.OFF); return START_NOT_STICKY }
            ACTION_RESTART -> if (tun != null) restart()
            else -> startVpn() // ACTION_START, avvio di sistema (VPN sempre attiva) o riavvio dopo kill
        }
        return START_STICKY
    }

    private fun startVpn() {
        // startForegroundService() richiede startForeground() a ogni chiamata, anche se già attivo.
        goForeground()
        if (tun != null) return
        VpnState.set(Protection.STARTING)
        val err = openTunnel()
        if (err != null) { shutdown(Protection.ERROR, err); return }
        app.settings.protectionWanted = true
        saver = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleWithFixedDelay({ app.stats.save() }, 30, 30, TimeUnit.SECONDS)
        }
    }

    /** Restituisce un codice di errore, o null se il tunnel è partito. */
    private fun openTunnel(): String? {
        if (app.settings.appMode == "include" && app.settings.selectedApps.none { app.apps.isInstalled(it) })
            return "no_apps_selected"
        val fd = try { buildTunnel() } catch (e: Exception) { Log.e(TAG, "establish", e); return "tun_failed" }
            ?: return "consent_denied" // establish() restituisce null se il permesso VPN non c'è più
        tun = fd
        val dnsServers = {
            when (app.settings.upstream) {
                "cloudflare" -> UpstreamResolver.CLOUDFLARE
                "quad9" -> UpstreamResolver.QUAD9
                else -> app.network.underlyingDnsServers().ifEmpty { UpstreamResolver.CLOUDFLARE }
            }
        }
        val t = DnsTunnel(fd, { app.rules.current }, { app.settings.blockMode }, app.stats, app.dnsCache,
            UpstreamResolver(this, dnsServers)) { VpnState.set(Protection.ON) }
        tunnel = t
        thread = Thread({
            t.run()
            // Il ciclo esce da solo solo se il tunnel si chiude in modo inatteso.
            main.post { if (tun === fd) shutdown(Protection.ERROR, "tun_failed") }
        }, "adzero-tunnel").also { it.start() }
        return null
    }

    private fun buildTunnel(): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("ADZERO")
            .setMtu(1500)
            .addAddress(ADDR4, 32).addDnsServer(DNS4).addRoute(DNS4, 32)
            .addAddress(ADDR6, 128).addDnsServer(DNS6).addRoute(DNS6, 128)
            .setBlocking(true)
            .setConfigureIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) b.setMetered(false)
        val s = app.settings
        if (s.appMode == "include") {
            s.selectedApps.forEach { pkg -> runCatching { b.addAllowedApplication(pkg) } }
        } else {
            runCatching { b.addDisallowedApplication(packageName) }
            s.selectedApps.forEach { pkg -> runCatching { b.addDisallowedApplication(pkg) } }
        }
        return b.establish()
    }

    /** Applica nuove impostazioni app: apre il nuovo tunnel prima di chiudere il vecchio. */
    private fun restart() {
        val oldTun = tun; val oldTunnel = tunnel
        tun = null
        val err = openTunnel()
        oldTunnel?.stop()
        runCatching { oldTun?.close() }
        if (err != null) shutdown(Protection.ERROR, err)
    }

    private fun shutdown(final: Protection, error: String? = null) {
        if (final == Protection.OFF) VpnState.set(Protection.STOPPING)
        tunnel?.stop(); tunnel = null
        runCatching { tun?.close() }; tun = null
        thread = null
        saver?.shutdownNow(); saver = null
        app.stats.save()
        app.dnsCache.clear()
        VpnState.set(final, error)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        // Un'altra VPN ha preso il posto di ADZERO, o l'utente l'ha disattivata dal sistema.
        app.settings.protectionWanted = false
        shutdown(Protection.ERROR, "other_vpn")
    }

    override fun onDestroy() {
        if (tun != null) shutdown(Protection.OFF)
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AdzeroVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_stop), stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
    }

    companion object {
        private const val TAG = "AdzeroVpn"
        const val ACTION_START = "it.lollomarta.adzero.START"
        const val ACTION_STOP = "it.lollomarta.adzero.STOP"
        const val ACTION_RESTART = "it.lollomarta.adzero.RESTART"
        const val ADDR4 = "10.111.222.2"
        const val DNS4 = "10.111.222.1"
        const val ADDR6 = "fd00:ad:0:0:0:0:0:2"
        const val DNS6 = "fd00:ad:0:0:0:0:0:1"
        private const val CHANNEL = "protezione"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) = ctx.startForegroundService(Intent(ctx, AdzeroVpnService::class.java).setAction(ACTION_START))
        fun stop(ctx: Context) = ctx.startService(Intent(ctx, AdzeroVpnService::class.java).setAction(ACTION_STOP))
        fun restartIfRunning(ctx: Context) {
            if (VpnState.protection == Protection.ON)
                ctx.startService(Intent(ctx, AdzeroVpnService::class.java).setAction(ACTION_RESTART))
        }
    }
}
