package it.lollomarta.adzero.engine

class DnsParseException(message: String) : Exception(message)

data class DnsQuery(val id: Int, val flags: Int, val qname: String, val qtype: Int, val qclass: Int, val questionEnd: Int)

/** Port 1:1 di engine/dnsmsg.py, più la lettura del TTL per la cache. */
object DnsMessage {
    const val QTYPE_A = 1
    const val QTYPE_AAAA = 28
    const val QCLASS_IN = 1
    const val RCODE_NOERROR = 0
    const val RCODE_SERVFAIL = 2
    const val RCODE_NXDOMAIN = 3
    const val BLOCK_TTL = 60
    private const val MAX_NAME_LEN = 255

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun u32(b: ByteArray, o: Int): Long =
        (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()

    fun parseQuery(data: ByteArray, length: Int = data.size): DnsQuery {
        if (length < 12) throw DnsParseException("pacchetto più corto dell'header")
        val id = u16(data, 0)
        val flags = u16(data, 2)
        if (flags and 0x8000 != 0) throw DnsParseException("è una risposta, non una query")
        if ((flags shr 11) and 0xF != 0) throw DnsParseException("opcode non supportato")
        if (u16(data, 4) != 1) throw DnsParseException("serve esattamente una domanda")
        var off = 12
        val sb = StringBuilder()
        var total = 0
        while (true) {
            if (off >= length) throw DnsParseException("nome troncato")
            val len = data[off].toInt() and 0xFF
            if (len == 0) { off++; break }
            if (len and 0xC0 != 0) throw DnsParseException("compressione non ammessa nella domanda")
            off++
            val end = off + len
            if (end > length) throw DnsParseException("etichetta troncata")
            total += len + 1
            if (total > MAX_NAME_LEN) throw DnsParseException("nome troppo lungo")
            if (sb.isNotEmpty()) sb.append('.')
            for (i in off until end) {
                val c = data[i].toInt() and 0xFF
                sb.append(if (c < 128) c.toChar() else '\uFFFD')
            }
            off = end
        }
        if (off + 4 > length) throw DnsParseException("domanda troncata")
        return DnsQuery(id, flags, sb.toString().lowercase(), u16(data, off), u16(data, off + 2), off + 4)
    }

    private fun header(q: DnsQuery, rcode: Int, ancount: Int): ByteArray {
        val flags = 0x8000 or (q.flags and 0x7900) or 0x0080 or (rcode and 0xF)
        return byteArrayOf(
            (q.id shr 8).toByte(), q.id.toByte(), (flags shr 8).toByte(), flags.toByte(),
            0, 1, (ancount shr 8).toByte(), ancount.toByte(), 0, 0, 0, 0,
        )
    }

    fun buildBlockedResponse(data: ByteArray, length: Int = data.size, mode: String = "null_ip"): ByteArray {
        val q = parseQuery(data, length)
        val question = data.copyOfRange(12, q.questionEnd)
        if (mode == "nxdomain") return header(q, RCODE_NXDOMAIN, 0) + question
        require(mode == "null_ip") { "modalità sconosciuta: $mode" }
        if (q.qclass == QCLASS_IN && (q.qtype == QTYPE_A || q.qtype == QTYPE_AAAA)) {
            val rdlen = if (q.qtype == QTYPE_A) 4 else 16
            val answer = byteArrayOf(
                0xC0.toByte(), 0x0C, (q.qtype shr 8).toByte(), q.qtype.toByte(), 0, QCLASS_IN.toByte(),
                0, 0, (BLOCK_TTL shr 8).toByte(), BLOCK_TTL.toByte(), 0, rdlen.toByte(),
            ) + ByteArray(rdlen)
            return header(q, RCODE_NOERROR, 1) + question + answer
        }
        return header(q, RCODE_NOERROR, 0) + question
    }

    fun buildServfail(data: ByteArray, length: Int = data.size): ByteArray {
        val q = parseQuery(data, length)
        return header(q, RCODE_SERVFAIL, 0) + data.copyOfRange(12, q.questionEnd)
    }

    fun withId(response: ByteArray, newId: Int): ByteArray {
        if (response.size < 12) throw DnsParseException("risposta troppo corta")
        val out = response.copyOf()
        out[0] = (newId shr 8).toByte(); out[1] = newId.toByte()
        return out
    }

    fun rcode(response: ByteArray): Int = if (response.size >= 4) response[3].toInt() and 0xF else -1
    fun isTruncated(response: ByteArray): Boolean = response.size >= 3 && (response[2].toInt() and 0x02) != 0

    private fun skipName(b: ByteArray, start: Int): Int {
        var off = start
        var steps = 0
        while (true) {
            if (off >= b.size || ++steps > 128) throw DnsParseException("nome non valido")
            val len = b[off].toInt() and 0xFF
            when {
                len == 0 -> return off + 1
                len and 0xC0 == 0xC0 -> return off + 2
                len and 0xC0 != 0 -> throw DnsParseException("etichetta non valida")
                else -> off += len + 1
            }
        }
    }

    /**
     * TTL minimo tra le risposte (sezioni answer e authority), utile alla cache.
     * Restituisce null se la risposta non è leggibile o non ha record.
     */
    fun minTtl(response: ByteArray): Int? {
        return try {
            if (response.size < 12 || u16(response, 4) != 1) return null
            val records = u16(response, 6) + u16(response, 8)
            var off = skipName(response, 12) + 4
            var min: Long? = null
            repeat(records) {
                off = skipName(response, off)
                if (off + 10 > response.size) return null
                val ttl = u32(response, off + 4)
                val rdlen = u16(response, off + 8)
                off += 10 + rdlen
                if (off > response.size) return null
                min = if (min == null) ttl else minOf(min!!, ttl)
            }
            min?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt()
        } catch (e: DnsParseException) {
            null
        }
    }

    fun buildQuery(qname: String, qtype: Int = QTYPE_A, id: Int = 0x1234): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        out.write(byteArrayOf((id shr 8).toByte(), id.toByte(), 1, 0, 0, 1, 0, 0, 0, 0, 0, 0))
        for (label in qname.trimEnd('.').split('.')) {
            val raw = label.toByteArray(Charsets.US_ASCII)
            require(raw.size in 1..63) { "etichetta non valida" }
            out.write(raw.size); out.write(raw)
        }
        out.write(byteArrayOf(0, (qtype shr 8).toByte(), qtype.toByte(), 0, QCLASS_IN.toByte()))
        return out.toByteArray()
    }
}
