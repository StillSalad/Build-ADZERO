package it.lollomarta.adzero.engine

/** Un datagramma UDP letto dal tunnel (IPv4 o IPv6). */
class UdpPacket(
    val ipVersion: Int,
    val src: ByteArray,
    val dst: ByteArray,
    val srcPort: Int,
    val dstPort: Int,
    val payload: ByteArray,
)

/**
 * Lettura e scrittura minimale di pacchetti IP/UDP per il tunnel.
 * Gestisce solo ciò che serve al DNS: niente frammenti, niente header di estensione IPv6.
 */
object IpPackets {
    const val PROTO_UDP = 17

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    fun parseUdp(buf: ByteArray, length: Int): UdpPacket? {
        if (length < 1) return null
        return when ((buf[0].toInt() and 0xF0) shr 4) {
            4 -> parseV4(buf, length)
            6 -> parseV6(buf, length)
            else -> null
        }
    }

    private fun parseV4(b: ByteArray, len: Int): UdpPacket? {
        if (len < 28) return null
        val ihl = (b[0].toInt() and 0x0F) * 4
        val totalLen = u16(b, 2)
        if (ihl < 20 || totalLen > len || totalLen < ihl + 8) return null
        val fragment = u16(b, 6)
        if (fragment and 0x3FFF != 0) return null // MF o offset: frammento
        if (b[9].toInt() and 0xFF != PROTO_UDP) return null
        return udp(4, b.copyOfRange(12, 16), b.copyOfRange(16, 20), b, ihl, totalLen)
    }

    private fun parseV6(b: ByteArray, len: Int): UdpPacket? {
        if (len < 48) return null
        val payloadLen = u16(b, 4)
        if (40 + payloadLen > len) return null
        if (b[6].toInt() and 0xFF != PROTO_UDP) return null
        return udp(6, b.copyOfRange(8, 24), b.copyOfRange(24, 40), b, 40, 40 + payloadLen)
    }

    private fun udp(v: Int, src: ByteArray, dst: ByteArray, b: ByteArray, start: Int, end: Int): UdpPacket? {
        val udpLen = u16(b, start + 4)
        if (udpLen < 8 || start + udpLen > end) return null
        return UdpPacket(v, src, dst, u16(b, start), u16(b, start + 2), b.copyOfRange(start + 8, start + udpLen))
    }

    /** Risposta al pacchetto [req]: indirizzi e porte invertiti, checksum calcolati. */
    fun buildUdpResponse(req: UdpPacket, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size
        val udpPart = ByteArray(udpLen)
        put16(udpPart, 0, req.dstPort); put16(udpPart, 2, req.srcPort); put16(udpPart, 4, udpLen)
        payload.copyInto(udpPart, 8)
        val src = req.dst; val dst = req.src
        var sum = checksum(pseudoHeader(req.ipVersion, src, dst, udpLen) + udpPart)
        if (sum == 0) sum = 0xFFFF
        put16(udpPart, 6, sum)

        return if (req.ipVersion == 4) {
            val h = ByteArray(20)
            h[0] = 0x45; put16(h, 2, 20 + udpLen); put16(h, 6, 0x4000)
            h[8] = 64; h[9] = PROTO_UDP.toByte()
            src.copyInto(h, 12); dst.copyInto(h, 16)
            put16(h, 10, checksum(h))
            h + udpPart
        } else {
            val h = ByteArray(40)
            h[0] = 0x60; put16(h, 4, udpLen); h[6] = PROTO_UDP.toByte(); h[7] = 64
            src.copyInto(h, 8); dst.copyInto(h, 24)
            h + udpPart
        }
    }

    private fun pseudoHeader(v: Int, src: ByteArray, dst: ByteArray, udpLen: Int): ByteArray =
        if (v == 4) src + dst + byteArrayOf(0, PROTO_UDP.toByte(), (udpLen shr 8).toByte(), udpLen.toByte())
        else src + dst + byteArrayOf(0, 0, (udpLen shr 8).toByte(), udpLen.toByte(), 0, 0, 0, PROTO_UDP.toByte())

    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }

    /** Checksum Internet (RFC 1071). Applicato a un blocco che lo contiene già, dà 0. */
    fun checksum(data: ByteArray): Int {
        var sum = 0L
        var i = 0
        while (i + 1 < data.size) { sum += u16(data, i); i += 2 }
        if (i < data.size) sum += (data[i].toInt() and 0xFF) shl 8
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }
}
