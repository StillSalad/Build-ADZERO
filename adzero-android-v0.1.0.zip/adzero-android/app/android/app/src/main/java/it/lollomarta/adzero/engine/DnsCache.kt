package it.lollomarta.adzero.engine

/** Port di engine/cache.py: TTL limitato + LRU. Thread-safe. */
class DnsCache(
    private val maxEntries: Int = 2000,
    private val minTtl: Int = 10,
    private val maxTtl: Int = 3600,
    private val clockMs: () -> Long = { System.nanoTime() / 1_000_000 },
) {
    init { require(maxEntries >= 1 && minTtl >= 0 && maxTtl >= minTtl) { "parametri cache non validi" } }

    private data class Key(val qname: String, val qtype: Int)
    private class Entry(val expiresAt: Long, val response: ByteArray)

    private val map = object : LinkedHashMap<Key, Entry>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Key, Entry>?) = size > maxEntries
    }
    var hits = 0L; private set
    var misses = 0L; private set

    @Synchronized
    fun put(qname: String, qtype: Int, response: ByteArray, ttl: Int) {
        val t = ttl.coerceIn(minTtl, maxTtl)
        map[Key(qname, qtype)] = Entry(clockMs() + t * 1000L, response.copyOf())
    }

    @Synchronized
    fun get(qname: String, qtype: Int): ByteArray? {
        val k = Key(qname, qtype)
        val e = map[k]
        if (e == null) { misses++; return null }
        if (clockMs() >= e.expiresAt) { map.remove(k); misses++; return null }
        hits++
        return e.response.copyOf()
    }

    @Synchronized fun clear() = map.clear()
    @Synchronized fun size() = map.size
}
