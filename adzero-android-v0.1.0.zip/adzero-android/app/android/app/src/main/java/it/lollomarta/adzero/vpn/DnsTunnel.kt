package it.lollomarta.adzero.vpn

import android.os.ParcelFileDescriptor
import android.util.Log
import it.lollomarta.adzero.data.StatsStore
import it.lollomarta.adzero.engine.DnsCache
import it.lollomarta.adzero.engine.DnsMessage
import it.lollomarta.adzero.engine.DnsParseException
import it.lollomarta.adzero.engine.IpPackets
import it.lollomarta.adzero.engine.RuleSet
import it.lollomarta.adzero.engine.UdpPacket
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * Ciclo principale: legge i pacchetti DNS dal tunnel, decide, risponde.
 * Le richieste bloccate ricevono subito una risposta locale; quelle consentite
 * passano dalla cache o vengono inoltrate al DNS reale su un thread separato.
 */
class DnsTunnel(
    private val tun: ParcelFileDescriptor,
    private val rules: () -> RuleSet,
    private val blockMode: () -> String,
    private val stats: StatsStore,
    private val cache: DnsCache,
    private val upstream: UpstreamResolver,
    private val onRunning: () -> Unit,
) {
    private val output = FileOutputStream(tun.fileDescriptor)
    private val workers = ThreadPoolExecutor(2, 16, 30, TimeUnit.SECONDS,
        ArrayBlockingQueue(256), ThreadPoolExecutor.DiscardOldestPolicy())
    @Volatile private var running = true

    fun run() {
        val input = FileInputStream(tun.fileDescriptor)
        val buf = ByteArray(32767)
        onRunning()
        while (running) {
            val n = try { input.read(buf) } catch (e: IOException) { if (running) Log.w(TAG, "lettura tunnel", e); break }
            if (n <= 0) continue
            val packet = IpPackets.parseUdp(buf, n) ?: continue
            if (packet.dstPort != 53) continue
            try { handle(packet) } catch (e: Exception) { Log.w(TAG, "pacchetto scartato", e) }
        }
        workers.shutdownNow()
    }

    fun stop() { running = false; workers.shutdownNow() }

    private fun handle(packet: UdpPacket) {
        val query = try { DnsMessage.parseQuery(packet.payload) } catch (e: DnsParseException) { return }
        val decision = rules().check(query.qname)
        stats.record(decision.domain, decision.blocked)

        if (decision.blocked) {
            write(packet, DnsMessage.buildBlockedResponse(packet.payload, mode = blockMode()))
            return
        }
        cache.get(query.qname, query.qtype)?.let { write(packet, DnsMessage.withId(it, query.id)); return }

        workers.execute {
            val resp = upstream.resolve(packet.payload)
            if (resp == null) {
                write(packet, DnsMessage.buildServfail(packet.payload))
                return@execute
            }
            val rcode = DnsMessage.rcode(resp)
            if (!DnsMessage.isTruncated(resp) && (rcode == DnsMessage.RCODE_NOERROR || rcode == DnsMessage.RCODE_NXDOMAIN)) {
                val ttl = DnsMessage.minTtl(resp) ?: if (rcode == DnsMessage.RCODE_NXDOMAIN) 60 else null
                if (ttl != null) cache.put(query.qname, query.qtype, resp, ttl)
            }
            write(packet, resp)
        }
    }

    private fun write(req: UdpPacket, dns: ByteArray) {
        val out = IpPackets.buildUdpResponse(req, dns)
        synchronized(output) {
            try { output.write(out) } catch (e: IOException) { if (running) Log.w(TAG, "scrittura tunnel", e) }
        }
    }

    companion object { private const val TAG = "AdzeroTunnel" }
}
