package it.lollomarta.adzero.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Osserva le reti fisiche (non VPN): serve per sapere se c'è connessione,
 * quali server DNS usa la rete e se il DNS privato "rigoroso" è attivo.
 */
class NetworkWatcher(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val links = ConcurrentHashMap<Network, LinkProperties>()
    private val validated = ConcurrentHashMap<Network, Boolean>()

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) { links[network] = lp; changed() }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            validated[network] = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED); changed()
        }
        override fun onLost(network: Network) { links.remove(network); validated.remove(network); changed() }
    }

    @Volatile var onChange: (() -> Unit)? = null
    private fun changed() { onChange?.invoke() }

    fun start() {
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        cm.registerNetworkCallback(req, callback)
    }

    val isAvailable: Boolean get() = links.isNotEmpty()

    /** Server DNS delle reti fisiche, IPv4 prima (funzionano ovunque). */
    fun underlyingDnsServers(): List<InetAddress> {
        val ordered = links.entries.sortedByDescending { validated[it.key] == true }
        return ordered.flatMap { it.value.dnsServers }
            .filterNot { it.isLoopbackAddress || it.isAnyLocalAddress || (it.hostAddress ?: "") in VIRTUAL_DNS }
            .distinct()
            .sortedBy { if (it is Inet4Address) 0 else 1 }
    }

    /** DNS privato impostato su un nome host: Android lo usa al posto del nostro filtro. */
    val privateDnsStrict: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            links.values.any { it.isPrivateDnsActive && it.privateDnsServerName != null }

    companion object {
        val VIRTUAL_DNS = setOf(AdzeroVpnService.DNS4, AdzeroVpnService.DNS6, "fd00:ad::1")
    }
}
