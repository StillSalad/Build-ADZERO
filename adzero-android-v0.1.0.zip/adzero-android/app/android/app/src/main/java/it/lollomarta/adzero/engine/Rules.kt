package it.lollomarta.adzero.engine

enum class Action { BLOCK, ALLOW }

data class Rule(val action: Action, val domain: String, val includeSubdomains: Boolean)

data class ParseReport(
    var totalLines: Int = 0,
    var rules: Int = 0,
    var comments: Int = 0,
    var ignored: Int = 0,
    var invalid: Int = 0,
    var unsupported: Int = 0,
)

enum class LineStatus { RULE, EMPTY, COMMENT, IGNORED, INVALID, UNSUPPORTED }

/** Port 1:1 di engine/rules.py. */
object RuleParser {
    val SINK_ADDRESSES = setOf("0.0.0.0", "127.0.0.1", "::", "::1", "0:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:1")
    private val DNS_SAFE_MODIFIERS = setOf("important", "all", "document", "doc")
    private val COSMETIC = listOf("##", "#@#", "#?#", "#$#", "#%#")
    private val WS = Regex("\\s+")

    private fun plainDomain(token: String): Pair<String?, Boolean> {
        val wildcard = token.startsWith("*.")
        val body = if (wildcard) token.substring(2) else token
        if (body.any { it in "/:*?#@[]^|$" }) return null to wildcard
        return Domains.normalize(body) to wildcard
    }

    fun parseLine(line: String, plainSubdomains: Boolean = false): Pair<List<Rule>, LineStatus> {
        var s = line.trim()
        if (s.isEmpty()) return emptyList<Rule>() to LineStatus.EMPTY
        if (s[0] in "!#[") return emptyList<Rule>() to LineStatus.COMMENT
        if (COSMETIC.any { s.contains(it) }) return emptyList<Rule>() to LineStatus.UNSUPPORTED
        if (s.contains('#')) {
            s = s.substringBefore('#').trim()
            if (s.isEmpty()) return emptyList<Rule>() to LineStatus.COMMENT
        }

        val allow = s.startsWith("@@")
        var body = if (allow) s.substring(2) else s
        val action = if (allow) Action.ALLOW else Action.BLOCK

        if (body.startsWith("||")) {
            body = body.substring(2)
            if (body.contains('$')) {
                val mods = body.substringAfter('$').split(',')
                    .map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
                body = body.substringBefore('$')
                if ((mods - DNS_SAFE_MODIFIERS).isNotEmpty()) return emptyList<Rule>() to LineStatus.UNSUPPORTED
            }
            body = when {
                body.endsWith("^|") -> body.dropLast(2)
                body.endsWith("^") -> body.dropLast(1)
                else -> body
            }
            if (body.any { it in "/*^|?:" }) return emptyList<Rule>() to LineStatus.UNSUPPORTED
            val d = Domains.normalize(body) ?: return emptyList<Rule>() to LineStatus.INVALID
            return listOf(Rule(action, d, true)) to LineStatus.RULE
        }

        val tokens = body.trim().split(WS).filter { it.isNotEmpty() }

        if (tokens.size >= 2 && Domains.isIp(tokens[0])) {
            if (allow) return emptyList<Rule>() to LineStatus.INVALID
            if (tokens[0] !in SINK_ADDRESSES) return emptyList<Rule>() to LineStatus.UNSUPPORTED
            val rules = ArrayList<Rule>()
            var ignored = 0
            for (tok in tokens.drop(1)) {
                if (tok.lowercase().trimEnd('.') in Domains.IGNORED_NAMES) { ignored++; continue }
                plainDomain(tok).first?.let { rules.add(Rule(Action.BLOCK, it, false)) }
            }
            if (rules.isNotEmpty()) return rules to LineStatus.RULE
            return emptyList<Rule>() to (if (ignored > 0) LineStatus.IGNORED else LineStatus.INVALID)
        }

        if (tokens.size == 1) {
            val tok = tokens[0]
            if (tok.lowercase().trimEnd('.') in Domains.IGNORED_NAMES) return emptyList<Rule>() to LineStatus.IGNORED
            val (d, wildcard) = plainDomain(tok)
            if (d == null) return emptyList<Rule>() to LineStatus.INVALID
            return listOf(Rule(action, d, wildcard || plainSubdomains)) to LineStatus.RULE
        }
        return emptyList<Rule>() to LineStatus.INVALID
    }

    /** Divide le righe come str.splitlines() di Python. */
    fun splitLines(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\r' || c == '\n' || c == '\u000B' || c == '\u000C' || c == '\u001C' ||
                c == '\u001D' || c == '\u001E' || c == '\u0085' || c == '\u2028' || c == '\u2029'
            ) {
                out.add(sb.toString()); sb.setLength(0)
                if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
            } else sb.append(c)
            i++
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    fun parseText(text: String, plainSubdomains: Boolean = false): Pair<List<Rule>, ParseReport> {
        val report = ParseReport()
        val seen = LinkedHashSet<Rule>()
        for (line in splitLines(text)) {
            report.totalLines++
            val (rules, status) = parseLine(line, plainSubdomains)
            when (status) {
                LineStatus.RULE -> seen.addAll(rules)
                LineStatus.COMMENT -> report.comments++
                LineStatus.IGNORED -> report.ignored++
                LineStatus.INVALID -> report.invalid++
                LineStatus.UNSUPPORTED -> report.unsupported++
                LineStatus.EMPTY -> Unit
            }
        }
        report.rules = seen.size
        return seen.toList() to report
    }

    // ---- Formato compilato, identico a quello scritto da engine/updater.py ----

    fun toCompiledLine(rule: Rule): String =
        (if (rule.action == Action.BLOCK) "B" else "A") + (if (rule.includeSubdomains) "*" else "") + " " + rule.domain

    private val FAST_DOMAIN = Regex("^[a-z0-9_.-]{3,253}$")

    /**
     * Lettura veloce dei file compilati scritti da ADZERO stesso (già validati
     * al momento del download). Controllo leggero: se una riga non torna,
     * l'intero file viene rifiutato con un'eccezione.
     */
    fun loadCompiledFast(text: String, into: RuleSet) {
        var start = 0
        val len = text.length
        while (start < len) {
            var end = text.indexOf('\n', start)
            if (end < 0) end = len
            val line = text.substring(start, end).trimEnd('\r')
            start = end + 1
            if (line.isEmpty() || line[0] == '#') continue
            val sp = line.indexOf(' ')
            require(sp in 1..2) { "riga compilata non valida" }
            val kind = line.substring(0, sp)
            val domain = line.substring(sp + 1)
            require(FAST_DOMAIN.matches(domain) && '.' in domain) { "dominio non valido nel file compilato" }
            val action = when (kind[0]) { 'B' -> Action.BLOCK; 'A' -> Action.ALLOW; else -> throw IllegalArgumentException("tipo") }
            require(kind.length == 1 || kind[1] == '*') { "tipo non valido" }
            into.add(Rule(action, domain, kind.length == 2))
        }
    }

    fun parseCompiled(text: String): List<Rule> {
        val out = ArrayList<Rule>()
        for (raw in splitLines(text)) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val parts = line.split(WS)
            require(parts.size == 2 && parts[0] in setOf("B", "B*", "A", "A*")) { "riga compilata non valida: $line" }
            val d = Domains.normalize(parts[1])
            require(d != null && d == parts[1]) { "dominio non canonico: ${parts[1]}" }
            out.add(Rule(if (parts[0][0] == 'B') Action.BLOCK else Action.ALLOW, d, parts[0].endsWith("*")))
        }
        return out
    }
}
