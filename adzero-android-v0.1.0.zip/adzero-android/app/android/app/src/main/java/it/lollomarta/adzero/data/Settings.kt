package it.lollomarta.adzero.data

import android.content.Context

/** Impostazioni persistenti (SharedPreferences), con valori sempre validati. */
class Settings(context: Context) {
    private val p = context.getSharedPreferences("adzero", Context.MODE_PRIVATE)

    var theme: String
        get() = p.getString("theme", "system").takeIf { it in THEMES } ?: "system"
        set(v) { require(v in THEMES); p.edit().putString("theme", v).apply() }

    var autoUpdate: Boolean
        get() = p.getBoolean("autoUpdate", true)
        set(v) = p.edit().putBoolean("autoUpdate", v).apply()

    var blockMode: String
        get() = p.getString("blockMode", "null_ip").takeIf { it in BLOCK_MODES } ?: "null_ip"
        set(v) { require(v in BLOCK_MODES); p.edit().putString("blockMode", v).apply() }

    var upstream: String
        get() = p.getString("upstream", "auto").takeIf { it in UPSTREAMS } ?: "auto"
        set(v) { require(v in UPSTREAMS); p.edit().putString("upstream", v).apply() }

    var appMode: String
        get() = p.getString("appMode", "exclude").takeIf { it in APP_MODES } ?: "exclude"
        set(v) { require(v in APP_MODES); p.edit().putString("appMode", v).apply() }

    var selectedApps: Set<String>
        get() = p.getStringSet("selectedApps", emptySet())!!.toSet()
        set(v) = p.edit().putStringSet("selectedApps", v).apply()

    /** L'utente vuole la protezione attiva (per ripristinarla dopo un riavvio del servizio). */
    var protectionWanted: Boolean
        get() = p.getBoolean("protectionWanted", false)
        set(v) = p.edit().putBoolean("protectionWanted", v).apply()

    fun isSourceEnabled(id: String, default: Boolean) = p.getBoolean("src.$id.enabled", default)
    fun setSourceEnabled(id: String, on: Boolean) = p.edit().putBoolean("src.$id.enabled", on).apply()
    fun sourceLastError(id: String): String? = p.getString("src.$id.error", null)
    fun setSourceLastError(id: String, msg: String?) = p.edit().putString("src.$id.error", msg).apply()

    fun resetToDefaults() {
        val keepSources = p.all.keys.filter { it.startsWith("src.") && it.endsWith(".error") }
        p.edit().apply {
            p.all.keys.filter { it !in keepSources }.forEach { remove(it) }
        }.apply()
    }

    companion object {
        val THEMES = setOf("system", "dark", "light")
        val BLOCK_MODES = setOf("null_ip", "nxdomain")
        val UPSTREAMS = setOf("auto", "cloudflare", "quad9")
        val APP_MODES = setOf("exclude", "include")
    }
}
