package it.lollomarta.adzero.data

import android.content.Context
import it.lollomarta.adzero.AdzeroApp
import it.lollomarta.adzero.engine.RuleParser
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.time.Instant
import java.time.temporal.ChronoUnit

data class UpdateResult(val id: String, val ok: Boolean, val rules: Int, val message: String)

/** Port di engine/updater.py: solo HTTPS, limite di dimensione, minimo di regole, scrittura atomica. */
object ListUpdater {
    private const val MAX_BYTES = 30 * 1024 * 1024
    private const val MIN_RULES = 100

    @Synchronized
    fun updateAll(context: Context): List<UpdateResult> {
        val app = AdzeroApp.from(context)
        val repo = app.rules
        val results = repo.sources.filter { repo.isEnabled(it) }.map { update(context, it) }
        repo.reload()
        return results
    }

    private fun update(context: Context, src: ListSource): UpdateResult {
        val app = AdzeroApp.from(context)
        val raw = try {
            download(src.url)
        } catch (e: Exception) {
            val msg = "Download non riuscito: ${e.message ?: e.javaClass.simpleName}"
            app.settings.setSourceLastError(src.id, msg)
            return UpdateResult(src.id, false, 0, msg)
        }
        val (rules, report) = RuleParser.parseText(String(raw, Charsets.UTF_8))
        if (rules.size < MIN_RULES) {
            val msg = "Lista scartata: solo ${rules.size} regole valide. Resta la versione precedente."
            app.settings.setSourceLastError(src.id, msg)
            return UpdateResult(src.id, false, rules.size, msg)
        }
        val sha = MessageDigest.getInstance("SHA-256").digest(raw).joinToString("") { "%02x".format(it) }
        val header = listOf(
            "# ADZERO compiled list v1",
            "# source: ${src.id}",
            "# name: ${src.name}",
            "# url: ${src.url}",
            "# license: ${src.license}",
            "# homepage: ${src.homepage}",
            "# fetched: ${Instant.now().truncatedTo(ChronoUnit.SECONDS)}",
            "# sha256: $sha",
            "# report: ${JSONObject().put("total_lines", report.totalLines).put("rules", report.rules)}",
        )
        Files.atomicWrite(app.rules.listFile(src.id),
            (header + rules.map { RuleParser.toCompiledLine(it) }).joinToString("\n") + "\n")
        app.settings.setSourceLastError(src.id, null)
        return UpdateResult(src.id, true, rules.size, "Aggiornata")
    }

    private fun download(url: String): ByteArray {
        require(url.startsWith("https://")) { "solo https" }
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "ADZERO-list-updater/0.1")
        try {
            if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
            if (conn.url.protocol != "https") throw java.io.IOException("reindirizzamento non sicuro")
            val out = ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) throw java.io.IOException("lista troppo grande")
                }
            }
            return out.toByteArray()
        } finally {
            conn.disconnect()
        }
    }

    /** Data di scaricamento letta dall'intestazione del file compilato. */
    fun fetchedAt(context: Context, id: String): String? {
        val f = AdzeroApp.from(context).rules.listFile(id)
        if (!f.isFile) return null
        return f.bufferedReader().useLines { lines ->
            lines.take(12).firstOrNull { it.startsWith("# fetched: ") }?.removePrefix("# fetched: ")
        }
    }

    fun ruleCount(context: Context, id: String): Int {
        val f = AdzeroApp.from(context).rules.listFile(id)
        if (!f.isFile) return 0
        return f.bufferedReader().useLines { l -> l.count { it.isNotEmpty() && it[0] != '#' } }
    }
}
