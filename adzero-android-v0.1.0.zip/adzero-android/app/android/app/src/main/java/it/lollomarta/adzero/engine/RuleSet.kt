package it.lollomarta.adzero.engine

data class Decision(val blocked: Boolean, val reason: String, val domain: String? = null, val rule: Rule? = null)

/**
 * Port 1:1 di engine/matcher.py. Immutabile dopo la costruzione: il servizio VPN
 * ne sostituisce il riferimento in blocco quando le liste cambiano.
 */
class RuleSet(private val guarded: Set<String> = DEFAULT_GUARDED) {
    private val blockExact = HashSet<String>()
    private val blockSub = HashSet<String>()
    private val allowExact = HashSet<String>()
    private val allowSub = HashSet<String>()
    val rejected = ArrayList<Pair<Rule, String>>()

    fun add(rule: Rule): Boolean {
        if (rule.action == Action.BLOCK && rule.domain in guarded) {
            rejected.add(rule to "dominio protetto")
            return false
        }
        val target = when (rule.action) {
            Action.BLOCK -> if (rule.includeSubdomains) blockSub else blockExact
            Action.ALLOW -> if (rule.includeSubdomains) allowSub else allowExact
        }
        target.add(rule.domain)
        return true
    }

    fun addAll(rules: Iterable<Rule>): Int = rules.count { add(it) }

    val blockedDomainCount: Int get() = (blockExact + blockSub).size
    val allowedDomainCount: Int get() = (allowExact + allowSub).size

    fun check(rawDomain: String?): Decision {
        val d = Domains.normalize(rawDomain) ?: return Decision(false, "invalid_domain")
        val suffixes = Domains.suffixes(d)
        if (d in allowExact) return Decision(false, "allowlist", d, Rule(Action.ALLOW, d, false))
        for (s in suffixes) if (s in allowSub) return Decision(false, "allowlist", d, Rule(Action.ALLOW, s, true))
        if (d in blockExact) return Decision(true, "blocklist", d, Rule(Action.BLOCK, d, false))
        for (s in suffixes) if (s in blockSub) return Decision(true, "blocklist", d, Rule(Action.BLOCK, s, true))
        return Decision(false, "no_match", d)
    }

    fun search(query: String, limit: Int = 50): List<Rule> {
        val q = query.trim().lowercase()
        val out = ArrayList<Rule>()
        val groups = listOf(
            Triple(allowExact, Action.ALLOW, false), Triple(allowSub, Action.ALLOW, true),
            Triple(blockExact, Action.BLOCK, false), Triple(blockSub, Action.BLOCK, true),
        )
        for ((set, action, sub) in groups) {
            for (d in set.filter { q in it }.sorted()) {
                out.add(Rule(action, d, sub))
                if (out.size >= limit) return out
            }
        }
        return out
    }

    companion object {
        val DEFAULT_GUARDED = setOf(
            "co.uk", "org.uk", "com.au", "com.br", "co.jp", "co.in", "com.cn",
            "github.io", "blogspot.com", "herokuapp.com", "netlify.app",
            "google.com", "googleapis.com", "gstatic.com", "android.com",
            "googleusercontent.com", "gvt1.com", "youtube.com", "apple.com",
            "icloud.com", "microsoft.com", "windows.net", "amazonaws.com",
            "cloudfront.net", "akamaihd.net", "akamaized.net", "fastly.net",
            "cloudflare.com", "github.com", "githubusercontent.com",
        )
    }
}
