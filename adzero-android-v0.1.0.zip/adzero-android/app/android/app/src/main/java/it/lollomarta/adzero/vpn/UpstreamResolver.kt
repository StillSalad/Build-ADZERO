package it.lollomarta.adzero.vpn

import android.net.VpnService
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Inoltra le richieste consentite al server DNS reale. Ogni socket viene
 * "protetto": il suo traffico esce dalla rete fisica, non rientra nel tunnel.
 */
class UpstreamResolver(
    private val service: VpnService?,
    private val servers: () -> List<InetAddress>,
) {
    fun resolve(query: ByteArray, timeoutMs: Int = 4000): ByteArray? {
        for (server in servers().take(3)) {
            try {
                DatagramSocket().use { s ->
                    if (service != null && !service.protect(s)) throw IOException("protect() rifiutato")
                    s.soTimeout = timeoutMs
                    s.send(DatagramPacket(query, query.size, server, 53))
                    val buf = ByteArray(4096)
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    if (p.length >= 12 && buf[0] == query[0] && buf[1] == query[1]) return buf.copyOf(p.length)
                }
            } catch (e: IOException) {
                continue // timeout o rete irraggiungibile: prova il server successivo
            }
        }
        return null
    }

    companion object {
        private fun ips(vararg s: String) = s.map { InetAddress.getByName(it) } // solo letterali IP: nessuna risoluzione

        val CLOUDFLARE: List<InetAddress> by lazy { ips("1.1.1.1", "1.0.0.1", "2606:4700:4700::1111") }
        val QUAD9: List<InetAddress> by lazy { ips("9.9.9.9", "149.112.112.112", "2620:fe::fe") }
    }
}
