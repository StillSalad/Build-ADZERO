package it.lollomarta.adzero.data

import android.content.Context
import it.lollomarta.adzero.engine.Stats
import java.io.File

/** Statistiche in memoria, salvate su file privato dell'app. Mai inviate fuori dal telefono. */
class StatsStore(context: Context) {
    private val file = File(context.filesDir, "stats.txt")
    @Volatile private var dirty = false

    val stats: Stats = try {
        if (file.isFile) Stats.deserialize(file.readText()) else Stats()
    } catch (e: Exception) {
        Stats()
    }

    fun record(domain: String?, blocked: Boolean) {
        stats.record(if (blocked) domain else null, blocked)
        dirty = true
    }

    @Synchronized
    fun save() {
        if (!dirty) return
        Files.atomicWrite(file, stats.serialize())
        dirty = false
    }

    @Synchronized
    fun reset() {
        stats.reset()
        dirty = true
        save()
    }
}
