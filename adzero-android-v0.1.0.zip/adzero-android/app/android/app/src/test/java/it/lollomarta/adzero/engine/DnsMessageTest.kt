package it.lollomarta.adzero.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class DnsMessageTest {
    private fun hdr(r: ByteArray, i: Int) = ((r[i * 2].toInt() and 0xFF) shl 8) or (r[i * 2 + 1].toInt() and 0xFF)

    @Test
    fun parsesQuery() {
        val q = DnsMessage.parseQuery(DnsMessage.buildQuery("Ads.Example.com", DnsMessage.QTYPE_AAAA, 7))
        assertEquals(7, q.id); assertEquals("ads.example.com", q.qname); assertEquals(28, q.qtype)
    }

    @Test
    fun blockedAReturnsZeroIp() {
        val query = DnsMessage.buildQuery("ads.example.com", DnsMessage.QTYPE_A, 0xBEEF)
        val r = DnsMessage.buildBlockedResponse(query)
        assertEquals(0xBEEF, hdr(r, 0))
        val flags = hdr(r, 1)
        assertTrue(flags and 0x8000 != 0 && flags and 0x0100 != 0 && flags and 0x0080 != 0)
        assertEquals(0, flags and 0xF); assertEquals(1, hdr(r, 2)); assertEquals(1, hdr(r, 3))
        assertArrayEquals(ByteArray(4), r.copyOfRange(r.size - 4, r.size))
        assertEquals(DnsMessage.BLOCK_TTL, DnsMessage.minTtl(r))
    }

    @Test
    fun blockedAaaaAndOtherTypes() {
        val r6 = DnsMessage.buildBlockedResponse(DnsMessage.buildQuery("a.com", DnsMessage.QTYPE_AAAA))
        assertEquals(1, hdr(r6, 3)); assertArrayEquals(ByteArray(16), r6.copyOfRange(r6.size - 16, r6.size))
        val other = DnsMessage.buildBlockedResponse(DnsMessage.buildQuery("a.com", 65))
        assertEquals(0, hdr(other, 3)); assertNull(DnsMessage.minTtl(other))
    }

    @Test
    fun nxdomainServfailAndId() {
        val q = DnsMessage.buildQuery("a.com", id = 1)
        assertEquals(3, DnsMessage.rcode(DnsMessage.buildBlockedResponse(q, mode = "nxdomain")))
        assertEquals(2, DnsMessage.rcode(DnsMessage.buildServfail(q)))
        assertEquals(99, hdr(DnsMessage.withId(DnsMessage.buildBlockedResponse(q), 99), 0))
    }

    @Test
    fun malformedPacketsAreRejected() {
        val h = byteArrayOf(0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0)
        val bad = listOf(
            ByteArray(0), ByteArray(11),
            byteArrayOf(0, 1, 0x81.toByte(), 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 'a'.code.toByte(), 0, 0, 1, 0, 1),
            byteArrayOf(0, 1, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1, 'a'.code.toByte(), 0, 0, 1, 0, 1),
            h + byteArrayOf(5, 'a'.code.toByte(), 'b'.code.toByte()),
            h + byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1),
            h + byteArrayOf(1, 'a'.code.toByte(), 0, 0),
            h + (ByteArray(64) { if (it == 0) 63 else 'a'.code.toByte() }).let { l -> l + l + l + l + l } + byteArrayOf(0, 0, 1, 0, 1),
        )
        for (b in bad) {
            try { DnsMessage.parseQuery(b); fail("doveva fallire: ${b.size} byte") } catch (e: DnsParseException) { }
        }
    }

    @Test
    fun minTtlReadsUpstreamAnswers() {
        // risposta con due record A (TTL 300 e 120), nome compresso
        val q = DnsMessage.buildQuery("x.com", id = 5)
        val head = byteArrayOf(0, 5, 0x81.toByte(), 0x80.toByte(), 0, 1, 0, 2, 0, 0, 0, 0)
        fun rec(ttl: Int) = byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1, 0, 0, (ttl shr 8).toByte(), ttl.toByte(), 0, 4, 1, 2, 3, 4)
        val resp = head + q.copyOfRange(12, q.size) + rec(300) + rec(120)
        assertEquals(120, DnsMessage.minTtl(resp))
        assertNull(DnsMessage.minTtl(resp.copyOf(resp.size - 3)))
    }
}
