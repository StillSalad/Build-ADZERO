package it.lollomarta.adzero.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class StatsTest {
    private val d = LocalDate.of(2026, 10, 29)

    @Test
    fun countsAndPercent() {
        val s = Stats()
        repeat(10) { s.record(if (it < 3) "ads.example.com" else "ok.com", it < 3, d) }
        assertEquals(10L, s.total); assertEquals(3L, s.blocked)
        assertEquals(30.0, s.day(d).percent, 0.0)
        assertEquals(listOf("ads.example.com" to 3L), s.topBlocked())
        assertEquals(0.0, Stats.percent(0, 0), 0.0)
    }

    @Test
    fun allowedDomainsAreNeverStored() {
        val s = Stats()
        s.record("private.example.com", false, d)
        assertFalse(s.serialize().contains("private.example.com"))
    }

    @Test
    fun historyFillsAndPrunes() {
        val s = Stats(historyDays = 7)
        s.record("a.com", true, d.minusDays(10)); s.record("a.com", true, d)
        val h = s.history(3, d)
        assertEquals(listOf("2026-10-27", "2026-10-28", "2026-10-29"), h.map { it.date })
        assertEquals(listOf(0L, 0L, 1L), h.map { it.blocked })
        assertFalse(s.serialize().contains(d.minusDays(10).toString()))
        assertEquals(2L, s.total)
    }

    @Test
    fun serializationRoundTripAndCorruption() {
        val s = Stats()
        s.record("a.com", true, d); s.record("b.com", false, d)
        assertEquals(s.serialize(), Stats.deserialize(s.serialize()).serialize())
        for (bad in listOf("", "v2\n", "v1\nt x y", "v1\nt 1 5", "v1\nd 2026-10-29 1 9", "v1\nq 1")) {
            assertEquals(0L, Stats.deserialize(bad).total)
        }
    }

    @Test
    fun topIsBounded() {
        val s = Stats(maxTop = 5)
        repeat(50) { s.record("d$it.com", true, d) }
        assertTrue(s.serialize().lines().count { it.startsWith("x ") } <= 10)
    }
}
