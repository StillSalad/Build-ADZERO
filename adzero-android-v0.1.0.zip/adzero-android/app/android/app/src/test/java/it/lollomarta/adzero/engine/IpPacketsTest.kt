package it.lollomarta.adzero.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class IpPacketsTest {
    private val app4 = byteArrayOf(10, 111, 222.toByte(), 2)
    private val dns4 = byteArrayOf(10, 111, 222.toByte(), 1)
    private val app6 = ByteArray(16).also { it[0] = 0xfd.toByte(); it[15] = 2 }
    private val dns6 = ByteArray(16).also { it[0] = 0xfd.toByte(); it[15] = 1 }

    /** Costruisce una "query" come se arrivasse dal sistema, usando il costruttore inverso. */
    private fun query(v: Int, payload: ByteArray): ByteArray {
        val fake = if (v == 4) UdpPacket(4, dns4, app4, 53, 40000, ByteArray(0))
        else UdpPacket(6, dns6, app6, 53, 40000, ByteArray(0))
        return IpPackets.buildUdpResponse(fake, payload)
    }

    @Test
    fun ipv4RoundTripWithValidChecksums() {
        val dns = DnsMessage.buildQuery("ads.example.com")
        val raw = query(4, dns)
        val p = IpPackets.parseUdp(raw, raw.size)!!
        assertEquals(4, p.ipVersion); assertEquals(53, p.dstPort); assertEquals(40000, p.srcPort)
        assertArrayEquals(app4, p.src); assertArrayEquals(dns, p.payload)
        assertEquals(0, IpPackets.checksum(raw.copyOfRange(0, 20)))

        val resp = IpPackets.buildUdpResponse(p, DnsMessage.buildBlockedResponse(p.payload))
        val back = IpPackets.parseUdp(resp, resp.size)!!
        assertArrayEquals(app4, back.dst); assertEquals(40000, back.dstPort)
        val pseudo = dns4 + app4 + byteArrayOf(0, 17, 0, (resp.size - 20).toByte())
        assertEquals(0, IpPackets.checksum(pseudo + resp.copyOfRange(20, resp.size)))
    }

    @Test
    fun ipv6RoundTripWithValidChecksum() {
        val raw = query(6, DnsMessage.buildQuery("ads.example.com", DnsMessage.QTYPE_AAAA))
        val p = IpPackets.parseUdp(raw, raw.size)!!
        assertEquals(6, p.ipVersion); assertArrayEquals(app6, p.src)
        val udpLen = raw.size - 40
        val pseudo = app6 + dns6 + byteArrayOf(0, 0, (udpLen shr 8).toByte(), udpLen.toByte(), 0, 0, 0, 17)
        assertEquals(0, IpPackets.checksum(pseudo + raw.copyOfRange(40, raw.size)))
    }

    @Test
    fun rejectsFragmentsOtherProtocolsAndGarbage() {
        val raw = query(4, DnsMessage.buildQuery("a.com"))
        val frag = raw.copyOf().also { it[6] = 0x20 } // flag MF
        val tcp = raw.copyOf().also { it[9] = 6 }
        assertNull(IpPackets.parseUdp(frag, frag.size))
        assertNull(IpPackets.parseUdp(tcp, tcp.size))
        assertNull(IpPackets.parseUdp(raw, 20))
        assertNull(IpPackets.parseUdp(ByteArray(60), 60))
        val v6 = query(6, DnsMessage.buildQuery("a.com")).also { it[6] = 0 } // header di estensione
        assertNull(IpPackets.parseUdp(v6, v6.size))
    }
}
