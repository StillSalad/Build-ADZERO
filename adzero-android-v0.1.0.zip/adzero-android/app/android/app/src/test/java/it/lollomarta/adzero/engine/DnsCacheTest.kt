package it.lollomarta.adzero.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DnsCacheTest {
    private var now = 0L
    private fun cache(max: Int = 100) = DnsCache(max, 10, 100) { now }

    @Test
    fun ttlIsClampedAndExpires() {
        val c = cache()
        c.put("a.com", 1, byteArrayOf(1), 0)
        c.put("b.com", 1, byteArrayOf(2), 1_000_000)
        now = 9_900; assertArrayEquals(byteArrayOf(1), c.get("a.com", 1))
        now = 10_000; assertNull(c.get("a.com", 1))
        now = 99_000; assertArrayEquals(byteArrayOf(2), c.get("b.com", 1))
        now = 100_000; assertNull(c.get("b.com", 1))
        assertEquals(2L, c.hits); assertEquals(2L, c.misses)
    }

    @Test
    fun lruEvictionAndTypeKey() {
        val c = cache(max = 2)
        c.put("a", 1, byteArrayOf(1), 60); c.put("b", 1, byteArrayOf(2), 60)
        c.get("a", 1); c.put("c", 1, byteArrayOf(3), 60)
        assertNull(c.get("b", 1)); assertArrayEquals(byteArrayOf(1), c.get("a", 1))
        assertNull(c.get("a", 28))
    }
}
