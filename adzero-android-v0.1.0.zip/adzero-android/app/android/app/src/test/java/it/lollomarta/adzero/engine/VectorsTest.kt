package it.lollomarta.adzero.engine

import org.junit.Assert.assertEquals
import org.junit.Test

/** Stessi vettori dei test Python: se i due motori divergono, questi test falliscono. */
@Suppress("UNCHECKED_CAST")
class VectorsTest {
    private val matching = TestJson.vector("matching.json") as Map<String, Any?>
    private val parity = TestJson.vector("parity.json") as Map<String, Any?>

    @Test
    fun sharedMatchingVectors() {
        val rs = RuleSet()
        rs.addAll(RuleParser.parseText((matching["rules"] as List<String>).joinToString("\n")).first)
        for (c in matching["cases"] as List<Map<String, Any?>>) {
            assertEquals("dominio ${c["domain"]}", c["blocked"], rs.check(c["domain"] as String).blocked)
        }
    }

    @Test
    fun parseReportMatchesPython() {
        val (_, report) = RuleParser.parseText(parity["text"] as String)
        val exp = parity["report"] as Map<String, Any?>
        assertEquals(exp["total_lines"], report.totalLines.toLong())
        assertEquals(exp["rules"], report.rules.toLong())
        assertEquals(exp["comments"], report.comments.toLong())
        assertEquals(exp["ignored"], report.ignored.toLong())
        assertEquals(exp["invalid"], report.invalid.toLong())
        assertEquals(exp["unsupported"], report.unsupported.toLong())
    }

    @Test
    fun compiledRulesMatchPython() {
        val (rules, _) = RuleParser.parseText(parity["text"] as String)
        assertEquals(parity["compiled"], rules.map { RuleParser.toCompiledLine(it) })
        val text = (parity["compiled"] as List<String>).joinToString("\n")
        assertEquals(rules, RuleParser.parseCompiled(text))
    }

    @Test
    fun decisionsMatchPython() {
        val rs = RuleSet()
        rs.addAll(RuleParser.parseText(parity["text"] as String).first)
        assertEquals(parity["rejected"], rs.rejected.map { it.first.domain }.sorted())
        for (d in parity["decisions"] as List<Map<String, Any?>>) {
            val dec = rs.check(d["q"] as String)
            assertEquals("blocco di ${d["q"]}", d["blocked"], dec.blocked)
            assertEquals("motivo per ${d["q"]}", d["reason"], dec.reason)
        }
    }

    @Test
    fun normalizationMatchesPython() {
        for (c in parity["normalize"] as List<Map<String, Any?>>) {
            assertEquals("normalizzazione di ${c["in"]}", c["out"], Domains.normalize(c["in"] as String))
        }
    }

    @Test
    fun fastCompiledLoaderGivesSameDecisions() {
        val compiled = "# header\n" + (parity["compiled"] as List<String>).joinToString("\n") + "\n"
        val slow = RuleSet().also { it.addAll(RuleParser.parseCompiled(compiled)) }
        val fast = RuleSet().also { RuleParser.loadCompiledFast(compiled, it) }
        for (d in parity["decisions"] as List<Map<String, Any?>>) {
            val q = d["q"] as String
            assertEquals("caricamento veloce per $q", slow.check(q), fast.check(q))
        }
        for (bad in listOf("X a.com", "B", "B* A B", "B a com", "B* -", "Bx a.com")) {
            try { RuleParser.loadCompiledFast(bad, RuleSet()); org.junit.Assert.fail("doveva fallire: $bad") }
            catch (e: IllegalArgumentException) { }
        }
    }
}
