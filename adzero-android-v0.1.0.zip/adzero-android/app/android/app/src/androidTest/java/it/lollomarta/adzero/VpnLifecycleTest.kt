package it.lollomarta.adzero

import android.net.VpnService
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import it.lollomarta.adzero.vpn.AdzeroVpnService
import it.lollomarta.adzero.vpn.VpnState
import it.lollomarta.adzero.vpn.VpnState.Protection
import org.junit.Assert.assertEquals
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Avvio e arresto reali del servizio VPN.
 * Il consenso VPN si concede una volta sola, prima dei test, con:
 *   adb shell appops set it.lollomarta.adzero ACTIVATE_VPN allow
 * Senza consenso il test viene saltato (non fallisce).
 */
@RunWith(AndroidJUnit4::class)
class VpnLifecycleTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    private fun waitFor(state: Protection, ms: Long = 10_000): Protection {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end && VpnState.protection != state) Thread.sleep(100)
        return VpnState.protection
    }

    @Test
    fun withoutConsentTheServiceReportsIt() {
        // Si esegue solo su un dispositivo dove il consenso NON è stato dato.
        assumeTrue("Consenso già concesso", VpnService.prepare(ctx) != null)
        AdzeroVpnService.start(ctx)
        assertEquals(Protection.ERROR, waitFor(Protection.ERROR))
        assertEquals("consent_denied", VpnState.errorCode)
    }

    @Test
    fun startThenStop() {
        assumeTrue("Consenso VPN non concesso", VpnService.prepare(ctx) == null)
        AdzeroVpnService.start(ctx)
        assertEquals(Protection.ON, waitFor(Protection.ON))
        AdzeroVpnService.stop(ctx)
        assertEquals(Protection.OFF, waitFor(Protection.OFF))
    }

    @Test
    fun includeModeWithoutAppsRefusesToStart() {
        assumeTrue("Consenso VPN non concesso", VpnService.prepare(ctx) == null)
        val s = AdzeroApp.from(ctx).settings
        val oldMode = s.appMode; val oldApps = s.selectedApps
        try {
            s.appMode = "include"; s.selectedApps = emptySet()
            AdzeroVpnService.start(ctx)
            assertEquals(Protection.ERROR, waitFor(Protection.ERROR))
            assertEquals("no_apps_selected", VpnState.errorCode)
        } finally {
            s.appMode = oldMode; s.selectedApps = oldApps
        }
    }
}
