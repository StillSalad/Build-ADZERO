package it.lollomarta.adzero

import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import it.lollomarta.adzero.data.StatsStore
import it.lollomarta.adzero.engine.Action
import it.lollomarta.adzero.engine.DnsCache
import it.lollomarta.adzero.engine.DnsMessage
import it.lollomarta.adzero.engine.IpPackets
import it.lollomarta.adzero.engine.Rule
import it.lollomarta.adzero.engine.RuleSet
import it.lollomarta.adzero.engine.UdpPacket
import it.lollomarta.adzero.vpn.DnsTunnel
import it.lollomarta.adzero.vpn.UpstreamResolver
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.FileDescriptor
import java.net.InetAddress

/**
 * Prova il tunnel con pacchetti IP veri, senza aprire la VPN: al posto del
 * dispositivo tun usa una coppia di socket a datagrammi del kernel.
 */
@RunWith(AndroidJUnit4::class)
class DnsTunnelTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext
    private val app4 = byteArrayOf(10, 111, 222.toByte(), 2)
    private val dns4 = byteArrayOf(10, 111, 222.toByte(), 1)
    private val app6 = InetAddress.getByName("fd00:ad::2").address
    private val dns6 = InetAddress.getByName("fd00:ad::1").address

    private val ours = FileDescriptor()
    private val theirs = FileDescriptor()
    private var tunnel: DnsTunnel? = null
    private var tunPfd: ParcelFileDescriptor? = null

    private fun startTunnel(servers: List<InetAddress>) {
        Os.socketpair(OsConstants.AF_UNIX, OsConstants.SOCK_DGRAM, 0, ours, theirs)
        if (android.os.Build.VERSION.SDK_INT >= 28) // evita attese infinite se il tunnel non risponde
            Os.setsockoptTimeval(ours, OsConstants.SOL_SOCKET, OsConstants.SO_RCVTIMEO, android.system.StructTimeval.fromMillis(15000))
        val rules = RuleSet().apply { add(Rule(Action.BLOCK, "ads.adzero-test.example", true)) }
        val pfd = ParcelFileDescriptor.dup(theirs)
        tunPfd = pfd
        val t = DnsTunnel(pfd, { rules }, { "null_ip" }, StatsStore(ctx), DnsCache(),
            UpstreamResolver(null) { servers }) {}
        tunnel = t
        Thread { t.run() }.start()
    }

    @After
    fun tearDown() {
        tunnel?.stop()
        runCatching { Os.close(ours) }; runCatching { Os.close(theirs) }; runCatching { tunPfd?.close() }
    }

    private fun exchange(v: Int, name: String, qtype: Int): UdpPacket {
        val fake = if (v == 4) UdpPacket(4, dns4, app4, 53, 40123, ByteArray(0)) else UdpPacket(6, dns6, app6, 53, 40123, ByteArray(0))
        val pkt = IpPackets.buildUdpResponse(fake, DnsMessage.buildQuery(name, qtype, 0x2A2A))
        Os.write(ours, pkt, 0, pkt.size)
        val buf = ByteArray(4096)
        val n = Os.read(ours, buf, 0, buf.size)
        return IpPackets.parseUdp(buf, n)!!
    }

    @Test
    fun blockedDomainIpv4GetsZeroAddress() {
        startTunnel(UpstreamResolver.CLOUDFLARE)
        val r = exchange(4, "x.ads.adzero-test.example", DnsMessage.QTYPE_A)
        assertArrayEquals(app4, r.dst)
        assertEquals(40123, r.dstPort)
        assertArrayEquals(ByteArray(4), r.payload.copyOfRange(r.payload.size - 4, r.payload.size))
    }

    @Test
    fun blockedDomainIpv6GetsZeroAddress() {
        startTunnel(UpstreamResolver.CLOUDFLARE)
        val r = exchange(6, "ads.adzero-test.example", DnsMessage.QTYPE_AAAA)
        assertEquals(6, r.ipVersion)
        assertArrayEquals(ByteArray(16), r.payload.copyOfRange(r.payload.size - 16, r.payload.size))
    }

    @Test
    fun allowedDomainIsResolvedUpstream() {
        // Richiede Internet sul dispositivo di test.
        startTunnel(UpstreamResolver.CLOUDFLARE)
        val r = exchange(4, "example.com", DnsMessage.QTYPE_A)
        assertEquals(DnsMessage.RCODE_NOERROR, DnsMessage.rcode(r.payload))
        assertNotNull(DnsMessage.minTtl(r.payload))
    }

    @Test
    fun unreachableUpstreamGivesServfail() {
        // 192.0.2.1 è un indirizzo di documentazione: nessuno risponde (rete non disponibile).
        startTunnel(listOf(InetAddress.getByName("192.0.2.1")))
        val r = exchange(4, "example.com", DnsMessage.QTYPE_A)
        assertEquals(DnsMessage.RCODE_SERVFAIL, DnsMessage.rcode(r.payload))
        assertTrue(r.payload.size >= 12)
    }
}
