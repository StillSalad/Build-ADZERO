"""Strumento da riga di comando per sviluppo e test.

Esempi:
  python -m engine.cli update
  python -m engine.cli check doubleclick.net googleads.g.doubleclick.net
  python -m engine.cli parse percorso/lista.txt
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .matcher import RuleSet
from .rules import Action, Rule, parse_compiled, parse_text
from .updater import load_sources, update_source

ROOT = Path(__file__).resolve().parent.parent
LISTS = ROOT / "lists"


def load_ruleset(compiled_dir: Path = LISTS / "compiled") -> RuleSet:
    rs = RuleSet()
    for f in sorted(compiled_dir.glob("*.rules")):
        rs.add_all(parse_compiled(f.read_text(encoding="utf-8")))
    # regole utente: un dominio scritto a mano include i sottodomini
    for name in ("blocklist_custom.txt", "allowlist_default.txt"):
        p = LISTS / name
        if p.exists():
            rules, _ = parse_text(p.read_text(encoding="utf-8"), plain_subdomains=True)
            if name.startswith("allow"):
                rules = [Rule(Action.ALLOW, r.domain, r.include_subdomains) for r in rules]
            rs.add_all(rules)
    return rs


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="adzero")
    sub = ap.add_subparsers(dest="cmd", required=True)
    u = sub.add_parser("update", help="scarica e compila le liste abilitate")
    u.add_argument("--sources", default=str(LISTS / "sources.json"))
    u.add_argument("--out", default=str(LISTS / "compiled"))
    c = sub.add_parser("check", help="verifica se uno o più domini verrebbero bloccati")
    c.add_argument("domains", nargs="+")
    p = sub.add_parser("parse", help="analizza un file di regole e mostra il resoconto")
    p.add_argument("file")
    args = ap.parse_args(argv)

    if args.cmd == "update":
        code = 0
        for src in load_sources(args.sources):
            if not src.enabled:
                continue
            res = update_source(src, args.out)
            print(f"[{'OK' if res.ok else 'ERRORE'}] {src.id}: {res.message} ({res.rules} regole)")
            code |= 0 if res.ok else 1
        return code
    if args.cmd == "check":
        rs = load_ruleset()
        print(f"regole caricate: {rs.blocked_domain_count} bloccate, "
              f"{rs.allowed_domain_count} consentite, {len(rs.rejected)} rifiutate")
        for d in args.domains:
            dec = rs.check(d)
            print(f"{'BLOCCATO ' if dec.blocked else 'consentito'}  {d}  ({dec.reason})")
        return 0
    if args.cmd == "parse":
        _, report = parse_text(Path(args.file).read_text(encoding="utf-8", errors="replace"))
        print(json.dumps(report.as_dict(), indent=2))
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
