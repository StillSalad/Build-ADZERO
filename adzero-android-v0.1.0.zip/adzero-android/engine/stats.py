"""Statistiche locali. Contano RICHIESTE DNS, non annunci visibili eliminati.

Privacy: si salvano solo contatori giornalieri e i domini BLOCCATI più
frequenti (mai i domini consentiti, mai orari, mai l'app di provenienza).
"""
from __future__ import annotations

from collections import Counter
from datetime import date, timedelta


def percent(part: int, whole: int) -> float:
    return round(100.0 * part / whole, 1) if whole > 0 else 0.0


class Stats:
    def __init__(self, max_top: int = 200, history_days: int = 30) -> None:
        self.max_top = max_top
        self.history_days = history_days
        self.total = 0
        self.blocked = 0
        self._days: dict[str, list[int]] = {}  # "YYYY-MM-DD" -> [totali, bloccate]
        self._top: Counter[str] = Counter()

    def record(self, domain: str | None, blocked: bool, day: date | None = None) -> None:
        day = day or date.today()
        key = day.isoformat()
        entry = self._days.setdefault(key, [0, 0])
        entry[0] += 1
        self.total += 1
        if blocked:
            entry[1] += 1
            self.blocked += 1
            if domain:
                self._top[domain] += 1
                if len(self._top) > self.max_top * 2:
                    self._top = Counter(dict(self._top.most_common(self.max_top)))
        self._prune(day)

    def _prune(self, today: date) -> None:
        cutoff = (today - timedelta(days=self.history_days - 1)).isoformat()
        for k in [k for k in self._days if k < cutoff]:
            del self._days[k]

    @property
    def block_percent(self) -> float:
        return percent(self.blocked, self.total)

    def day(self, day: date) -> dict:
        total, blocked = self._days.get(day.isoformat(), [0, 0])
        return {"date": day.isoformat(), "total": total, "blocked": blocked,
                "percent": percent(blocked, total)}

    def history(self, days: int, end: date | None = None) -> list[dict]:
        end = end or date.today()
        return [self.day(end - timedelta(days=i)) for i in range(days - 1, -1, -1)]

    def top_blocked(self, n: int = 10) -> list[tuple[str, int]]:
        return self._top.most_common(n)

    def reset(self) -> None:
        self.__init__(self.max_top, self.history_days)

    def to_dict(self) -> dict:
        return {"version": 1, "total": self.total, "blocked": self.blocked,
                "days": self._days, "top": dict(self._top)}

    @classmethod
    def from_dict(cls, data: dict, **kwargs) -> "Stats":
        """Carica statistiche salvate; dati corrotti -> statistiche vuote."""
        s = cls(**kwargs)
        try:
            if data.get("version") != 1:
                return s
            total, blocked = int(data["total"]), int(data["blocked"])
            days = {str(k): [int(v[0]), int(v[1])] for k, v in data["days"].items()}
            top = Counter({str(k): int(v) for k, v in data["top"].items()})
        except (KeyError, TypeError, ValueError, IndexError, AttributeError):
            return s
        if total < 0 or blocked < 0 or blocked > total:
            return s
        if any(t < 0 or b < 0 or b > t for t, b in days.values()):
            return s
        s.total, s.blocked, s._days, s._top = total, blocked, days, top
        return s
