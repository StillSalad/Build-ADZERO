"""Decisione blocca/consenti per un dominio richiesto via DNS.

Regole di precedenza (semplici e prevedibili):
1. un dominio non valido non viene mai bloccato (fail-open);
2. l'allowlist vince sempre sulla blocklist;
3. regola esatta: solo quel nome; regola con sottodomini: il nome e tutto
   ciò che sta sotto.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .domains import iter_suffixes, normalize_domain
from .rules import Action, Rule

# Domini che non possono essere bloccati: bloccarli romperebbe Android,
# gli store o metà di Internet. Proteggono da liste o regole sbagliate.
# I sottodomini specifici (es. ads.example.com) restano bloccabili.
DEFAULT_GUARDED = frozenset({
    # suffissi pubblici frequenti
    "co.uk", "org.uk", "com.au", "com.br", "co.jp", "co.in", "com.cn",
    "github.io", "blogspot.com", "herokuapp.com", "netlify.app",
    # infrastruttura critica
    "google.com", "googleapis.com", "gstatic.com", "android.com",
    "googleusercontent.com", "gvt1.com", "youtube.com", "apple.com",
    "icloud.com", "microsoft.com", "windows.net", "amazonaws.com",
    "cloudfront.net", "akamaihd.net", "akamaized.net", "fastly.net",
    "cloudflare.com", "github.com", "githubusercontent.com",
})


@dataclass(frozen=True)
class Decision:
    blocked: bool
    reason: str  # allowlist | blocklist | no_match | invalid_domain
    domain: str | None = None
    rule: Rule | None = None


class RuleSet:
    def __init__(self, guarded: Iterable[str] = DEFAULT_GUARDED) -> None:
        self._guarded = frozenset(guarded)
        self._block_exact: set[str] = set()
        self._block_sub: set[str] = set()
        self._allow_exact: set[str] = set()
        self._allow_sub: set[str] = set()
        self.rejected: list[tuple[Rule, str]] = []

    def add(self, rule: Rule) -> bool:
        if rule.action is Action.BLOCK and rule.domain in self._guarded:
            self.rejected.append((rule, "dominio protetto"))
            return False
        if rule.action is Action.BLOCK:
            target = self._block_sub if rule.include_subdomains else self._block_exact
        else:
            target = self._allow_sub if rule.include_subdomains else self._allow_exact
        target.add(rule.domain)
        return True

    def add_all(self, rules: Iterable[Rule]) -> int:
        return sum(self.add(r) for r in rules)

    @property
    def blocked_domain_count(self) -> int:
        return len(self._block_exact | self._block_sub)

    @property
    def allowed_domain_count(self) -> int:
        return len(self._allow_exact | self._allow_sub)

    def check(self, raw_domain: str) -> Decision:
        d = normalize_domain(raw_domain)
        if d is None:
            return Decision(False, "invalid_domain")
        suffixes = list(iter_suffixes(d))

        if d in self._allow_exact:
            return Decision(False, "allowlist", d, Rule(Action.ALLOW, d, False))
        for s in suffixes:
            if s in self._allow_sub:
                return Decision(False, "allowlist", d, Rule(Action.ALLOW, s, True))
        if d in self._block_exact:
            return Decision(True, "blocklist", d, Rule(Action.BLOCK, d, False))
        for s in suffixes:
            if s in self._block_sub:
                return Decision(True, "blocklist", d, Rule(Action.BLOCK, s, True))
        return Decision(False, "no_match", d)

    def search(self, query: str, limit: int = 50) -> list[Rule]:
        """Ricerca testuale nelle regole (per la schermata "Domini")."""
        q = query.strip().lower()
        out: list[Rule] = []
        groups = (
            (self._allow_exact, Action.ALLOW, False), (self._allow_sub, Action.ALLOW, True),
            (self._block_exact, Action.BLOCK, False), (self._block_sub, Action.BLOCK, True),
        )
        for domains, action, sub in groups:
            for d in sorted(x for x in domains if q in x):
                out.append(Rule(action, d, sub))
                if len(out) >= limit:
                    return out
        return out
