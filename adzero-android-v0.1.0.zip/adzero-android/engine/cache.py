"""Cache DNS con TTL limitato e politica LRU (riferimento per Kotlin)."""
from __future__ import annotations

import time
from collections import OrderedDict
from typing import Callable

Key = tuple[str, int]  # (qname, qtype)


class DnsCache:
    def __init__(self, max_entries: int = 2000, min_ttl: int = 10, max_ttl: int = 3600,
                 clock: Callable[[], float] = time.monotonic) -> None:
        if max_entries < 1 or min_ttl < 0 or max_ttl < min_ttl:
            raise ValueError("parametri cache non validi")
        self.max_entries = max_entries
        self.min_ttl = min_ttl
        self.max_ttl = max_ttl
        self._clock = clock
        self._data: OrderedDict[Key, tuple[float, bytes]] = OrderedDict()
        self.hits = 0
        self.misses = 0

    def put(self, key: Key, response: bytes, ttl: int) -> None:
        ttl = max(self.min_ttl, min(self.max_ttl, int(ttl)))
        self._data[key] = (self._clock() + ttl, response)
        self._data.move_to_end(key)
        while len(self._data) > self.max_entries:
            self._data.popitem(last=False)

    def get(self, key: Key) -> bytes | None:
        item = self._data.get(key)
        if item is None:
            self.misses += 1
            return None
        expires, response = item
        if self._clock() >= expires:
            del self._data[key]
            self.misses += 1
            return None
        self._data.move_to_end(key)
        self.hits += 1
        return response

    def clear(self) -> None:
        self._data.clear()

    def __len__(self) -> int:
        return len(self._data)
