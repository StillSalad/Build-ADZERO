"""ADZERO engine: logica di riferimento per il filtraggio DNS.

Questo pacchetto è la "fonte di verità" delle regole: il motore Kotlin
nell'app Android deve comportarsi in modo identico, e lo verifichiamo con
i vettori di test condivisi in tests/vectors/.
"""

__version__ = "0.1.0"
