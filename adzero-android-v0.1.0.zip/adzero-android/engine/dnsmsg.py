"""Lettura delle query DNS e costruzione delle risposte di blocco (RFC 1035).

Implementazione di riferimento per il servizio VPN Kotlin: stessi byte in
ingresso, stessi byte in uscita.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass

QTYPE_A = 1
QTYPE_AAAA = 28
QCLASS_IN = 1

RCODE_NOERROR = 0
RCODE_SERVFAIL = 2
RCODE_NXDOMAIN = 3

BLOCK_TTL = 60  # secondi: breve, così una modifica alle regole si vede presto
MAX_NAME_LEN = 255


class DnsParseError(ValueError):
    pass


@dataclass(frozen=True)
class DnsQuery:
    id: int
    flags: int
    qname: str
    qtype: int
    qclass: int
    question_end: int  # offset del primo byte dopo la sezione Question


def _read_name(data: bytes, offset: int) -> tuple[str, int]:
    labels: list[str] = []
    total = 0
    while True:
        if offset >= len(data):
            raise DnsParseError("nome troncato")
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0:
            # Le query non usano compressione nella Question: la rifiutiamo
            # invece di seguire puntatori (niente loop, niente sorprese).
            raise DnsParseError("compressione non ammessa nella domanda")
        offset += 1
        end = offset + length
        if end > len(data):
            raise DnsParseError("etichetta troncata")
        total += length + 1
        if total > MAX_NAME_LEN:
            raise DnsParseError("nome troppo lungo")
        labels.append(data[offset:end].decode("ascii", errors="replace"))
        offset = end
    return ".".join(labels), offset


def parse_query(data: bytes) -> DnsQuery:
    if len(data) < 12:
        raise DnsParseError("pacchetto più corto dell'header")
    qid, flags, qdcount, _an, _ns, _ar = struct.unpack("!HHHHHH", data[:12])
    if flags & 0x8000:
        raise DnsParseError("è una risposta, non una query")
    if (flags >> 11) & 0xF != 0:
        raise DnsParseError("opcode non supportato")
    if qdcount != 1:
        raise DnsParseError("serve esattamente una domanda")
    qname, off = _read_name(data, 12)
    if off + 4 > len(data):
        raise DnsParseError("domanda troncata")
    qtype, qclass = struct.unpack("!HH", data[off:off + 4])
    return DnsQuery(qid, flags, qname.lower(), qtype, qclass, off + 4)


def _header(query: DnsQuery, rcode: int, ancount: int) -> bytes:
    # QR=1, copia opcode e RD, RA=1
    flags = 0x8000 | (query.flags & 0x7900) | 0x0080 | (rcode & 0xF)
    return struct.pack("!HHHHHH", query.id, flags, 1, ancount, 0, 0)


def build_blocked_response(data: bytes, mode: str = "null_ip") -> bytes:
    """Risposta per un dominio bloccato.

    mode="null_ip": A -> 0.0.0.0, AAAA -> ::, altri tipi -> NOERROR vuoto.
    mode="nxdomain": NXDOMAIN per qualunque tipo.
    """
    q = parse_query(data)
    question = data[12:q.question_end]
    if mode == "nxdomain":
        return _header(q, RCODE_NXDOMAIN, 0) + question
    if mode != "null_ip":
        raise ValueError(f"modalità sconosciuta: {mode}")
    if q.qclass == QCLASS_IN and q.qtype in (QTYPE_A, QTYPE_AAAA):
        rdata = bytes(4) if q.qtype == QTYPE_A else bytes(16)
        answer = struct.pack("!HHHIH", 0xC00C, q.qtype, QCLASS_IN, BLOCK_TTL, len(rdata)) + rdata
        return _header(q, RCODE_NOERROR, 1) + question + answer
    return _header(q, RCODE_NOERROR, 0) + question


def build_servfail(data: bytes) -> bytes:
    q = parse_query(data)
    return _header(q, RCODE_SERVFAIL, 0) + data[12:q.question_end]


def with_id(response: bytes, new_id: int) -> bytes:
    """Riusa una risposta in cache per una nuova query (cambia solo l'ID)."""
    if len(response) < 12:
        raise DnsParseError("risposta troppo corta")
    return struct.pack("!H", new_id & 0xFFFF) + response[2:]


def build_query(qname: str, qtype: int = QTYPE_A, qid: int = 0x1234) -> bytes:
    """Costruisce una query (usata nei test e nella diagnostica)."""
    out = bytearray(struct.pack("!HHHHHH", qid, 0x0100, 1, 0, 0, 0))
    for label in qname.rstrip(".").split("."):
        raw = label.encode("ascii")
        if not 0 < len(raw) < 64:
            raise ValueError("etichetta non valida")
        out += bytes([len(raw)]) + raw
    out += b"\x00" + struct.pack("!HH", qtype, QCLASS_IN)
    return bytes(out)
