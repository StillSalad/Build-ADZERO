"""Normalizzazione e validazione dei nomi di dominio."""
from __future__ import annotations

import ipaddress
import re
from typing import Iterator

MAX_DOMAIN_LEN = 253

# Etichetta DNS: lettere, cifre, trattino e underscore (presente in alcune liste).
_LABEL_RE = re.compile(r"^[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?$")

# Nomi tipici degli hosts file che non sono domini da bloccare.
IGNORED_NAMES = frozenset({
    "localhost", "localhost.localdomain", "local", "broadcasthost",
    "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
    "ip6-allnodes", "ip6-allrouters", "ip6-allhosts",
})


def is_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def normalize_domain(raw: object) -> str | None:
    """Restituisce il dominio in forma canonica (minuscolo, ASCII/punycode)
    oppure None se non è un dominio valido.

    Accetta anche input "da utente" come "https://Ads.Example.com/path"
    o "*.example.com" e li riduce al nome host.
    """
    if not isinstance(raw, str):
        return None
    d = raw.strip().lower()
    if not d or any(c.isspace() for c in d):
        return None
    if "://" in d:
        d = d.split("://", 1)[1]
    for sep in ("/", "?", "#"):
        d = d.split(sep, 1)[0]
    if "@" in d or d.startswith("["):
        return None
    if d.startswith("*."):
        d = d[2:]
    if is_ip(d):
        return None
    if d.count(":") == 1:
        host, port = d.split(":")
        if not port.isdigit():
            return None
        d = host
    elif ":" in d:
        return None
    if d.endswith("."):
        d = d[:-1]
    if not d or d in IGNORED_NAMES:
        return None
    if not d.isascii():
        try:
            d = d.encode("idna").decode("ascii")
        except UnicodeError:
            return None
    if len(d) > MAX_DOMAIN_LEN:
        return None
    labels = d.split(".")
    if len(labels) < 2:
        return None
    if not all(_LABEL_RE.match(label) for label in labels):
        return None
    if labels[-1].isdigit():  # TLD numerico: è un IP scritto male
        return None
    return d


def iter_suffixes(domain: str) -> Iterator[str]:
    """'a.b.example.com' -> a.b.example.com, b.example.com, example.com.
    Si ferma a due etichette: le regole su un TLD non sono mai accettate."""
    labels = domain.split(".")
    for i in range(len(labels) - 1):
        yield ".".join(labels[i:])
