"""Parsing delle regole: formato hosts, elenco di domini, sintassi adblock
(solo la parte applicabile al DNS) e formato compilato interno di ADZERO."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum

from .domains import IGNORED_NAMES, is_ip, normalize_domain


class Action(str, Enum):
    BLOCK = "block"
    ALLOW = "allow"


@dataclass(frozen=True)
class Rule:
    action: Action
    domain: str
    include_subdomains: bool


@dataclass
class ParseReport:
    total_lines: int = 0
    rules: int = 0
    comments: int = 0
    ignored: int = 0
    invalid: int = 0
    unsupported: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


# Indirizzi "pozzo": un hosts file che punta qui sta bloccando il dominio.
SINK_ADDRESSES = frozenset({
    "0.0.0.0", "127.0.0.1", "::", "::1",
    "0:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:1",
})

# Modificatori adblock che non cambiano il significato a livello DNS.
_DNS_SAFE_MODIFIERS = frozenset({"important", "all", "document", "doc"})
_COSMETIC_MARKERS = ("##", "#@#", "#?#", "#$#", "#%#")


def _plain_domain(token: str) -> tuple[str | None, bool]:
    """Dominio "nudo" in una lista: niente URL, porte o wildcard interne."""
    wildcard = token.startswith("*.")
    body = token[2:] if wildcard else token
    if any(c in body for c in "/:*?#@[]^|$"):
        return None, wildcard
    return normalize_domain(body), wildcard


def parse_line(line: str, *, plain_subdomains: bool = False) -> tuple[list[Rule], str]:
    """Analizza una riga. Restituisce (regole, stato) con stato tra:
    rule, empty, comment, ignored, invalid, unsupported."""
    s = line.strip()
    if not s:
        return [], "empty"
    if s[0] in "!#[":
        return [], "comment"
    if any(m in s for m in _COSMETIC_MARKERS):
        return [], "unsupported"  # regole grafiche dei browser
    if "#" in s:
        s = s.split("#", 1)[0].strip()
        if not s:
            return [], "comment"

    allow = s.startswith("@@")
    body = s[2:] if allow else s
    action = Action.ALLOW if allow else Action.BLOCK

    # Sintassi adblock: ||dominio^
    if body.startswith("||"):
        body = body[2:]
        if "$" in body:
            body, mods = body.split("$", 1)
            mod_set = {m.strip().lower() for m in mods.split(",") if m.strip()}
            if mod_set - _DNS_SAFE_MODIFIERS:
                return [], "unsupported"
        if body.endswith("^|"):
            body = body[:-2]
        elif body.endswith("^"):
            body = body[:-1]
        if any(c in body for c in "/*^|?:"):
            return [], "unsupported"  # regole su percorsi o pattern: non DNS
        d = normalize_domain(body)
        if d is None:
            return [], "invalid"
        return [Rule(action, d, True)], "rule"

    tokens = body.split()

    # Formato hosts: "0.0.0.0 dominio [dominio...]"
    if len(tokens) >= 2 and is_ip(tokens[0]):
        if allow:
            return [], "invalid"
        if tokens[0] not in SINK_ADDRESSES:
            return [], "unsupported"  # reindirizzamento, non blocco
        rules: list[Rule] = []
        names_ignored = 0
        for tok in tokens[1:]:
            if tok.lower().rstrip(".") in IGNORED_NAMES:
                names_ignored += 1
                continue
            d, _ = _plain_domain(tok)
            if d is not None:
                rules.append(Rule(Action.BLOCK, d, False))
        if rules:
            return rules, "rule"
        return [], "ignored" if names_ignored else "invalid"

    # Dominio singolo per riga
    if len(tokens) == 1:
        tok = tokens[0]
        if tok.lower().rstrip(".") in IGNORED_NAMES:
            return [], "ignored"
        d, wildcard = _plain_domain(tok)
        if d is None:
            return [], "invalid"
        return [Rule(action, d, wildcard or plain_subdomains)], "rule"

    return [], "invalid"


def parse_text(text: str, *, plain_subdomains: bool = False) -> tuple[list[Rule], ParseReport]:
    """Analizza un'intera lista. Le regole duplicate vengono unite."""
    report = ParseReport()
    seen: dict[Rule, None] = {}
    for line in text.splitlines():
        report.total_lines += 1
        rules, status = parse_line(line, plain_subdomains=plain_subdomains)
        if status == "rule":
            for r in rules:
                seen.setdefault(r, None)
        elif status == "comment":
            report.comments += 1
        elif status != "empty":
            setattr(report, status, getattr(report, status) + 1)
    report.rules = len(seen)
    return list(seen), report


# ---- Formato compilato (letto anche dall'app Android) -----------------
# Una regola per riga:  "B dominio" | "B* dominio" | "A dominio" | "A* dominio"
# B = blocca, A = consenti, * = include i sottodomini. "#" = commento.

def to_compiled_line(rule: Rule) -> str:
    prefix = "B" if rule.action is Action.BLOCK else "A"
    return f"{prefix}{'*' if rule.include_subdomains else ''} {rule.domain}"


def parse_compiled(text: str) -> list[Rule]:
    rules = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2 or parts[0] not in ("B", "B*", "A", "A*"):
            raise ValueError(f"riga compilata non valida: {line!r}")
        d = normalize_domain(parts[1])
        if d is None or d != parts[1]:
            raise ValueError(f"dominio non canonico: {parts[1]!r}")
        action = Action.BLOCK if parts[0][0] == "B" else Action.ALLOW
        rules.append(Rule(action, d, parts[0].endswith("*")))
    return rules
