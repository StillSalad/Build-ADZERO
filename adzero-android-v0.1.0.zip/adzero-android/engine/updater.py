"""Download e aggiornamento sicuro delle liste di blocco.

Garanzie:
- solo HTTPS e solo fonti dichiarate in sources.json, con licenza indicata;
- limite di dimensione;
- una lista scaricata viene accettata solo se contiene abbastanza regole
  valide (protegge da pagine di errore, liste vuote o troncate);
- scrittura atomica: se qualcosa va storto la lista precedente resta intatta.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .rules import parse_compiled, parse_text, to_compiled_line

DEFAULT_MAX_BYTES = 30 * 1024 * 1024
DEFAULT_MIN_RULES = 100
USER_AGENT = "ADZERO-list-updater/0.1"


@dataclass(frozen=True)
class ListSource:
    id: str
    name: str
    url: str
    homepage: str
    license: str
    format: str
    enabled: bool


class SourceError(ValueError):
    pass


def load_sources(path: str | Path) -> list[ListSource]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    out, ids = [], set()
    for raw in data.get("sources", []):
        try:
            src = ListSource(**{k: raw[k] for k in ListSource.__dataclass_fields__})
        except KeyError as e:
            raise SourceError(f"campo mancante {e} in una fonte") from None
        if not src.url.startswith("https://"):
            raise SourceError(f"{src.id}: sono ammessi solo URL https")
        if not src.license.strip():
            raise SourceError(f"{src.id}: licenza non indicata")
        if src.format not in ("hosts", "domains", "adblock"):
            raise SourceError(f"{src.id}: formato sconosciuto {src.format}")
        if not src.id.replace("-", "").isalnum() or src.id in ids:
            raise SourceError(f"id non valido o duplicato: {src.id}")
        ids.add(src.id)
        out.append(src)
    return out


def fetch_https(url: str, max_bytes: int = DEFAULT_MAX_BYTES, timeout: float = 30) -> bytes:
    if not url.startswith("https://"):
        raise SourceError("solo https")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (https verificato)
        data = resp.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise SourceError("lista troppo grande")
    return data


@dataclass
class UpdateResult:
    ok: bool
    source_id: str
    rules: int
    message: str
    sha256: str = ""


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp-", suffix=".rules")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def update_source(source: ListSource, out_dir: str | Path, *,
                  fetch: Callable[[str, int], bytes] = fetch_https,
                  max_bytes: int = DEFAULT_MAX_BYTES,
                  min_rules: int = DEFAULT_MIN_RULES,
                  now: datetime | None = None) -> UpdateResult:
    dest = Path(out_dir) / f"{source.id}.rules"
    try:
        raw = fetch(source.url, max_bytes)
    except Exception as e:  # rete assente, timeout, HTTP 404...
        return UpdateResult(False, source.id, 0, f"download fallito: {e}")
    if len(raw) > max_bytes:
        return UpdateResult(False, source.id, 0, "lista troppo grande")

    text = raw.decode("utf-8", errors="replace")
    rules, report = parse_text(text, plain_subdomains=False)
    if len(rules) < min_rules:
        return UpdateResult(False, source.id, len(rules),
                            f"lista rifiutata: solo {len(rules)} regole valide "
                            f"(minimo {min_rules}); mantenuta la versione precedente")

    digest = hashlib.sha256(raw).hexdigest()
    stamp = (now or datetime.now(timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
    header = [
        "# ADZERO compiled list v1",
        f"# source: {source.id}",
        f"# name: {source.name}",
        f"# url: {source.url}",
        f"# license: {source.license}",
        f"# homepage: {source.homepage}",
        f"# fetched: {stamp}",
        f"# sha256: {digest}",
        f"# report: {json.dumps(report.as_dict())}",
    ]
    body = "\n".join(header + [to_compiled_line(r) for r in rules]) + "\n"
    parse_compiled(body)  # verifica: ciò che scriviamo deve essere rileggibile
    _atomic_write(dest, body)
    return UpdateResult(True, source.id, len(rules), "aggiornata", digest)
