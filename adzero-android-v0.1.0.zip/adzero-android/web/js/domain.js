/* Normalizzazione domini: stessa logica di engine/domains.py.
   Serve solo per dare un riscontro immediato mentre si scrive una regola;
   la validazione definitiva la fa sempre il motore nativo. */
(function (root) {
  "use strict";
  var LABEL = /^[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?$/;
  var IGNORED = ["localhost", "localhost.localdomain", "local", "broadcasthost",
    "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
    "ip6-allnodes", "ip6-allrouters", "ip6-allhosts"];
  var IPV4 = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;

  function isIp(s) {
    return IPV4.test(s) || (s.indexOf(":") !== -1 && /^[0-9a-f:.]+$/.test(s) && s.split(":").length > 2);
  }

  function normalizeDomain(raw) {
    if (typeof raw !== "string") return null;
    var d = raw.trim().toLowerCase();
    if (!d || /\s/.test(d)) return null;
    var i = d.indexOf("://");
    if (i !== -1) d = d.slice(i + 3);
    ["/", "?", "#"].forEach(function (sep) { d = d.split(sep)[0]; });
    if (d.indexOf("@") !== -1 || d.charAt(0) === "[") return null;
    if (d.slice(0, 2) === "*.") d = d.slice(2);
    if (isIp(d)) return null;
    var colons = d.split(":").length - 1;
    if (colons === 1) {
      var parts = d.split(":");
      if (!/^\d+$/.test(parts[1])) return null;
      d = parts[0];
    } else if (colons > 1) return null;
    if (d.slice(-1) === ".") d = d.slice(0, -1);
    if (!d || IGNORED.indexOf(d) !== -1) return null;
    if (/[^\x00-\x7f]/.test(d)) {
      try { d = new URL("http://" + d).hostname; } catch (e) { return null; }
    }
    if (d.length > 253) return null;
    var labels = d.split(".");
    if (labels.length < 2) return null;
    for (var k = 0; k < labels.length; k++) if (!LABEL.test(labels[k])) return null;
    if (/^\d+$/.test(labels[labels.length - 1])) return null;
    return d;
  }

  var api = { normalizeDomain: normalizeDomain };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.AdzeroDomain = api;
})(this);
