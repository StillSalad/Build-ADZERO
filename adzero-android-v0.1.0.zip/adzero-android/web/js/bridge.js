/* Ponte tra dashboard e app Android. Contratto completo: docs/BRIDGE.md.

   In Android l'app inietta l'oggetto `AdzeroNative`, limitato all'origine
   interna della dashboard. Le richieste partono con:
     AdzeroNative.postMessage(JSON.stringify({id, method, args}))
   (sui WebView molto vecchi: AdzeroNative.request(id, method, argsJson))
   e risponde chiamando:
     window.__adzero.resolve(id, ok, payloadJson)
   Gli aggiornamenti spontanei (stato VPN, contatori) arrivano con:
     window.__adzero.emit(name, payloadJson)

   Nel browser (senza app) si usa un'anteprima: niente filtraggio, niente
   numeri inventati, solo le regole e le impostazioni tenute in memoria. */
(function () {
  "use strict";

  var METHODS = [
    "getStatus", "setProtection", "getStats", "resetStats",
    "listRules", "addRule", "removeRule",
    "getSources", "setSourceEnabled", "updateLists",
    "getApps", "setAppMode", "setAppSelected",
    "getSettings", "setSetting", "getDiagnostics", "resetDefaults",
    "openSystemSettings"
  ];
  var TIMEOUT_MS = 15000;
  var pending = {};
  var listeners = {};
  var seq = 0;

  function emitLocal(name, payload) {
    (listeners[name] || []).forEach(function (fn) {
      try { fn(payload); } catch (e) { console.error(e); }
    });
  }

  // Ricevitore chiamato dal lato nativo.
  window.__adzero = Object.freeze({
    resolve: function (id, ok, payloadJson) {
      var p = pending[id];
      if (!p) return;
      delete pending[id];
      clearTimeout(p.timer);
      var payload;
      try { payload = payloadJson ? JSON.parse(payloadJson) : null; }
      catch (e) { p.reject(bridgeError("bad_response", "Risposta non leggibile dall'app.")); return; }
      if (ok) p.resolve(payload);
      else p.reject(bridgeError(payload && payload.code, payload && payload.message));
    },
    emit: function (name, payloadJson) {
      var payload = null;
      try { payload = JSON.parse(payloadJson); } catch (e) { return; }
      emitLocal(name, payload);
    }
  });

  function bridgeError(code, message) {
    var e = new Error(message || "Operazione non riuscita.");
    e.code = code || "unknown";
    return e;
  }

  function nativeCall(method, args) {
    return new Promise(function (resolve, reject) {
      var id = "r" + (++seq);
      pending[id] = {
        resolve: resolve, reject: reject,
        timer: setTimeout(function () {
          delete pending[id];
          reject(bridgeError("timeout", "L'app non ha risposto in tempo."));
        }, TIMEOUT_MS)
      };
      try {
        var n = window.AdzeroNative;
        if (typeof n.postMessage === "function") n.postMessage(JSON.stringify({ id: id, method: method, args: args || {} }));
        else n.request(id, method, JSON.stringify(args || {}));
      } catch (e) {
        clearTimeout(pending[id].timer);
        delete pending[id];
        reject(bridgeError("bridge_unavailable", "Collegamento con l'app non disponibile."));
      }
    });
  }

  /* ---------- Anteprima nel browser ---------- */
  function createPreview() {
    var state = {
      settings: { theme: "system", autoUpdate: true, blockMode: "null_ip", upstream: "auto" },
      rules: [
        { action: "allow", domain: "connectivitycheck.gstatic.com", includeSubdomains: true, source: "default" },
        { action: "allow", domain: "connectivitycheck.android.com", includeSubdomains: true, source: "default" },
        { action: "allow", domain: "clients3.google.com", includeSubdomains: true, source: "default" }
      ],
      sources: [
        { id: "stevenblack-unified", name: "StevenBlack Unified hosts", license: "MIT",
          homepage: "https://github.com/StevenBlack/hosts", enabled: true, rules: 0, updatedAt: null, lastError: null },
        { id: "hagezi-light", name: "HaGeZi DNS Blocklist Light", license: "GPL-3.0",
          homepage: "https://github.com/hagezi/dns-blocklists", enabled: false, rules: 0, updatedAt: null, lastError: null }
      ],
      appMode: "exclude"
    };
    var GUARDED = ["google.com", "googleapis.com", "gstatic.com", "android.com", "youtube.com",
      "apple.com", "microsoft.com", "amazonaws.com", "cloudfront.net", "cloudflare.com", "github.com"];

    function status() {
      return {
        protection: "unavailable", vpn: "disconnected", network: "unknown",
        error: { code: "preview", message: "" }, privateDnsStrict: false,
        blockedDomains: 0, allowedDomains: state.rules.filter(function (r) { return r.action === "allow"; }).length,
        listsUpdatedAt: null, engineVersion: "0.1.0 (anteprima)"
      };
    }
    function days(n) {
      var out = [], d = new Date();
      for (var i = n - 1; i >= 0; i--) {
        var x = new Date(d); x.setDate(d.getDate() - i);
        out.push({ date: x.toISOString().slice(0, 10), total: 0, blocked: 0 });
      }
      return out;
    }

    var handlers = {
      getStatus: status,
      setProtection: function () { throw bridgeError("preview", "Nell'anteprima il filtraggio non è disponibile: installa l'app sul telefono."); },
      getStats: function (a) {
        var n = a.range === "30d" ? 30 : a.range === "7d" ? 7 : 1;
        return { total: 0, blocked: 0, percent: 0, days: days(n), top: [] };
      },
      resetStats: function () { return { ok: true }; },
      listRules: function (a) {
        var q = (a.query || "").toLowerCase();
        var list = state.rules.filter(function (r) {
          return (!a.kind || a.kind === "all" || r.action === a.kind) && r.domain.indexOf(q) !== -1;
        });
        return { rules: list.slice(0, a.limit || 100), total: list.length };
      },
      addRule: function (a) {
        var d = window.AdzeroDomain.normalizeDomain(a.domain);
        if (!d) throw bridgeError("invalid_domain", "Questo non è un dominio valido.");
        if (a.action === "block" && GUARDED.indexOf(d) !== -1)
          throw bridgeError("guarded_domain", d + " è protetto: bloccarlo romperebbe il telefono.");
        if (state.rules.some(function (r) { return r.domain === d && r.action === a.action; }))
          throw bridgeError("duplicate", "La regola esiste già.");
        var rule = { action: a.action, domain: d, includeSubdomains: true, source: "user" };
        state.rules.unshift(rule);
        return rule;
      },
      removeRule: function (a) {
        state.rules = state.rules.filter(function (r) {
          return !(r.domain === a.domain && r.action === a.action && r.source === "user");
        });
        return { ok: true };
      },
      getSources: function () { return state.sources; },
      setSourceEnabled: function (a) {
        state.sources.forEach(function (s) { if (s.id === a.id) s.enabled = !!a.enabled; });
        return { ok: true };
      },
      updateLists: function () { throw bridgeError("preview", "Le liste si scaricano dall'app sul telefono."); },
      getApps: function () { return { mode: state.appMode, apps: [] }; },
      setAppMode: function (a) { state.appMode = a.mode === "include" ? "include" : "exclude"; return { ok: true }; },
      setAppSelected: function () { return { ok: true }; },
      getSettings: function () { return Object.assign({}, state.settings); },
      setSetting: function (a) {
        if (!(a.key in state.settings)) throw bridgeError("invalid_setting", "Impostazione sconosciuta.");
        state.settings[a.key] = a.value;
        return { ok: true };
      },
      getDiagnostics: function () {
        return { items: [
          { id: "native", label: "App Android", ok: false, detail: "Non collegata: questa è l'anteprima nel browser." },
          { id: "vpn", label: "Servizio VPN", ok: false, detail: "Non disponibile nell'anteprima." },
          { id: "lists", label: "Liste di blocco", ok: false, detail: "Nessuna lista scaricata." }
        ] };
      },
      resetDefaults: function () {
        state.rules = state.rules.filter(function (r) { return r.source === "default"; });
        state.settings = { theme: "system", autoUpdate: true, blockMode: "null_ip", upstream: "auto" };
        state.appMode = "exclude";
        return { ok: true };
      },
      openSystemSettings: function () { throw bridgeError("preview", "Disponibile solo nell'app."); }
    };

    return function (method, args) {
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          try { resolve(JSON.parse(JSON.stringify(handlers[method](args || {})))); }
          catch (e) { reject(e.code ? e : bridgeError("unknown", e.message)); }
        }, 60);
      });
    };
  }

  var nat = window.AdzeroNative;
  var isNative = (typeof nat === "object" || typeof nat === "function") && nat !== null &&
    (typeof nat.postMessage === "function" || typeof nat.request === "function");
  var transport = isNative ? nativeCall : createPreview();

  window.Adzero = Object.freeze({
    isPreview: !isNative,
    call: function (method, args) {
      if (METHODS.indexOf(method) === -1)
        return Promise.reject(bridgeError("unknown_method", "Metodo non consentito: " + method));
      return transport(method, args);
    },
    on: function (name, fn) { (listeners[name] = listeners[name] || []).push(fn); }
  });
})();
