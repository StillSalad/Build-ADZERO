Icone e grafica: le tavole servono da riferimento, gli asset definitivi arrivano nella Fase 3.
