# Componenti di terze parti

| Componente | Dove | Licenza | Distribuito con l'app |
|---|---|---|---|
| Orbitron (font) | `web/fonts/` | SIL Open Font License 1.1 (`web/fonts/OFL-Orbitron.txt`) | sì |
| Inter (font) | `web/fonts/` | SIL Open Font License 1.1 (`web/fonts/OFL-Inter.txt`) | sì |
| Gradle Wrapper | `app/android/gradle/wrapper/`, `gradlew` | Apache 2.0 | no (solo per compilare) |
| AndroidX (core, activity, webkit, work) | dipendenze Gradle | Apache 2.0 | sì |
| StevenBlack hosts | scaricata dal telefono | MIT | no: scaricata dalla fonte |
| HaGeZi DNS Blocklists | scaricata dal telefono, disattivata di default | GPL-3.0 | no: scaricata dalla fonte |

Le liste di blocco non sono incluse nel codice né nell'APK: l'app le scarica
dalle fonti originali al primo avvio e poi una volta al giorno.
