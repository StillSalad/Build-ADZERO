import pytest

from engine.domains import iter_suffixes, normalize_domain


@pytest.mark.parametrize("raw,expected", [
    ("example.com", "example.com"),
    ("  Ads.Example.COM  ", "ads.example.com"),
    ("example.com.", "example.com"),
    ("https://ads.example.com/path?x=1", "ads.example.com"),
    ("ads.example.com:443", "ads.example.com"),
    ("*.example.com", "example.com"),
    ("_dmarc.example.com", "_dmarc.example.com"),
    ("città.it", "xn--citt-3na.it"),
])
def test_valid(raw, expected):
    assert normalize_domain(raw) == expected


@pytest.mark.parametrize("raw", [
    "", "   ", None, 42, "localhost", "com", "a..b.com", ".example.com",
    "-bad.example.com", "bad-.example.com", "exa mple.com", "1.2.3.4",
    "::1", "[::1]", "1.2.3.4:80", "user@example.com", "example.123",
    "a" * 64 + ".com", ("a" * 60 + ".") * 5 + "com", "example.com:abc",
    "example..", "example.com..",
])
def test_invalid(raw):
    assert normalize_domain(raw) is None


def test_suffixes_stop_before_tld():
    assert list(iter_suffixes("a.b.example.com")) == ["a.b.example.com", "b.example.com", "example.com"]
    assert list(iter_suffixes("example.com")) == ["example.com"]
