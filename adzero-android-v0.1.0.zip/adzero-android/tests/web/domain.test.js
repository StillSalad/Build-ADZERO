// Verifica che domain.js dia gli stessi risultati di engine/domains.py.
// Esegui con:  node --test tests/web/domain.test.js
const test = require("node:test");
const assert = require("node:assert");
const { normalizeDomain } = require("../../web/js/domain.js");

const valid = [
  ["example.com", "example.com"],
  ["  Ads.Example.COM  ", "ads.example.com"],
  ["example.com.", "example.com"],
  ["https://ads.example.com/path?x=1", "ads.example.com"],
  ["ads.example.com:443", "ads.example.com"],
  ["*.example.com", "example.com"],
  ["_dmarc.example.com", "_dmarc.example.com"],
  ["città.it", "xn--citt-3na.it"],
];
const invalid = ["", "   ", null, 42, "localhost", "com", "a..b.com", ".example.com",
  "-bad.example.com", "bad-.example.com", "exa mple.com", "1.2.3.4", "::1", "[::1]",
  "1.2.3.4:80", "user@example.com", "example.123", "a".repeat(64) + ".com",
  ("a".repeat(60) + ".").repeat(5) + "com", "example.com:abc", "example..", "example.com.."];

test("domini validi", () => {
  for (const [raw, exp] of valid) assert.strictEqual(normalizeDomain(raw), exp, raw);
});
test("domini non validi", () => {
  for (const raw of invalid) assert.strictEqual(normalizeDomain(raw), null, String(raw));
});
