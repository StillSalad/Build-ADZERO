import struct

import pytest

from engine.dnsmsg import (QTYPE_A, QTYPE_AAAA, RCODE_NXDOMAIN, RCODE_SERVFAIL, DnsParseError,
                           build_blocked_response, build_query, build_servfail, parse_query, with_id)


def header(resp):
    return struct.unpack("!HHHHHH", resp[:12])


def test_parse_query():
    q = parse_query(build_query("Ads.Example.com", QTYPE_AAAA, qid=7))
    assert (q.id, q.qname, q.qtype) == (7, "ads.example.com", QTYPE_AAAA)


def test_blocked_a_returns_zero_ip():
    query = build_query("ads.example.com", QTYPE_A, qid=0xBEEF)
    resp = build_blocked_response(query)
    qid, flags, qd, an, ns, ar = header(resp)
    assert qid == 0xBEEF and flags & 0x8000 and flags & 0x0100 and flags & 0x0080
    assert (flags & 0xF, qd, an) == (0, 1, 1)
    assert resp.endswith(bytes(4)) and resp[12:len(query)] == query[12:]


def test_blocked_aaaa_returns_zero_ipv6():
    resp = build_blocked_response(build_query("ads.example.com", QTYPE_AAAA))
    assert header(resp)[3] == 1 and resp.endswith(bytes(16))


def test_other_types_get_empty_answer():
    resp = build_blocked_response(build_query("ads.example.com", 65))  # HTTPS record
    assert header(resp)[3] == 0 and header(resp)[1] & 0xF == 0


def test_nxdomain_mode_and_servfail():
    q = build_query("ads.example.com")
    assert header(build_blocked_response(q, "nxdomain"))[1] & 0xF == RCODE_NXDOMAIN
    assert header(build_servfail(q))[1] & 0xF == RCODE_SERVFAIL


def test_with_id():
    resp = build_blocked_response(build_query("a.com", qid=1))
    assert header(with_id(resp, 99))[0] == 99


@pytest.mark.parametrize("data", [
    b"", b"\x00" * 11,
    struct.pack("!HHHHHH", 1, 0x8100, 1, 0, 0, 0) + b"\x01a\x00\x00\x01\x00\x01",  # risposta
    struct.pack("!HHHHHH", 1, 0x0100, 2, 0, 0, 0) + b"\x01a\x00\x00\x01\x00\x01",  # 2 domande
    struct.pack("!HHHHHH", 1, 0x0100, 1, 0, 0, 0) + b"\x05ab",                     # troncato
    struct.pack("!HHHHHH", 1, 0x0100, 1, 0, 0, 0) + b"\xc0\x0c\x00\x01\x00\x01",    # puntatore
    struct.pack("!HHHHHH", 1, 0x0100, 1, 0, 0, 0) + b"\x01a\x00\x00",               # qtype corto
    struct.pack("!HHHHHH", 1, 0x0100, 1, 0, 0, 0) + (b"\x3f" + b"a" * 63) * 5 + b"\x00\x00\x01\x00\x01",
])
def test_malformed_packets_raise(data):
    with pytest.raises(DnsParseError):
        parse_query(data)
