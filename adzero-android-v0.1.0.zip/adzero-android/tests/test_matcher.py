import json
from pathlib import Path

import pytest

from engine.matcher import RuleSet
from engine.rules import Action, Rule, parse_text

VECTORS = json.loads((Path(__file__).parent / "vectors" / "matching.json").read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def ruleset():
    rs = RuleSet()
    rules, _ = parse_text("\n".join(VECTORS["rules"]))
    rs.add_all(rules)
    return rs


@pytest.mark.parametrize("case", VECTORS["cases"], ids=lambda c: c["domain"] or "<vuoto>")
def test_shared_vectors(ruleset, case):
    assert ruleset.check(case["domain"]).blocked is case["blocked"]


def test_guarded_domains_are_rejected(ruleset):
    rejected = {r.domain for r, _ in ruleset.rejected}
    assert {"google.com", "cloudfront.net"} <= rejected


def test_allowlist_beats_blocklist():
    rs = RuleSet(guarded=())
    rs.add(Rule(Action.BLOCK, "example.com", True))
    rs.add(Rule(Action.ALLOW, "ok.example.com", False))
    assert rs.check("ok.example.com").blocked is False
    assert rs.check("ok.example.com").reason == "allowlist"
    assert rs.check("x.example.com").blocked is True


def test_decision_reports_matching_rule():
    rs = RuleSet(guarded=())
    rs.add(Rule(Action.BLOCK, "example.com", True))
    d = rs.check("a.b.example.com")
    assert d.blocked and d.rule == Rule(Action.BLOCK, "example.com", True)


def test_invalid_domain_is_never_blocked():
    rs = RuleSet(guarded=())
    rs.add(Rule(Action.BLOCK, "example.com", True))
    assert rs.check("exa mple.com").reason == "invalid_domain"


def test_counts_and_search():
    rs = RuleSet(guarded=())
    rs.add_all([Rule(Action.BLOCK, "ads.a.com", False), Rule(Action.BLOCK, "ads.b.com", True),
                Rule(Action.ALLOW, "ok.com", False)])
    assert rs.blocked_domain_count == 2 and rs.allowed_domain_count == 1
    assert [r.domain for r in rs.search("ads")] == ["ads.a.com", "ads.b.com"]
    assert len(rs.search("", limit=2)) == 2
