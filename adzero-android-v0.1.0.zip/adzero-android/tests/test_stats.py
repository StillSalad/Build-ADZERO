from datetime import date, timedelta

from engine.stats import Stats, percent

D = date(2026, 10, 29)


def test_counting_and_percent():
    s = Stats()
    for i in range(10):
        s.record("ads.example.com" if i < 3 else "ok.com", blocked=i < 3, day=D)
    assert (s.total, s.blocked, s.block_percent) == (10, 3, 30.0)
    assert s.day(D) == {"date": "2026-10-29", "total": 10, "blocked": 3, "percent": 30.0}
    assert s.top_blocked() == [("ads.example.com", 3)]


def test_allowed_domains_are_not_stored():
    s = Stats()
    s.record("private.example.com", blocked=False, day=D)
    assert "private.example.com" not in str(s.to_dict())


def test_percent_zero_division():
    assert percent(0, 0) == 0.0


def test_history_fills_missing_days_and_prunes():
    s = Stats(history_days=7)
    s.record("a.com", True, day=D - timedelta(days=10))
    s.record("a.com", True, day=D)
    hist = s.history(3, end=D)
    assert [h["date"] for h in hist] == ["2026-10-27", "2026-10-28", "2026-10-29"]
    assert [h["blocked"] for h in hist] == [0, 0, 1]
    assert (D - timedelta(days=10)).isoformat() not in s.to_dict()["days"]
    assert s.total == 2  # il totale storico resta


def test_top_is_bounded():
    s = Stats(max_top=5)
    for i in range(50):
        s.record(f"d{i}.com", True, day=D)
    assert len(s.to_dict()["top"]) <= 10


def test_roundtrip_and_corrupted_data():
    s = Stats()
    s.record("a.com", True, day=D)
    assert Stats.from_dict(s.to_dict()).to_dict() == s.to_dict()
    for bad in [{}, {"version": 2}, {"version": 1, "total": "x"},
                {"version": 1, "total": 1, "blocked": 5, "days": {}, "top": {}}]:
        assert Stats.from_dict(bad).total == 0


def test_reset():
    s = Stats()
    s.record("a.com", True, day=D)
    s.reset()
    assert s.total == 0 and s.top_blocked() == []
