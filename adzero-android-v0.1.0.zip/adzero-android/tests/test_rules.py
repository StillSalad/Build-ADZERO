import pytest

from engine.rules import Action, Rule, parse_compiled, parse_line, parse_text, to_compiled_line

B, A = Action.BLOCK, Action.ALLOW


@pytest.mark.parametrize("line,rules,status", [
    ("0.0.0.0 ads.example.com", [Rule(B, "ads.example.com", False)], "rule"),
    ("127.0.0.1\tads.example.com  # commento", [Rule(B, "ads.example.com", False)], "rule"),
    ("0.0.0.0 a.com b.com", [Rule(B, "a.com", False), Rule(B, "b.com", False)], "rule"),
    (":: ads.example.com", [Rule(B, "ads.example.com", False)], "rule"),
    ("||ads.example.com^", [Rule(B, "ads.example.com", True)], "rule"),
    ("||ads.example.com^|", [Rule(B, "ads.example.com", True)], "rule"),
    ("||ads.example.com^$important", [Rule(B, "ads.example.com", True)], "rule"),
    ("@@||good.example.com^", [Rule(A, "good.example.com", True)], "rule"),
    ("@@good.example.com", [Rule(A, "good.example.com", False)], "rule"),
    ("ads.example.com", [Rule(B, "ads.example.com", False)], "rule"),
    ("*.ads.example.com", [Rule(B, "ads.example.com", True)], "rule"),
    ("", [], "empty"),
    ("# commento", [], "comment"),
    ("! commento adblock", [], "comment"),
    ("[Adblock Plus 2.0]", [], "comment"),
    ("127.0.0.1 localhost", [], "ignored"),
    ("::1 ip6-localhost ip6-loopback", [], "ignored"),
    ("192.168.1.10 nas.local", [], "unsupported"),
    ("example.com##.banner", [], "unsupported"),
    ("||example.com/ads/*", [], "unsupported"),
    ("||example.com^$third-party", [], "unsupported"),
    ("/banner[0-9]+/", [], "invalid"),
    ("https://ads.example.com/x", [], "invalid"),
    ("ads..example.com", [], "invalid"),
    ("0.0.0.0", [], "invalid"),
    ("questa non è una regola", [], "invalid"),
])
def test_parse_line(line, rules, status):
    assert parse_line(line) == (rules, status)


def test_plain_subdomains_option():
    assert parse_line("ads.example.com", plain_subdomains=True)[0] == [Rule(B, "ads.example.com", True)]


def test_parse_text_report_and_dedup():
    text = "# titolo\n0.0.0.0 a.com\n0.0.0.0 a.com\n\n127.0.0.1 localhost\nspazzatura qui\n||b.com^$popup\n"
    rules, rep = parse_text(text)
    assert rules == [Rule(B, "a.com", False)]
    assert (rep.total_lines, rep.rules, rep.comments, rep.ignored, rep.invalid, rep.unsupported) == (7, 1, 1, 1, 1, 1)


def test_compiled_roundtrip():
    rules = [Rule(B, "a.com", False), Rule(B, "b.com", True), Rule(A, "c.com", False), Rule(A, "d.com", True)]
    text = "# header\n" + "\n".join(to_compiled_line(r) for r in rules)
    assert parse_compiled(text) == rules


@pytest.mark.parametrize("bad", ["X a.com", "B", "B a.com extra", "B A.COM", "B not_valid..com"])
def test_compiled_rejects_corruption(bad):
    with pytest.raises(ValueError):
        parse_compiled(bad)
