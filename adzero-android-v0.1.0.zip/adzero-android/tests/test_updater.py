import json
from datetime import datetime, timezone

import pytest

from engine.rules import parse_compiled
from engine.updater import ListSource, SourceError, load_sources, update_source

SRC = ListSource("test-list", "Test", "https://example.org/hosts", "https://example.org",
                 "MIT", "hosts", True)
GOOD = "\n".join(f"0.0.0.0 ads{i}.example.com" for i in range(150)).encode()
NOW = datetime(2026, 10, 29, tzinfo=timezone.utc)


def test_successful_update_writes_compiled_file(tmp_path):
    res = update_source(SRC, tmp_path, fetch=lambda u, m: GOOD, now=NOW)
    assert res.ok and res.rules == 150
    text = (tmp_path / "test-list.rules").read_text()
    assert "# license: MIT" in text and "# fetched: 2026-10-29T00:00:00Z" in text
    assert len(parse_compiled(text)) == 150


def test_failed_download_keeps_previous_list(tmp_path):
    update_source(SRC, tmp_path, fetch=lambda u, m: GOOD, now=NOW)
    before = (tmp_path / "test-list.rules").read_text()

    def boom(u, m):
        raise OSError("rete non disponibile")

    res = update_source(SRC, tmp_path, fetch=boom)
    assert not res.ok and "rete non disponibile" in res.message
    assert (tmp_path / "test-list.rules").read_text() == before


def test_too_few_rules_is_rejected(tmp_path):
    html = b"<html><body>404 Not Found</body></html>"
    res = update_source(SRC, tmp_path, fetch=lambda u, m: html)
    assert not res.ok and not (tmp_path / "test-list.rules").exists()


def test_size_limit(tmp_path):
    res = update_source(SRC, tmp_path, fetch=lambda u, m: GOOD, max_bytes=10)
    assert not res.ok and "grande" in res.message


def test_no_temp_files_left(tmp_path):
    update_source(SRC, tmp_path, fetch=lambda u, m: GOOD)
    assert [p.name for p in tmp_path.iterdir()] == ["test-list.rules"]


def _write(tmp_path, sources):
    p = tmp_path / "sources.json"
    p.write_text(json.dumps({"sources": sources}))
    return p


BASE = {"id": "x", "name": "X", "url": "https://e.org/l", "homepage": "https://e.org",
        "license": "MIT", "format": "hosts", "enabled": True}


def test_load_real_sources_file():
    from pathlib import Path
    srcs = load_sources(Path(__file__).parent.parent / "lists" / "sources.json")
    assert all(s.url.startswith("https://") and s.license for s in srcs)


@pytest.mark.parametrize("change", [
    {"url": "http://e.org/l"}, {"license": " "}, {"format": "exe"}, {"id": "../evil"},
])
def test_invalid_sources_rejected(tmp_path, change):
    with pytest.raises(SourceError):
        load_sources(_write(tmp_path, [{**BASE, **change}]))


def test_duplicate_and_missing_fields(tmp_path):
    with pytest.raises(SourceError):
        load_sources(_write(tmp_path, [BASE, BASE]))
    with pytest.raises(SourceError):
        load_sources(_write(tmp_path, [{k: v for k, v in BASE.items() if k != "license"}]))
