from engine.cache import DnsCache


class Clock:
    t = 0.0
    def __call__(self):
        return self.t


def test_ttl_expiry_and_clamping():
    clk = Clock()
    c = DnsCache(min_ttl=10, max_ttl=100, clock=clk)
    c.put(("a.com", 1), b"x", ttl=0)      # alzato a 10
    c.put(("b.com", 1), b"y", ttl=10**6)  # abbassato a 100
    clk.t = 9.9
    assert c.get(("a.com", 1)) == b"x"
    clk.t = 10
    assert c.get(("a.com", 1)) is None
    clk.t = 99
    assert c.get(("b.com", 1)) == b"y"
    clk.t = 100
    assert c.get(("b.com", 1)) is None
    assert (c.hits, c.misses) == (2, 2)


def test_lru_eviction():
    c = DnsCache(max_entries=2, clock=Clock())
    c.put(("a", 1), b"a", 60)
    c.put(("b", 1), b"b", 60)
    c.get(("a", 1))
    c.put(("c", 1), b"c", 60)
    assert c.get(("b", 1)) is None and c.get(("a", 1)) == b"a" and len(c) == 2


def test_type_is_part_of_key():
    c = DnsCache(clock=Clock())
    c.put(("a.com", 1), b"v4", 60)
    assert c.get(("a.com", 28)) is None
