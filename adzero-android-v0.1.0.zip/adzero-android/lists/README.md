# Liste di blocco

| id | Licenza | Stato | Note |
|---|---|---|---|
| stevenblack-unified | MIT | attiva | formato hosts, solo nomi esatti |
| hagezi-light | GPL-3.0 | disattivata | formato adblock, sottodomini inclusi |

Le liste **non sono incluse nel repository**: vengono scaricate dal
dispositivo (o dal PC con `python -m engine.cli update`) direttamente dalla
fonte originale. Se in futuro una lista viene inclusa nell'APK, va
rispettata la sua licenza (per MIT: copia della nota di copyright; per
GPL-3.0: valutare l'impatto sulla licenza dell'app).

Prima di attivare una fonte: aprire la homepage, leggere il file LICENSE
e annotarlo qui. `lists/compiled/` è ignorata da Git.
