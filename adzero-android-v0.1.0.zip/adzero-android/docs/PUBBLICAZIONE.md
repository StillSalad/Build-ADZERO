# Checklist di pubblicazione

Spunta ogni voce prima di pubblicare una versione.

## Prima di tutto
- [ ] La build "Build ADZERO" su GitHub Actions è verde, compresi i test
      sull'emulatore (Fase 6).
- [ ] Hai provato l'APK su un telefono vero:
  - [ ] il consenso VPN compare al primo tocco dello scudo;
  - [ ] la Home mostra "Protezione attiva" e la notifica compare;
  - [ ] nel browser, un sito di prova pubblicitario non carica gli annunci
        (es. cerca "ads test page" e confronta con la protezione spenta);
  - [ ] Fantacalcio e Geometry Dash Lite si aprono e funzionano;
  - [ ] staccando e riattaccando il Wi-Fi la protezione resta attiva;
  - [ ] "Disattiva" nella notifica spegne davvero il filtro;
  - [ ] Diagnostica: tutte le voci verdi (o spiegate).
- [ ] Nessun numero finto nella dashboard: da appena installata mostra zeri
      veri.

## Chiave e versione
- [ ] I quattro secret di firma sono configurati (docs/COMPILARE.md).
- [ ] Hai una copia di sicurezza della chiave fuori dal computer.
- [ ] Il tag è più alto del precedente (`v0.1.0`, `v0.1.1`…).

## Licenze
- [ ] `LICENSE` (MIT) e `THIRD_PARTY.md` aggiornati.
- [ ] Le fonti in `lists/sources.json` hanno licenza verificata nella loro
      pagina; nessuna lista è inclusa nell'APK.
- [ ] I font restano con i loro file OFL in `web/fonts/`.

## Privacy e trasparenza
- [ ] `docs/PRIVACY.md` descrive ancora ciò che l'app fa davvero.
- [ ] La descrizione della release dice chiaramente i limiti: non blocca
      tutti gli annunci, richieste bloccate ≠ annunci eliminati, una sola
      VPN alla volta, DNS privato e DNS sicuro dei browser la scavalcano.

## Dove pubblicare
- **GitHub Releases**: sì, è il canale principale (APK + SHA-256).
- **Pagina su Netlify**: facoltativa, cartella `site/`, rimanda alla release.
- **Google Play**: no. Le norme di Play vietano le app che bloccano o
  interferiscono con la pubblicità di altre app; verrebbe rifiutata.
- **F-Droid**: possibile in futuro. Richiede codice open source (lo è) e
  una build riproducibile senza componenti proprietari: va verificato.

## Consumo di batteria
- [ ] Controlla in Impostazioni Android > Batteria dopo una giornata d'uso.
      Nel tunnel passa solo il DNS, quindi il consumo dovrebbe essere basso;
      se ADZERO compare tra le app più energivore, segnalalo come bug.
- [ ] Se il telefono chiude l'app in background (alcuni Xiaomi, Samsung,
      Huawei), nella pagina della release spiega come escluderla
      dall'ottimizzazione della batteria.
