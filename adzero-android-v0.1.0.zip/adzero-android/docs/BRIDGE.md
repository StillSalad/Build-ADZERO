# Contratto del ponte dashboard ↔ app Android

La dashboard (`web/`) parla con l'app solo attraverso `web/js/bridge.js`.
Questo file è il contratto che il codice Kotlin della Fase 4 deve rispettare.

## Trasporto

Kotlin espone **un solo** oggetto JavaScript, `AdzeroNative`, solo alla pagina
con origine `https://appassets.androidplatform.net` (frame principale):

```kotlin
WebViewCompat.addWebMessageListener(webView, "AdzeroNative", setOf(ORIGIN)) { ... }
// JS:  AdzeroNative.postMessage(JSON.stringify({id, method, args}))
```

Solo sui WebView che non supportano `WEB_MESSAGE_LISTENER` si ripiega su
`addJavascriptInterface` con un unico metodo `request(id, method, argsJson)`.

Risposta (sul thread principale):

```kotlin
webView.evaluateJavascript("window.__adzero.resolve(${q(id)}, true, ${q(json)})", null)
// errore: ok = false e payload {"code": "...", "message": "..."}
```

Eventi spontanei: `window.__adzero.emit("status", json)` quando cambia lo stato.

Regole di sicurezza:
- La WebView carica solo `https://appassets.androidplatform.net/` tramite
  `WebViewAssetLoader`; ogni altra navigazione viene annullata.
- `allowFileAccess = false`, `allowContentAccess = false`, nessun accesso a
  file o comandi dal ponte.
- Kotlin accetta solo i metodi elencati qui sotto, valida ogni argomento e
  risponde `unknown_method` a tutto il resto.
- Il ponte viene aggiunto solo se la pagina caricata è quella interna.

## Metodi

| Metodo | Argomenti | Risposta |
|---|---|---|
| `getStatus` | — | `Status` |
| `setProtection` | `{enabled: bool}` | `Status` (se serve, Kotlin mostra prima il consenso VPN di Android) |
| `getStats` | `{range: "today" \| "7d" \| "30d"}` | `{total, blocked, percent, days: [{date, total, blocked}], top: [{domain, count}]}` |
| `resetStats` | — | `{ok: true}` |
| `listRules` | `{query, kind: "all" \| "block" \| "allow", limit}` | `{rules: [Rule], total}` |
| `addRule` | `{action: "block" \| "allow", domain}` | `Rule` |
| `removeRule` | `{action, domain}` | `{ok: true}` (solo regole `source: "user"`) |
| `getSources` | — | `[{id, name, license, homepage, enabled, rules, updatedAt, lastError}]` |
| `setSourceEnabled` | `{id, enabled}` | `{ok: true}` |
| `updateLists` | — | `{results: [{id, ok, rules, message}]}` |
| `getApps` | `{query}` | `{mode: "exclude" \| "include", apps: [{packageName, label, selected, icon?}]}` |
| `setAppMode` | `{mode}` | `{ok: true}` |
| `setAppSelected` | `{packageName, selected}` | `{ok: true}` |
| `getSettings` | — | `{theme, autoUpdate, blockMode, upstream}` |
| `setSetting` | `{key, value}` | `{ok: true}` |
| `getDiagnostics` | — | `{items: [{id, label, ok, detail}]}` |
| `resetDefaults` | — | `{ok: true}` |
| `openSystemSettings` | `{target: "vpn" \| "private_dns"}` | `{ok: true}` |

`Status`:
```json
{
  "protection": "off | starting | on | stopping | error",
  "vpn": "disconnected | connecting | connected",
  "network": "available | unavailable",
  "error": null,
  "privateDnsStrict": false,
  "blockedDomains": 0,
  "allowedDomains": 0,
  "listsUpdatedAt": null,
  "engineVersion": "0.1.0"
}
```

`protection` vale `on` **solo** se il tunnel è davvero aperto e il ciclo di
lettura dei pacchetti è in esecuzione.

`Rule`: `{action, domain, includeSubdomains, source: "user" | "default" | "list"}`

`icon`, se presente, deve essere `data:image/png;base64,...` (al massimo 48×48).

## Codici di errore riconosciuti dalla dashboard

`consent_denied`, `other_vpn`, `no_apps_selected`, `always_on_other`, `no_network`, `tun_failed`,
`upstream_unreachable`, `lists_corrupted`, `invalid_domain`,
`guarded_domain`, `duplicate`, `invalid_setting`, `unknown_method`,
`timeout`. Per ciascuno la dashboard mostra una spiegazione con l'azione da fare.
