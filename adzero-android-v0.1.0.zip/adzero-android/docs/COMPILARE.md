# Compilare ADZERO

Ci sono due strade. La prima non richiede di installare nulla sul PC.

## A. Con GitHub (consigliata)

1. Su github.com crea un repository nuovo: pulsante verde **New**, nome
   `adzero-android`, visibilità a scelta, poi **Create repository**.
2. Nella pagina del repository vuoto clicca **uploading an existing file** e
   trascina dentro **tutto il contenuto** della cartella `adzero-android`
   (comprese le cartelle nascoste `.github` e il file `.gitignore`).
   Poi **Commit changes**.
   Se il browser non carica le cartelle nascoste, usa GitHub Desktop
   (File > Add local repository > Publish repository).
3. Apri la scheda **Actions**: parte da sola la compilazione "Build ADZERO".
   Dura circa 5–8 minuti.
4. Quando ha la spunta verde, clicca sull'esecuzione e, in fondo alla pagina
   nella sezione **Artifacts**, scarica **adzero-debug-apk** (è uno zip con
   dentro `app-debug.apk`).
5. Sul telefono: apri l'APK, consenti l'installazione da questa fonte quando
   Android lo chiede, poi **Installa**.

Se la spunta è rossa, apri il passaggio fallito e copia il messaggio
d'errore: va corretto nella Fase 6.

## B. Con Android Studio

1. Installa Android Studio (versione Ladybug o successiva).
2. **File > Open** e scegli la cartella `adzero-android/app/android`
   (non la radice del repository).
3. Attendi la fine di "Gradle sync" nella barra in basso.
4. Collega il telefono con il debug USB attivo (Impostazioni > Info telefono >
   tocca 7 volte "Numero build", poi Opzioni sviluppatore > Debug USB).
5. Premi il triangolo verde **Run 'app'**.

## Test

- Python: `python -m pytest`
- JavaScript: `node --test tests/web/domain.test.js`
- Kotlin (motore): in Android Studio, tasto destro su
  `app/src/test` > **Run 'Tests in ...'**, oppure `./gradlew testDebugUnitTest`
- Android (su telefono collegato), prima concedi il consenso VPN ai test:
  `adb shell appops set it.lollomarta.adzero ACTIVATE_VPN allow`
  poi `./gradlew connectedDebugAndroidTest`

## APK firmato per la distribuzione

L'APK di debug va bene per provare. Per darlo ad altri serve un APK
**firmato con una tua chiave**: Android accetta gli aggiornamenti solo se
sono firmati con la stessa chiave della prima installazione.

### 1. Crea la chiave (una volta sola)

In Android Studio, con il progetto aperto:
**Build > Generate Signed App Bundle or APK… > APK > Next >
Create new…**

- Key store path: una cartella **fuori** dal repository, ad esempio
  `Documenti/chiavi/adzero.jks`
- Password: scegline una robusta e salvala in un gestore di password
- Alias: `adzero`
- Validity: 30 anni
- Certificate: basta il nome (es. Lorenzo Marta)

Premi **OK**, poi **Cancel**: la chiave è creata, il resto lo fa GitHub.

> Se perdi questo file o la password non potrai più pubblicare
> aggiornamenti: chi ha l'app dovrebbe disinstallarla e reinstallarla.
> Tienine una copia di sicurezza. Non caricarlo mai nel repository.

### 2. Dai la chiave a GitHub (in modo segreto)

Trasforma il file in testo. In Windows apri **PowerShell** nella cartella
della chiave e scrivi:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("adzero.jks")) | Set-Clipboard
```

Ora il testo è negli appunti. Su GitHub, nel repository:
**Settings > Secrets and variables > Actions > New repository secret**,
e crea questi quattro secret:

| Nome | Valore |
|---|---|
| `ADZERO_KEYSTORE_BASE64` | incolla gli appunti |
| `ADZERO_KEYSTORE_PASSWORD` | la password del key store |
| `ADZERO_KEY_ALIAS` | `adzero` |
| `ADZERO_KEY_PASSWORD` | la password della chiave (se non l'hai cambiata, è la stessa) |

### 3. Pubblica una versione

Su GitHub: **Releases > Draft a new release > Choose a tag**, scrivi
`v0.1.0` e scegli **Create new tag**. Dai un titolo (es. "ADZERO 0.1.0"),
scrivi cosa c'è di nuovo e premi **Publish release**.

Il workflow "Release ADZERO" parte da solo e dopo qualche minuto allega
alla release `ADZERO-v0.1.0.apk` e `SHA256SUMS.txt`.

Per le versioni successive usa un numero più alto (`v0.1.1`, `v0.2.0`…):
il numero di versione interno cresce da solo.
