# Informativa sulla privacy di ADZERO

Ultimo aggiornamento: 29 ottobre 2026.

ADZERO funziona interamente sul telefono. Non ha account, non usa server
dello sviluppatore e non invia dati personali a nessuno.

**Cosa fa la VPN.** ADZERO usa la funzione VPN di Android solo per ricevere
le richieste DNS (le domande "qual è l'indirizzo di questo sito?"). Il resto
del traffico non passa da ADZERO. Il contenuto delle connessioni, comprese
quelle HTTPS, non viene mai letto né decifrato. ADZERO non installa
certificati.

**Cosa viene salvato, solo sul telefono.** Contatori giornalieri delle
richieste DNS totali e bloccate (ultimi 30 giorni) e l'elenco dei domini
bloccati più frequenti. I domini consentiti, gli orari delle richieste e le
app che le hanno fatte non vengono registrati. Le regole aggiunte a mano e
le impostazioni restano nella memoria privata dell'app e sono escluse dal
backup su cloud.

**Connessioni verso Internet fatte da ADZERO.**
1. Le richieste DNS consentite vengono inoltrate al server DNS scelto nelle
   impostazioni: quello della rete in uso, Cloudflare (1.1.1.1) o Quad9
   (9.9.9.9). Si applica l'informativa del server scelto, come succede
   senza ADZERO.
2. Le liste di blocco vengono scaricate dagli indirizzi indicati in
   Regole > Liste di blocco (GitHub). Il download non contiene dati
   personali.

**Cancellare i dati.** Statistiche > Azzera statistiche; Impostazioni >
Ripristina impostazioni predefinite; oppure disinstallare l'app.

**Contatti.** Per domande apri una segnalazione nella pagina GitHub del
progetto.
