# ADZERO
**Meno pubblicità. Più libertà.**

ADZERO è un'app Android che riduce la pubblicità nelle altre app e nei giochi,
senza root. Filtra le richieste DNS attraverso una VPN locale: quando un'app
chiede l'indirizzo di un dominio pubblicitario noto, ADZERO risponde con un
indirizzo vuoto e l'annuncio non viene scaricato.

## Cosa sa fare
- Attiva e disattiva il filtro con un tocco, con lo stato reale del servizio.
- Liste di domini aggiornabili, scaricate dalle fonti originali.
- Regole personali: blocca o consenti sempre un dominio (sottodomini inclusi).
- Scegli le app da filtrare o da escludere.
- Statistiche locali: richieste totali, bloccate, percentuale, ultimi 30 giorni,
  domini bloccati più spesso.
- Tema scuro e chiaro, diagnostica, ripristino delle impostazioni.

## Cosa non sa fare (e perché)
- **Non blocca tutti gli annunci.** Alcuni arrivano dallo stesso dominio dei
  contenuti (per esempio i video di YouTube) e il DNS non li può separare.
- **Una richiesta bloccata non è un annuncio eliminato.** Un annuncio può
  usare più richieste: le statistiche contano richieste, non annunci.
- **Non dice quale app mostra più pubblicità.** Le richieste DNS le invia il
  sistema per conto delle app, quindi non si sa con certezza da quale app
  arrivano.
- **Viene scavalcata** dal DNS privato di Android impostato su un nome host e
  dai browser con "DNS sicuro" attivo. La Diagnostica segnala il primo caso.
- **Una sola VPN alla volta**: con un'altra VPN attiva, ADZERO si ferma.

## Installare
Scarica l'ultimo `ADZERO-vX.Y.Z.apk` dalla pagina
[Releases](../../releases/latest), aprilo sul telefono e consenti
l'installazione da quella fonte quando Android lo chiede. Al primo tocco dello
scudo, accetta la richiesta di connessione VPN.

Serve Android 8.0 o successivo.

## Privacy
Nessun account, nessun server dello sviluppatore, nessun dato inviato. Il
traffico HTTPS non viene mai letto. Dettagli in [docs/PRIVACY.md](docs/PRIVACY.md).

## Per sviluppatori

### Struttura
```
app/android/   progetto Android Studio (Kotlin): servizio VPN, motore, ponte
web/           dashboard HTML/CSS/JS caricata nell'app
engine/        motore di riferimento in Python
tests/         test Python, test JS, vettori condivisi Python ↔ Kotlin
lists/         fonti delle liste e allowlist predefinita
site/          pagina di download per Netlify (facoltativa)
tools/         anteprima dashboard, generatore vettori, verifica completa
docs/          architettura, ponte, compilazione, pubblicazione, privacy
.github/       build, test su emulatore e release automatiche
```

### Come è fatto
Il motore esiste due volte: in **Python** (riferimento, facile da testare) e in
**Kotlin** (quello che gira sul telefono). I vettori in `tests/vectors/` vengono
eseguiti da entrambi: se i due motori danno risultati diversi, i test
falliscono. Dettagli in [docs/ARCHITETTURA.md](docs/ARCHITETTURA.md).

### Comandi
```bash
pip install -r requirements.txt
sh tools/verify_all.sh                     # Python, JS, vettori, anteprima
python -m engine.cli update                # scarica le liste sul PC
python -m engine.cli check doubleclick.net # prova una regola
python tools/build_preview.py              # dist/adzero-anteprima.html
cd app/android && ./gradlew testDebugUnitTest assembleDebug
```

Compilare l'APK e firmarlo: [docs/COMPILARE.md](docs/COMPILARE.md).
Prima di pubblicare: [docs/PUBBLICAZIONE.md](docs/PUBBLICAZIONE.md).

## Licenza
Codice: MIT (vedi [LICENSE](LICENSE)). Componenti di terze parti:
[THIRD_PARTY.md](THIRD_PARTY.md).

Progetto di Lorenzo Marta.
