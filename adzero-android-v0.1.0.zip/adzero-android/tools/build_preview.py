"""Crea dist/adzero-anteprima.html: la dashboard in un solo file, da aprire
sul telefono per vedere la grafica. È solo un'anteprima: non filtra nulla.

Uso:  python tools/build_preview.py
"""
import base64
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"


def data_uri(path: Path, mime: str) -> str:
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode()


def main() -> None:
    html = (WEB / "index.html").read_text(encoding="utf-8")
    css = (WEB / "css" / "style.css").read_text(encoding="utf-8")
    css = re.sub(r'url\("\.\./fonts/([^"]+)"\)',
                 lambda m: f'url("{data_uri(WEB / "fonts" / m.group(1), "font/woff2")}")', css)
    logo = data_uri(WEB / "img" / "logo.svg", "image/svg+xml")

    # La CSP dell'app vieta il codice inline; nel file unico serve inline.
    html = re.sub(r'\s*<meta http-equiv="Content-Security-Policy"[^>]*>', "", html, flags=re.S)
    html = html.replace('<link rel="stylesheet" href="css/style.css">', f"<style>{css}</style>")
    html = html.replace('href="img/logo.svg"', f'href="{logo}"').replace('src="img/logo.svg"', f'src="{logo}"')
    for name in ("domain.js", "bridge.js", "app.js"):
        js = (WEB / "js" / name).read_text(encoding="utf-8")
        html = html.replace(f'<script src="js/{name}"></script>', f"<script>{js}</script>")

    out = ROOT / "dist" / "adzero-anteprima.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"creato {out.relative_to(ROOT)} ({out.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
