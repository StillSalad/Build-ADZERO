#!/bin/sh
# Esegue tutti i controlli che non richiedono Android Studio.
# Uso (dalla radice del repository):  sh tools/verify_all.sh
set -e
echo "== Test motore Python"
python3 -m pytest -q
echo "== Vettori di parità aggiornati?"
python3 tools/gen_parity.py >/dev/null
git diff --quiet -- tests/vectors/parity.json 2>/dev/null || echo "(parity.json rigenerato: ricordati di includerlo nel commit)"
echo "== Test JavaScript"
node --test tests/web/domain.test.js
echo "== Anteprima dashboard"
python3 tools/build_preview.py
echo "Tutto ok. Per Kotlin e Android: cd app/android && ./gradlew testDebugUnitTest assembleDebug"
