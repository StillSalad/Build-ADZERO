"""Genera tests/vectors/parity.json: un insieme ampio di righe e domini
"difficili" con il risultato atteso calcolato dal motore Python.
I test Kotlin lo rileggono e devono ottenere esattamente gli stessi risultati.

Uso:  python tools/gen_parity.py
"""
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from engine.domains import normalize_domain  # noqa: E402
from engine.matcher import RuleSet  # noqa: E402
from engine.rules import parse_text, to_compiled_line  # noqa: E402

rng = random.Random(42)
WORDS = ["ads", "ad", "track", "metrics", "cdn", "img", "api", "static", "pixel", "banner",
         "stats", "beacon", "log", "sdk", "promo", "media", "click", "serve", "x1", "a_b"]
TLDS = ["com", "net", "org", "io", "it", "co.uk", "xyz"]


def rand_domain(depth=None):
    depth = depth or rng.randint(2, 4)
    return ".".join(rng.choice(WORDS) for _ in range(depth - 1)) + "." + rng.choice(TLDS)


lines = [
    "# Titolo", "! commento", "[Adblock Plus 2.0]", "", "   ",
    "127.0.0.1 localhost", "::1 ip6-localhost ip6-loopback", "0.0.0.0 0.0.0.0",
    "255.255.255.255 broadcasthost", "192.168.0.1 router.lan", "0.0.0.0\tTabbed.Example.COM",
    "0.0.0.0 multi1.example.com multi2.example.com # commento", "0.0.0.0 bad..name.com",
    "||adblock.example.net^", "||mods.example.net^$important,all", "||thirdp.example.net^$third-party",
    "@@||allowed.adblock.example.net^", "@@plain-allow.example.org", "||path.example.net/ads/*",
    "example.com##.banner", "example.com#@#.ad", "*.wildcard.example", "città.example",
    "https://url.example.com/x", "-bad.example.com", "UPPER.Example.Com.", "just-one-label",
    "0.0.0.0 google.com", "||cloudfront.net^", "0.0.0.0 ads.google.com", "a b c",
    "||x.example^|", "||weird^^", "@@0.0.0.0 x.com", ":: v6sink.example.com", "1.2.3.4",
    "0.0.0.0 under_score.example.com", "||Mixed.Case.Example^", "plain.example.net",
    "  0.0.0.0   spaced.example.com   ", "0.0.0.0 port.example.com:80", "\u00a0nbsp.example.com",
]
for _ in range(400):
    d = rand_domain()
    fmt = rng.randint(0, 3)
    lines.append({0: f"0.0.0.0 {d}", 1: f"||{d}^", 2: d, 3: f"@@||{d}^"}[fmt])

text = "\n".join(lines)
rules, report = parse_text(text)
rs = RuleSet()
rs.add_all(rules)

queries = ["", "localhost", "a..b.com", "ADS.google.com", "x.y.adblock.example.net",
           "allowed.adblock.example.net", "sub.allowed.adblock.example.net", "a.wildcard.example",
           "wildcard.example", "xn--citt-3na.example", "città.example", "d.cloudfront.net",
           "google.com", "tabbed.example.com", "sub.tabbed.example.com", "1.2.3.4", "upper.example.com"]
for r in rules:
    queries += [r.domain, "sub." + r.domain]
queries += [rand_domain() for _ in range(400)]

decisions = []
for q in queries:
    dec = rs.check(q)
    decisions.append({"q": q, "blocked": dec.blocked, "reason": dec.reason})

normalize_cases = [{"in": q, "out": normalize_domain(q)} for q in queries + lines]

out = {
    "description": "Generato da tools/gen_parity.py. Non modificare a mano.",
    "text": text,
    "report": report.as_dict(),
    "compiled": [to_compiled_line(r) for r in rules],
    "rejected": sorted(r.domain for r, _ in rs.rejected),
    "decisions": decisions,
    "normalize": normalize_cases,
}
dest = ROOT / "tests" / "vectors" / "parity.json"
dest.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"scritto {dest.relative_to(ROOT)}: {len(rules)} regole, {len(decisions)} decisioni, "
      f"{len(normalize_cases)} normalizzazioni")
